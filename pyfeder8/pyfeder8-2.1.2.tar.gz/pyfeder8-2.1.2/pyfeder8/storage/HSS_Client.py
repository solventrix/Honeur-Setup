import json
import pandas as pd
from io import StringIO

from pyfeder8.GenericRestClient import *
from pyfeder8.TokenContext import TokenContext


class HSS_Client(GenericRestClient):
    """
    A Python client to call the REST API of the HONEUR Storage Service (HSS)
    The environment determines the environment (PRD, UAT, DEV) to connect to
    """
    def __init__(self, environment: Environment, verify_tls: bool = True):
        super().__init__(environment, verify_tls)

    @property
    def environment(self):
        return self._environment

    @property
    def hss_api_url(self):
        return self._hss_api_url

    @property
    def login_api_url(self):
        return self._login_api_url

    @property
    def catalogue_api_url(self):
        return self._catalogue_api_url

    def download_file_with_uuid(self, uuid: str, token_context: TokenContext = None):
        """Downloads the file with the given UUID"""
        request_url = self._hss_api_url + "/" + uuid
        response = self._do_get_request(request_url, token_context)
        return HSS_Client._handle_file_response(response)

    def download_file_with_key(self, file_key: str, token_context: TokenContext = None):
        """Downloads the file with the given file key"""
        request_url = self._hss_api_url + "/v2/files?fileKey=" + file_key
        response = self._do_get_request(request_url, token_context)
        return HSS_Client._handle_file_response(response)

    def download_file_with_key_as_dataframe(self, file_key: str, token_context: TokenContext = None):
        """Downloads the file with the given file key and returns it as pandas DataFrame"""
        file_content = self.download_file_with_key(file_key, token_context)
        file_content_str_io = StringIO(str(file_content, 'utf-8'))
        if file_key.lower().endswith(".csv"):
            return pd.read_csv(file_content_str_io)
        elif file_key.lower().endswith(".json"):
            return pd.read_json(file_content_str_io, orient='columns')
        else:
            raise Exception(f'File with key {file_key} cannot be converted to a pandas DataFrame!')

    def download_file_with_key_as_dictionary(self, file_key: str, token_context: TokenContext = None):
        """Downloads the file with the given file key and returns it as dictionary"""
        file_content = self.download_file_with_key(file_key, token_context)
        return json.loads(file_content.decode('utf-8'))

    def delete_file_with_uuid(self, uuid, token_context: TokenContext = None):
        """Deletes the file with the given UUID"""
        request_url = self._hss_api_url + "/" + uuid
        response = self._do_delete_request(request_url, token_context)
        if response.status_code != requests.codes.no_content:
            logging.error("File with UUID '{}' could not be deleted!".format(uuid))
            return False
        return True

    def delete_file_with_key(self, file_key: str, token_context: TokenContext = None):
        """Deletes the file with the given file key"""
        request_url = self._hss_api_url + "/v2/files?file_key=" + file_key
        response = self._do_delete_request(request_url, token_context)
        if response.status_code != requests.codes.no_content:
            logging.error("File with key '{}' could not be deleted!".format(file_key))
            return False
        return True

    def list_files(self, file_key_prefix: str, token_context: TokenContext = None):
        """Returns a list of files whose file key matches the given file key prefix"""
        request_url = self._hss_api_url + "/v2/files/list?fileKeyPrefix=" + file_key_prefix
        return self._get_json(request_url, token_context)

    def save_data_file(self, file, token_context: TokenContext = None):
        """Saves the given file in the data folder and returns the UUID of the saved file"""
        request_url = self._hss_api_url + "/data"
        return self._save_file(request_url, file, token_context)

    def list_data_files(self, token_context: TokenContext = None):
        """Returns a list of all files in the data folder"""
        request_url = self._hss_api_url + "/data/list"
        return self._get_json(request_url, token_context)

    def save_notebook_results(self, notebook_uuid, file, zip_file=None, token_context: TokenContext = None):
        """ Saves the result files for the notebook with the given UUID. Deprecated! CatalogueClient.save_script_result should be used instead! """
        request_url = "{}/notebook-results/{}".format(self.hss_api_url, notebook_uuid)
        if file:
            file_to_save = file
        elif zip_file:
            file_to_save = zip_file
        else:
            logging.warning("Missing file input parameter")
            return
        return self._save_file(request_url, file_to_save, token_context)

