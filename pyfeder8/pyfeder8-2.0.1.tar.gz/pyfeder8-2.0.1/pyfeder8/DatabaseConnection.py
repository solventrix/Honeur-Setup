import logging
import sqlalchemy as db


def get_db_engine(db_host, db_port, db_name, db_username, db_password):
    """
    Helper function to create a database engine by use of the given connection parameters
    """
    return db.create_engine(_get_db_connect_string(db_host, db_port, db_name, db_username, db_password))


def _get_db_connect_string(db_host, db_port, db_name, db_username, db_password):
    logging.info("Database {} at host: {} and port: {}".format(db_name, db_host, db_port))
    return "postgresql+psycopg2://{}:{}@{}:{}/{}".format(db_username, db_password, db_host, db_port, db_name)
