import logging
import os
import requests
from datetime import datetime

from pyfeder8 import PasswordManager
from pyfeder8.TokenContext import TokenContext
from pyfeder8.config.Configuration import Configuration
from pyfeder8.config.Environment import Environment
from pyfeder8.config.TherapeuticDomain import TherapeuticDomain


class TokenContextProvider:

    def __init__(self, configuration: Configuration):
        self._configuration = configuration

    def get_token_context(self) -> TokenContext:
        """
        Retrieves a TokenContext from any of the available sources
        :return: TokenContext
        """
        token_context = self._get_token_context_from_local_token_endpoint()
        if token_context:
            return token_context

        username = self._configuration.central_service_connection_details.username
        password = self._configuration.central_service_connection_details.password
        if username and password:
            token_context = self._get_token_context_from_central_token_endpoint(username, password)
            return token_context
        else:
            logging.warning("Missing username or password of Feder8 account in configuration!")

    def _get_token_context_from_local_token_endpoint(self) -> TokenContext:
        response = requests.get(self._configuration.local_token_endpoint())
        if response.status_code != 200:
            logging.warning(f"Token could not be retrieved from the local token endpoint! Error status code {response.status_code}")
            return None
        token_response = response.json()
        return TokenContext(
            token_response.get("accessToken"),
            token_response.get("idToken"),
            token_response.get("refreshToken"),
            token_response.get("creationTime")
        )

    def _get_token_context_from_central_token_endpoint(self, username=None, password=None) -> TokenContext:
        if not username:
            username = self._configuration.central_service_connection_details.username
        if not password:
            password = self._configuration.central_service_connection_details.password
        if not username or not password:
            logging.warning("Missing username and/or password of Feder8 account!")
            return None

        request_url = self._configuration.central_token_endpoint()
        request_data = { "username" : username,
                         "password" : password,
                         "grant_type" : "password",
                         "client_id" : self._configuration.central_service_connection_details.oauth_client_id,
                         "client_secret" : self._configuration.central_service_connection_details.oauth_client_secret }
        verify_tls = self._configuration.central_service_connection_details.verify_tls
        response = requests.post(url=request_url, data=request_data, verify=verify_tls)
        token_response = response.json()
        return TokenContext(
            access_token = token_response["access_token"],
            id_token = token_response["id_token"],
            refresh_token = token_response["refresh_token"],
            creation_time=datetime.now())

    def get_token_context_with_api_key(self, username=None, api_key=None) -> TokenContext:
        if not username:
            logging.warning("Missing username")
            return
        if not api_key:
            logging.warning("Missing API key")
            return
        oidc_client_secret_api_key = os.getenv('OIDC_CLIENT_SECRET_API_KEY')
        if not oidc_client_secret_api_key:
            logging.warning("Environment variable 'OIDC_CLIENT_SECRET_API_KEY' should be set!")
            return

        request_url = self._configuration.central_token_endpoint()
        request_data = { "username" : username,
                         "password" : api_key,
                         "grant_type" : "password",
                         "client_id" : "api-key",
                         "client_secret" : oidc_client_secret_api_key }
        verify_tls = self._configuration.central_service_connection_details.verify_tls
        response = requests.post(url=request_url, data=request_data, verify=verify_tls)
        token_response = response.json()
        return TokenContext(
            access_token = token_response["access_token"],
            id_token = token_response["id_token"],
            refresh_token = token_response["refresh_token"],
            creation_time=datetime.now())

    def get_token_context_from_vault(self, domain: TherapeuticDomain, env: Environment) -> TokenContext:
        """
        Retrieves the username and password of a central Feder8 account from a local vault
        and retrieves a valid token (and its associated fingerprint) by use of the username / password combination
        """
        credential = PasswordManager.get_credential(domain, env)
        if credential:
            return self._get_token_context_from_central_token_endpoint(credential.username,
                                                                       credential.password)
