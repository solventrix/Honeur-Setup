class RequestMessage:

    def __init__(self, uuid:str, study: str, organization: str, payload: str, context: str=None):
        self.uuid = uuid
        self.study = study
        self.organization = organization
        self.payload = payload
        self.context = context

    def to_dict(self):
        return self.__dict__
