from enum import Enum

from pyfeder8.config.Environment import Environment
from pyfeder8.config.TherapeuticDomain import TherapeuticDomain


class Feder8Service(Enum):
    """
    Enum for each of the available Feder8 environments
    """
    CAS = "cas"
    HARBOR = "harbor"
    CATALOGUE = "catalogue"
    DISTRIBUTED_ANALYTICS = "distributed-analytics"

    def get_url(self, domain: TherapeuticDomain, env:Environment):
        return f"https://{self.get_host(domain, env)}"

    def get_host(self, domain: TherapeuticDomain, env:Environment):
        return f"{self.value}{env.get_url_addition()}.{domain.domain()}"
