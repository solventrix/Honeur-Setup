import os, sys, logging, json
from pathlib import Path


def find_script_uuid_in_env():
    script_uuid = os.getenv('SCRIPT_UUID')
    if not script_uuid:
        logging.warning("Env variable SCRIPT_UUID not found")
    return script_uuid


def find_script_uuid_in_zeppelin(z):
    try:
        if z.get("script_uuid"):
            return z.get("script_uuid")
    except Exception as e:
        logging.warning(e)
    try:
        if z.z.get("script_uuid"):
            return z.z.get("script_uuid")
    except Exception as e:
        logging.warning(e)


def find_script_uuid_in_metadata():
    script_metadata_filename = _find_script_metadata_file()
    if not script_metadata_filename:
        logging.warning("Metadata file not found!")
        return None
    with open(script_metadata_filename,'r') as script_metadata_file:
        metadata = json.load(script_metadata_file)
        return metadata['script_uuid']


def _find_script_metadata_file():
    working_dir = sys.path[0]
    logging.info("Working directory: {}".format(working_dir))
    parent_dir = working_dir[0:working_dir.rindex('/')]
    for path in Path(parent_dir).rglob('metadata.json'):
        return path.name
