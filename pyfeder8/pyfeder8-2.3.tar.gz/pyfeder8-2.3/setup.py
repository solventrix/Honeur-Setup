from setuptools import setup

__project__ = "pyfeder8"
__version__ = "2.3"
__description__ = "A Python package to interact with Feder8 services"
__packages__ = ["pyfeder8", "pyfeder8.catalogue", "pyfeder8.config", "pyfeder8.distributed_analytics", "pyfeder8.pipeline"]
__url__ = "https://github.com/solventrix/pyfeder8"
__author__ = "Peter Moorthamer"
__author_email__ = "pmoorth1@its.jnj.com"
__classifiers__ = [
    "Development Status :: 5 - Production/Stable",
    "Intended Audience :: Healthcare Industry",
    "Programming Language :: Python :: 3",
]
__requires__ = ["requests", "uuid", "pandas", "sqlalchemy", "spring-config-client"]

setup(
    name = __project__,
    version = __version__,
    description = __description__,
    url = __url__,
    packages = __packages__,
    author = __author__,
    author_email = __author_email__,
    classifiers = __classifiers__,
    install_requires = __requires__
)