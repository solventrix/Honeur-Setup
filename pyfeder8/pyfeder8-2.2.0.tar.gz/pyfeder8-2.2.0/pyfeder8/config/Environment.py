from enum import Enum


class Environment(Enum):
    """
    Enum for each of the available Feder8 environments
    """
    DEV_LOCAL = "DEV_LOCAL"
    DEV = "DEV"
    UAT = "UAT"
    PRD = "PRD"

    def get_url_addition(self) -> str:
        if Environment.PRD == self:
            return ""
        elif Environment.UAT == self:
            return "-uat"
        elif Environment.DEV == self:
            return "-dev"
        elif Environment.DEV_LOCAL == self:
            return "-local"
