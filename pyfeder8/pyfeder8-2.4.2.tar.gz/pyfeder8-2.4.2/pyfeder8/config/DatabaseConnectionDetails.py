class DatabaseConnectionDetails:

    def __init__(self, db_host, db_port, db_name, db_username, db_password, db_admin_username, db_admin_password,
                 dbms="postgresql",
                 cdm_schema="omopcdm", vocab_schema="omopcdm", results_schema="results", scratch_schema="scratch"):
        self._dbms = dbms
        self._db_host = db_host
        self._db_port = db_port
        self._db_name = db_name
        self._db_username = db_username
        self._db_password = db_password
        self._db_admin_username = db_admin_username
        self._db_admin_password = db_admin_password
        self._cdm_schema = cdm_schema
        self._vocab_schema = vocab_schema
        self._results_schema = results_schema
        self._scratch_schema = scratch_schema

    @property
    def dbms(self):
        return self._dbms

    @property
    def host(self):
        return self._db_host

    @property
    def port(self):
        return self._db_port

    @property
    def name(self):
        return self._db_name

    @property
    def username(self):
        return self._db_username

    @property
    def password(self):
        return self._db_password

    @property
    def admin_username(self):
        return self._db_admin_username

    @property
    def admin_password(self):
        return self._db_admin_password

    @property
    def cdm_schema(self):
        return self._cdm_schema

    @property
    def vocab_schema(self):
        return self._vocab_schema

    @property
    def results_schema(self):
        return self._results_schema

    @property
    def scratch_schema(self):
        return self._scratch_schema

    def connect_string(self, admin=False):
        un = self.username
        pwd = self.password
        if admin:
            un = self.admin_username
            pwd = self.admin_password
        base_connect_string = f"{un}:{pwd}@{self.host}:{self.port}/{self.name}"
        if self.dbms == "postgresql":
            return f"postgresql+psycopg2://{base_connect_string}"
        elif self.dbms == "mssql":
            return f"mssql+pyodbc://{base_connect_string}?driver=ODBC+Driver+18+for+SQL+Server&TrustServerCertificate=yes"
        else:
            raise f"Unsupported DBMS {self.dbms}"

    def __str__(self):
        return f"host={self.host}, port={self.port}, name={self.name}, " \
               f"username={self.username}, admin_username={self.admin_username}, dbms={self.dbms}"
