import sys, logging, json
from pathlib import Path


def find_script_uuid_in_zeppelin(z):
    try:
        if z.z:
            return z.z.get("script_uuid")
        else:
            return z.get("script_uuid")
    except AttributeError as ae:
        logging.error(ae)
    finally:
        return z.get("script_uuid")


def find_script_uuid_in_metadata():
    script_metadata_filename = _find_script_metadata_file()
    if not script_metadata_filename:
        logging.warning("Metadata file not found!")
        return None
    with open(script_metadata_filename,'r') as script_metadata_file:
        metadata = json.load(script_metadata_file)
        return metadata['script_uuid']


def _find_script_metadata_file():
    working_dir = sys.path[0]
    logging.info("Working directory: {}".format(working_dir))
    parent_dir = working_dir[0:working_dir.rindex('/')]
    for path in Path(parent_dir).rglob('metadata.json'):
        return path.name
