import requests
import logging

from enum import Enum
from storage import TokenContextProvider
from storage.Environment import Environment
from storage.TokenContext import TokenContext


class HSS_Client:
    """
    A Python client to call the REST API of the HONEUR Storage Service (HSS)
    The environment determines the environment (PRD, UAT, DEV) to connect to
    """
    def __init__(self, environment: Environment):
        self._environment = environment
        self._hss_api_url = Environment.get_hss_api_url(environment)
        self._login_api_url = Environment.get_login_api_url(environment)
        self._catalogue_api_url = Environment.get_catalogue_api_url(environment)

    @property
    def environment(self):
        return self._environment

    @property
    def hss_api_url(self):
        return self._hss_api_url

    @property
    def login_api_url(self):
        return self._login_api_url

    @property
    def catalogue_api_url(self):
        return self._catalogue_api_url

    def download_file(self, uuid: str, token_context: TokenContext = None):
        """Downloads the file with the given UUID"""
        request_url = self._hss_api_url + "/" + uuid
        response = self._do_get_request(request_url, token_context)
        return HSS_Client._handle_file_response(response)

    def delete_file(self, uuid, token_context: TokenContext = None):
        """Deletes the file with the given UUID"""
        request_url = self._hss_api_url + "/" + uuid
        response = self._do_delete_request(request_url, token_context)
        if response.status_code != requests.codes.no_content:
            logging.error("File with UUID '{}' could not be deleted!".format(uuid))
            return False
        return True

    def save_data_file(self, file, token_context: TokenContext = None):
        """Saves the given file in the data folder and returns the UUID of the saved file"""
        request_url = self._hss_api_url + "/data"
        return self._save_file(request_url, file, token_context)

    def list_data_files(self, token_context: TokenContext = None):
        """Returns a list of all files in the data folder"""
        request_url = self._hss_api_url + "/data/list"
        return self._list_files(request_url, token_context)

    def list_studies(self, token_context: TokenContext = None):
        """Returns a list of all studies from the Study Catalogue"""
        request_url = self.catalogue_api_url + "/studies"
        response = self._do_get_request(request_url, token_context)
        return self._handle_json_response(response)

    def list_study_files(self, study_id, token_context: TokenContext = None):
        """Returns a list of all files for the study with the given Study ID"""
        request_url = "{}/study-files/list/{}".format(self.hss_api_url, study_id)
        return self._list_files(request_url, token_context)

    def save_notebook_results(self, notebook_uuid, file, zip_file=None, token_context: TokenContext = None):
        """Saves the result files for the notebook with the given UUID"""
        request_url = "{}/notebook-results/{}".format(self.hss_api_url, notebook_uuid)
        if file:
            file_to_save = file
        elif zip_file:
            file_to_save = zip_file
        else:
            logging.warning("Missing file input parameter")
            return
        return self._save_file(request_url, file_to_save, token_context)

    def list_notebook_results(self, study_id, external_notebook_uuid=None, notebook_uuid=None,
                              latest_version_only=False, reverse_order=False, token_context: TokenContext = None):
        """
        Returns a list of results for the study with the given Study ID,
        additional criteria like the UUID of the notebook / shared notebook can be specified to further filter the list.
        The latest_version_only flag can be used to only return the latest version of the results, the reverse_order
        flag can be used to reverse the default order of the list
        """
        request_url = self._build_list_notebook_results_request_url(study_id,
                                                                    external_notebook_uuid, notebook_uuid,
                                                                    latest_version_only, reverse_order)
        return self._list_files(request_url, token_context)

    def _build_list_notebook_results_request_url(self, study_id, external_notebook_uuid=None, notebook_uuid=None,
                                                 latest_version_only=False, reverse_order=False):
        request_url = "{}/notebook-results/list/{}".format(self.hss_api_url, study_id)
        if external_notebook_uuid: request_url += "/" + external_notebook_uuid
        if notebook_uuid: request_url += "/" + notebook_uuid
        param_separator = "?"
        if latest_version_only:
            request_url += param_separator + "latestVersionOnly=true"
            param_separator = "&"
        if reverse_order:
            request_url += param_separator + "reverseOrder=true"
        return request_url

    def save_study_document(self, study_id, document_uuid, file, token_context: TokenContext = None):
        """Saves the given file in the documents folder and study sub folder and assigns the given UUID to it"""
        request_url = "{}/documents/{}/{}".format(self.hss_api_url, study_id, document_uuid)
        return self._save_file(request_url, file, token_context)

    def list_study_documents(self, study_id, token_context: TokenContext = None):
        """Returns a list of document files that belong to the study with the given ID"""
        request_url = "{}/documents/list/{}".format(self.hss_api_url, study_id)
        return self._list_files(request_url, token_context)

    def list_study_notebooks(self, study_id, external_notebook_uuid=None, token_context: TokenContext = None):
        """
        Returns a list of all shared notebooks of the study with the given Study ID.
        The UUID of the Zepl notebook can be specified to filter the list of notebooks
        """
        request_url = "{}/notebooks/list/{}".format(self.hss_api_url, study_id)
        if external_notebook_uuid: request_url += "/" + external_notebook_uuid
        return self._list_files(request_url, token_context)

    def _list_files(self, request_url, token_context: TokenContext = None):
        response = self._do_get_request(request_url, token_context)
        return HSS_Client._handle_json_response(response)

    def _do_get_request(self, request_url, token_context=None):
        return self._do_request(request_url, RequestMethod.GET, token_context)

    def _save_file(self, request_url, file, token_context=None):
        files = {"file": file}
        response = self._do_request(request_url, RequestMethod.POST, token_context, files)
        return self._handle_save_response(response)

    def _do_delete_request(self, request_url, token_context=None):
        return self._do_request(request_url, RequestMethod.DELETE, token_context)

    def _do_request(self, request_url, request_method, token_context=None, files=None):
        if not token_context: token_context = self._get_token_context()
        headers = {"token": token_context.token, "userFingerprint": token_context.fingerprint}
        cookies = {"userFingerprint": token_context.fingerprint}
        try:
            if RequestMethod.GET == request_method:
                return requests.get(request_url, headers=headers, cookies=cookies, verify=True)
            elif RequestMethod.POST == request_method:
                return requests.post(request_url, files=files, headers=headers, cookies=cookies, verify=True)
            elif RequestMethod.DELETE == request_method:
                return requests.delete(request_url, headers=headers, cookies=cookies, verify=True)
            else:
                logging.warning("Request method {} not supported!".format(request_method))
        except Exception as e:
            logging.error("{} request {} failed!".format(request_method, request_url), e)

    @staticmethod
    def _handle_file_response(response: requests.Response) -> bytes:
        if response.status_code == requests.codes.ok:
            return response.content
        else:
            logging.warning("Error response status code: {}".format(response.status_code))
            response.raise_for_status()

    @staticmethod
    def _handle_json_response(response: requests.Response):
        if response.status_code == requests.codes.ok:
            return response.json()
        else:
            logging.warning("Error response status code: {}".format(response.status_code))
            response.raise_for_status()

    @staticmethod
    def _handle_save_response(response: requests.Response):
        if response.status_code == 201:
            location = str(response.headers['Location'])
            return HSS_Client.parse_uuid_from_location(location)
        else:
            logging.error("The file could not be saved, status code: {}!".format(response.status_code))
            response.raise_for_status()

    @staticmethod
    def parse_uuid_from_location(location):
        return location[location.rindex("/")+1:]

    def _get_token_context(self) -> TokenContext:
        token_context = TokenContextProvider.get_token_context_from_webapi()
        if not token_context:
            return TokenContextProvider.get_token_context_from_vault(self.environment)


class RequestMethod(Enum):
    GET = "Get"
    POST = "Post"
    DELETE = "Delete"
