import logging, requests
from requests.auth import HTTPBasicAuth
from storage.TokenContext import TokenContext
from storage.Environment import Environment
from storage import PasswordManager


WEBAPI_TOKEN_ENDPOINT = "http://webapi:8080/webapi/hss/token"


def get_token_context_from_webapi(webapi_base_url:str = None) -> TokenContext:
    """
    Retrieves a TokenContext (a token and its associated fingerprint) by calling the token
    REST endpoint exposed by the WebAPI (backend of Atlas)
    :param webapi_base_url: the base URL of the webAPI service that will be called to generate the TokenContext,
    when the base URL is not provided, the default URL of a local Docker installation will be used
    :return: TokenContext
    """
    webapi_token_endpoint = WEBAPI_TOKEN_ENDPOINT
    if webapi_base_url:
        webapi_token_endpoint = webapi_base_url + "/hss/token"
    token_reponse = requests.get(webapi_token_endpoint)
    token = token_reponse.json().get('token')
    fingerprint = token_reponse.json().get('userFingerprint')
    return TokenContext(token, fingerprint)


def get_token_context_from_vault(environment: Environment) -> TokenContext:
    """
    Retrieves the username and password of a central HONEUR account from a local vault
    and retrieves a valid token (and its associated fingerprint) by use of the username / password combination
    """
    credential = PasswordManager.get_credential(environment)
    if credential:
        return get_token_context(environment, credential.username, credential.password)


def get_token_context(environment: Environment, username: str, password: str) -> TokenContext:
    """
    Logs on to the given Environment with the given username and password to get a valid TokenContext
    (token and its associated fingerprint)
    """
    basic_auth_credentials = HTTPBasicAuth(username, password)
    response = requests.get(Environment.get_login_api_url(environment), auth=basic_auth_credentials)
    logging.debug("get_token_context response {}".format(response.content))
    token = response.json()["token"]
    fingerprint = response.cookies["userFingerprint"]
    return TokenContext(token, fingerprint)