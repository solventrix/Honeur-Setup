# pyfeder8
Federate API in Python

- Open the sphinx folder and run `make html` to generate the documentation in HTML format
- Run `python3 setup.py install` to install the pyfeder8 code as Python package
- Run `pip install git+https://github.com/solventrix/pyfeder8` to install the pyfeder8 package from GitHub
- Run `python3 setup.py sdist` to upload pyfeder8 as Python package to PyPI 

