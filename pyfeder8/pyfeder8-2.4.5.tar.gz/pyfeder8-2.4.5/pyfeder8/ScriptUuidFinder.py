import os, sys, logging, json
from pathlib import Path


"""
Helper functions to find the script UUID's depending on the environment the script runs in
"""


def find_script_uuid(z=None):
    script_uuid = find_script_uuid_in_env()
    if script_uuid: return script_uuid
    script_uuid = find_script_uuid_in_metadata()
    if script_uuid: return script_uuid
    return find_script_uuid_in_zeppelin(z)


def find_script_version_uuid(z=None):
    script_version_uuid = find_script_version_uuid_in_env()
    if script_version_uuid: return script_version_uuid
    script_version_uuid = find_script_version_uuid_in_metadata()
    if script_version_uuid: return script_version_uuid
    return find_script_version_uuid_in_zeppelin(z)


def find_shared_script_version_uuid(z=None):
    shared_script_version_uuid = find_shared_script_version_uuid_in_env()
    if shared_script_version_uuid: return shared_script_version_uuid
    shared_script_version_uuid = find_shared_script_version_uuid_in_metadata()
    if shared_script_version_uuid: return shared_script_version_uuid
    return find_shared_script_version_uuid_in_zeppelin(z)


def find_task_execution_uuid(z=None):
    task_execution_uuid = find_task_execution_uuid_in_env()
    if task_execution_uuid: return task_execution_uuid
    task_execution_uuid = find_task_execution_uuid_in_metadata()
    if task_execution_uuid: return task_execution_uuid
    return find_task_execution_uuid_in_zeppelin(z)


def find_script_uuid_in_env():
    return _find_uuid_in_env('SCRIPT_UUID')


def find_script_version_uuid_in_env():
    return _find_uuid_in_env('SCRIPT_VERSION_UUID')


def find_shared_script_version_uuid_in_env():
    return _find_uuid_in_env('SHARED_SCRIPT_VERSION_UUID')


def find_task_execution_uuid_in_env():
    return _find_uuid_in_env('TASK_EXECUTION_UUID')


def _find_uuid_in_env(env_key):
    uuid = os.getenv(env_key)
    if not uuid:
        logging.warning(f"Env variable '{env_key}' not found")
    return uuid


def find_script_uuid_in_metadata():
    return _find_uuid_in_metadata(uuid_key='script_uuid')


def find_script_version_uuid_in_metadata():
    return _find_uuid_in_metadata(uuid_key='script_version_uuid')


def find_shared_script_version_uuid_in_metadata():
    return _find_uuid_in_metadata(uuid_key='shared_script_version_uuid')


def find_task_execution_uuid_in_metadata():
    return _find_uuid_in_metadata(uuid_key='task_execution_uuid')


def _find_uuid_in_metadata(uuid_key):
    script_metadata_filename = _find_script_metadata_file()
    if not script_metadata_filename:
        logging.warning("Metadata file not found!")
        return None
    with open(script_metadata_filename,'r') as script_metadata_file:
        metadata = json.load(script_metadata_file)
        return metadata[uuid_key]


def _find_script_metadata_file():
    working_dir = sys.path[0]
    logging.info("Working directory: {}".format(working_dir))
    parent_dir = working_dir[0:working_dir.rindex('/')]
    for path in Path(parent_dir).rglob('metadata.json'):
        return path.name


def find_script_uuid_in_zeppelin(z):
    return _find_uuid_in_zeppelin(z, 'script_uuid')


def find_script_version_uuid_in_zeppelin(z):
    return _find_uuid_in_zeppelin(z, 'script_version_uuid')


def find_shared_script_version_uuid_in_zeppelin(z):
    return _find_uuid_in_zeppelin(z, 'shared_script_version_uuid')


def find_task_execution_uuid_in_zeppelin(z):
    return _find_uuid_in_zeppelin(z, 'shared_script_version_uuid')


def _find_uuid_in_zeppelin(z, uuid_key):
    if not z:
        logging.warning("Missing zeppelin context")
        return None
    try:
        if z.get(uuid_key):
            return z.get(uuid_key)
    except Exception as e:
        logging.warning(e)
    try:
        if z.z.get(uuid_key):
            return z.z.get(uuid_key)
    except Exception as e:
        logging.warning(e)
    logging.warning(f"'{uuid_key}' not found in zeppelin context")
