# pyfeder8
Federate API in Python

## How to build
- Open the sphinx folder and run `make html` to generate the documentation in HTML format
- Run `python3 setup.py install` to install the pyfeder8 code as Python package
- Run `python3 setup.py sdist` to create a source distribution

## How to install 
- Make sure the dependencies of the pyfeder8 package are installed:
    - `pip3 install requests`
    - `pip3 install uuid`
    - `pip3 install pandas`
    - `pip3 install sqlalchemy`
    - `pip3 install spring-config-client`
- Option 1: install pyfeder8 directly from its private Github repository:
    - `pip3 install git+https://github.com/solventrix/pyfeder8`
- Option 2: Install pyfeder8 from the public HONEUR repository:
    - `pip3 install https://github.com/solventrix/Honeur-Setup/raw/master/pyfeder8/pyfeder8-2.3.tar.gz`
    
## How to use

```python
from pyfeder8.TokenContextProvider import TokenContextProvider
from pyfeder8.catalogue.CatalogueClient import CatalogueClient
from pyfeder8.config.ConfigurationClient import ConfigurationClient

configuration = ConfigurationClient().get_configuration()
token_context = TokenContextProvider(configuration).get_token_context()

catalogue_client = CatalogueClient(configuration)
studies = catalogue_client.list_studies(token_context)
```

 
 

