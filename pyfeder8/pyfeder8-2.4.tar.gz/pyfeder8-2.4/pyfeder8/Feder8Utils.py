import datetime
import json
import logging
import os
import pandas as pd

from pandas import DataFrame

from pyfeder8.config.DatabaseConnectionDetails import DatabaseConnectionDetails
from pyfeder8.TokenContextProvider import TokenContextProvider
from pyfeder8.config.ConfigurationClient import ConfigurationClient
from pyfeder8.config.Configuration import Configuration

from sqlalchemy import create_engine


def get_therapeutic_area() -> str:
    return os.environ.get("THERAPEUTIC_AREA", "honeur")


def get_indication() -> str:
    return os.environ.get("INDICATION", "mm")


def get_organization() -> str:
    return os.environ.get("ORGANIZATION")


def get_analysis_table_schema(results_schema) -> str:
    return os.environ.get("DB_ANALYSIS_TABLE_SCHEMA", results_schema)


def get_analysis_table_name() -> str:
    return os.environ.get("DB_ANALYSIS_TABLE_NAME", "analysis_table")


def find_analysis_table_schema(db_engine, results_schema="results"):
    analysis_table_name = get_analysis_table_name()
    expected_analysis_table_schema = get_analysis_table_schema(results_schema=results_schema)
    query = f"SELECT table_schema FROM information_schema.tables WHERE table_name = '{analysis_table_name}'"
    query_result = pd.read_sql_query(query, db_engine)
    actual_analysis_table_schemas = query_result['table_schema'].tolist()
    if not actual_analysis_table_schemas:
        logging.warning(f"No table '{analysis_table_name}' found in database")
        return expected_analysis_table_schema
    logging.info(f"Table '{analysis_table_name}' found in the following database schema(s): "
                 f"{actual_analysis_table_schemas}")
    if expected_analysis_table_schema in actual_analysis_table_schemas:
        return expected_analysis_table_schema
    else:
        logging.info(f"Table '{analysis_table_name}' not found in schema '{expected_analysis_table_schema}'")
        return actual_analysis_table_schemas[0]


def get_db_connection_details(configuration=None) -> DatabaseConnectionDetails:
    if not configuration:
        configuration = get_feder8_configuration()
    if configuration:
        return configuration.db_connection_details
    else:
        logging.info("Falling back to environment variables")
        db_host = os.environ.get("DB_HOST", "postgres")
        db_username = os.environ.get("DB_ADMIN_USERNAME")
        db_password = os.environ.get("DB_ADMIN_PASSWORD")
        db_port = os.environ.get("DB_PORT", 5432)
        db_name = os.environ.get("DB_NAME", "OHDSI")
        cdm_schema = os.environ.get("DB_CDM_SCHEMA", "omopcdm")
        vocab_schema = os.environ.get("DB_VOCABULARY_SCHEMA", "omopcdm")
        results_schema = os.environ.get("DB_RESULTS_SCHEMA", "results")
        scratch_schema = os.environ.get("DB_SCRATCH_SCHEMA", "scratch")
        return DatabaseConnectionDetails(
            db_host=db_host,
            db_port=db_port,
            db_name=db_name,
            db_admin_username=db_username,
            db_admin_password=db_password,
            db_username=db_username,
            db_password=db_password,
            cdm_schema=cdm_schema,
            vocab_schema=vocab_schema,
            results_schema=results_schema,
            scratch_schema=scratch_schema
        )


def get_db_engine(db_connection_details: DatabaseConnectionDetails, admin=True):
    db_connect_str = db_connection_details.connect_string(admin)
    return create_engine(db_connect_str)


def get_feder8_configuration_name() -> str:
    therapeutic_area = get_therapeutic_area()
    config_name = "feder8-config-" + therapeutic_area.lower()
    organization = get_organization()
    if organization:
        config_name += "-" + organization.lower()
    return config_name


def get_feder8_configuration():
    config_name = get_feder8_configuration_name()
    try:
        configuration = ConfigurationClient(config_server="http://config-server:8080/config-server",
                                            config_name=config_name).get_configuration()
        logging.info(f"Configuration '{config_name}' retrieved from local config server")
        return configuration
    except:
        logging.error(f"Failed to load configuration '{config_name}' from local config server")
        return None


def get_feder8_token(configuration: Configuration):
    try:
        return TokenContextProvider(configuration).get_token_context()
    except:
        logging.warning("Failed to retrieve a feder8 token")
        return None


def create_sub_folder(folder_name: str):
    current_dir = os.path.dirname(os.path.realpath('__file__'))
    folder_path = os.path.join(current_dir, folder_name)
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
    return folder_path


def build_filename(prefix, file_extension, include_current_date=True):
    if include_current_date:
        cur_date = str(datetime.datetime.today().strftime('%Y%m%d'))
        return f'{prefix}_{cur_date}.{file_extension}'
    else:
        return f'{prefix}.{file_extension}'


def write_dataframe_to_csv(df: DataFrame, filename: str):
    df.to_csv(filename, index=False)


def write_dataframe_to_json(df: DataFrame, filename: str):
    df.to_json(filename, orient='columns')


def write_dictionary_to_json(dd: dict, filename: str):
    with open(filename, "w") as json_file:
        json.dump(dd, json_file)

