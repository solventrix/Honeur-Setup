from pyfeder8.config.CentralServiceConnectionDetails import CentralServiceConnectionDetails
from pyfeder8.config.DatabaseConnectionDetails import DatabaseConnectionDetails
from pyfeder8.config.HostDetails import HostDetails


class Configuration:

    def __init__(self,
                 name: str,
                 host_details: HostDetails,
                 db_connection_details: DatabaseConnectionDetails,
                 central_service_connection_details: CentralServiceConnectionDetails):
        self._name = name
        self._host_details = host_details
        self._db_connection_details = db_connection_details
        self._central_service_connection_details = central_service_connection_details

    def local_token_endpoint(self):
        return f"{self.host_details.token_endpoint}?envKey={self.name}"

    def central_token_endpoint(self):
        return self.central_service_connection_details.oauth_token_uri

    @property
    def name(self) -> str:
        return self._name

    @property
    def host_details(self) -> HostDetails:
        return self._host_details

    @property
    def db_connection_details(self) -> DatabaseConnectionDetails:
        return self._db_connection_details

    @property
    def central_service_connection_details(self) -> CentralServiceConnectionDetails:
        return self._central_service_connection_details

