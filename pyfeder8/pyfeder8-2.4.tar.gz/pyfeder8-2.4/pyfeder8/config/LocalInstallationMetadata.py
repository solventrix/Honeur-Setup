from pyfeder8.catalogue.CatalogueClient import CatalogueClient
from pyfeder8.config.Configuration import Configuration
from pyfeder8.config.LocalPortalClient import LocalPortalClient


def get_local_installation_metadata(configuration: Configuration,
                                    local_portal_base_url="http://local-portal:8080/portal"):
    local_portal_client = LocalPortalClient(local_portal_base_url)
    return local_portal_client.get_local_installation_metadata(configuration.name)


def capture_and_save_local_installation_metadata(configuration: Configuration,
                                                 script_version_uuid,
                                                 local_portal_base_url="http://local-portal:8080/portal"):
    metadata = get_local_installation_metadata(configuration, local_portal_base_url)
    cdm_source_name = metadata['omopCdmMetadata']['cdmSource']['cdm_source_name']
    filename = f"{cdm_source_name}_installation_metadata.json"
    catalogue_client = CatalogueClient(configuration)
    catalogue_client.save_dictionary_as_json_script_result(script_version_uuid=script_version_uuid,
                                                           dd=metadata,
                                                           filename=filename)

