import logging
import sqlalchemy as db

from pyfeder8.config.DatabaseConnectionDetails import DatabaseConnectionDetails


def get_db_engine(db_conn_details:DatabaseConnectionDetails):
    """
    Helper function to create a database engine by use of the given connection parameters
    """
    logging.info(f"Connect to database {db_conn_details.name} at host: {db_conn_details.host} and port: {db_conn_details.port}")
    return db.create_engine(db_conn_details.connect_string())
