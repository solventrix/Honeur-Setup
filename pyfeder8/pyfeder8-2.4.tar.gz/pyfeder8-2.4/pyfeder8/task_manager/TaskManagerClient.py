import json
from io import StringIO

import pandas as pd
from pandas import DataFrame

from pyfeder8.GenericRestClient import *
from pyfeder8.TokenContext import TokenContext
from pyfeder8.config.Configuration import Configuration


class TaskManagerClient(GenericRestClient):

    """
    A Python client to call the REST API of the local Task Manager Service
    The configuration provides the context of the task execution
    """
    def __init__(self, configuration: Configuration):
        super().__init__(configuration)
        self.empty_token = TokenContext("", "", "", "")

    @property
    def task_execution_api_url(self):
        return self._configuration.host_details.task_manager_container_url + "/local-analysis-task-execution"

    @property
    def local_analysis_api_url(self):
        return self._configuration.host_details.task_manager_container_url + "/local-analysis"

    def save_task_execution_result(self, task_execution_uuid, result_file):
        """Saves a result file for the task execution with the given UUID"""
        request_url = f"{self.task_execution_api_url}/{task_execution_uuid}/results"
        return self._save_file(request_url, result_file, self.empty_token)

    def save_shared_script_version_result(self,
                                          shared_script_version_uuid,
                                          local_config_name,
                                          result_file):
        """Saves a result file for the shared script version with the given UUID"""
        request_url = f"{self.local_analysis_api_url}/{shared_script_version_uuid}/results?localConfigurationName={local_config_name}"
        return self._save_file(request_url, result_file, self.empty_token)

