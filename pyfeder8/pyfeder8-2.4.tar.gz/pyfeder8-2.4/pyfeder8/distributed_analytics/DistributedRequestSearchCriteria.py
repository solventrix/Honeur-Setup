import json
from datetime import datetime, timedelta

from pyfeder8.distributed_analytics.DistributedRequestStatus import DistributedRequestStatus


class DistributedRequestSearchCriteria():

    def __init__(self, study:str=None, statuses=None, created_from=None, created_until=None):
        self._study = study
        if statuses and len(statuses) > 0:
            self._statuses = statuses
        else:
            self._statuses = [s.value for s in DistributedRequestStatus]
        now = datetime.now()
        if created_from:
            self._created_from = created_from
        else:
            self._created_from = now - timedelta(days=31)
        if created_until:
            self._created_until = created_until
        else:
            self._created_until = now + timedelta(days=1)

    @staticmethod
    def _date_to_string(date_time: datetime):
        return date_time.strftime("%d-%b-%Y %H:%M:%S")

    def to_dict(self) -> ():
        return { "study" : self._study,
                 "statuses": self._statuses,
                 "createdDateFrom": DistributedRequestSearchCriteria._date_to_string(self._created_from),
                 "createdDateUntil": DistributedRequestSearchCriteria._date_to_string(self._created_until)
               }

    def to_json(self):
        return json.dumps(self.to_dict())
