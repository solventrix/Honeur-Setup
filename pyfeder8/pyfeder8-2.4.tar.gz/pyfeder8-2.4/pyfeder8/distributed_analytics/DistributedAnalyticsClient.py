import logging
import time
import uuid

from pyfeder8.GenericRestClient import GenericRestClient
from pyfeder8.TokenContext import TokenContext
from pyfeder8.config.Configuration import Configuration
from pyfeder8.distributed_analytics.DistributedRequestSearchCriteria import DistributedRequestSearchCriteria
from pyfeder8.distributed_analytics.DockerRequest import DockerRequest
from pyfeder8.distributed_analytics.RequestMessage import RequestMessage


class DistributedAnalyticsClient(GenericRestClient):
    """
    A Python client to call the REST API of the Feder8 Distributed Analytics Service
    The configuration determines the domain and environment to connect to
    """
    def __init__(self, configuration: Configuration):
        super().__init__(configuration)

    @property
    def distributed_analytics_api_url(self):
        return self._configuration.central_service_connection_details.distributed_analytics_api_url

    @property
    def configuration(self):
        return self._configuration

    def search_distributed_requests(self, search_criteria: DistributedRequestSearchCriteria,
                                    token_context: TokenContext = None):
        request_url = f"{self._get_distributed_requests_url()}/search"
        return self._do_post_request(request_url, json=search_criteria.to_dict(), token_context=token_context)

    def run_docker_pipeline(self, study:str, organizations:[], docker_requests: [], token_context: TokenContext = None):
        request_uuid = str(uuid.uuid4())
        response_dict = {}
        for organization in organizations:
            response_dict[organization] = []
            for docker_request in docker_requests:
                response = self.run_docker_image(study, [organization], docker_request, request_uuid, token_context)
                response_dict[organization].append(response[organization])
                if response[organization].get("errorResponse"):
                    break

        return response_dict

    def run_docker_image(self, study:str, organizations:[], docker_request: DockerRequest,
                         request_uuid: str = str(uuid.uuid4()),
                         token_context: TokenContext = None):
        logging.info(f"Run Docker image {docker_request.image_name_tag}")
        request_dict = self.create_and_send_request_messages(study, organizations, docker_request, request_uuid, token_context)
        if not request_dict:
            logging.warning("Distributed requests where not created!")
            return {}
        return self.wait_for_responses(request_uuid, organizations, token_context)

    def create_and_send_request_message(self, study: str, organization: str, docker_request: DockerRequest,
                                        request_uuid: str = str(uuid.uuid4()), token_context: TokenContext = None):
        request_dict = self.create_and_send_request_messages(study, [organization], docker_request,
                                                             request_uuid, token_context)
        return request_dict[organization]

    def create_and_send_request_messages(self, study: str, organizations:[], docker_request: DockerRequest,
                                         request_uuid: str = str(uuid.uuid4()), token_context: TokenContext = None):
        request_dict = {}
        for organization in organizations:
            request_message = RequestMessage(request_uuid, study, organization,
                                             docker_request.to_json(),
                                             docker_request.description)
            r = self.send_request_message(request_message, token_context)
            if r.status_code == 200 or r.status_code == 201:
                request_dict[organization] = r.json()
        return request_dict

    def send_request_message(self, request_message:RequestMessage,
                             token_context: TokenContext = None):
        return self._do_post_request(self._get_distributed_requests_url(),
                                     json=request_message.to_dict(),
                                     token_context=token_context)

    def wait_for_response(self, request_uuid: str, organization: str, token_context: TokenContext = None):
        response_dict = self.wait_for_responses(request_uuid, [organization], token_context)
        return response_dict[organization]

    def wait_for_responses(self, request_uuid: str, organizations:[], token_context: TokenContext = None):
        pending_organizations = organizations
        completed_organizations = []
        response_dict = {}
        while len(pending_organizations) > 0:
            for organization in pending_organizations:
                response_message = self.poll_response_message(request_uuid, organization, token_context)
                if response_message.status_code == 204:
                    logging.info("No response yet from organization " + organization)
                    time.sleep(2)
                elif response_message.status_code == 404:
                    logging.warning("Request {} not found for organization {}!".format(request_uuid, organization))
                    completed_organizations.append(organization)
                elif response_message.status_code == 403:
                    logging.warning("Forbidden to poll for request {} and organization {}!".format(request_uuid, organization))
                    completed_organizations.append(organization)
                elif response_message.status_code == 200:
                    response_dict[organization] = response_message.json()
                    self.acknowledge_response_message(response_dict[organization].get("uuid"), token_context)
                    completed_organizations.append(organization)
            pending_organizations = [o for o in pending_organizations if o not in completed_organizations]
        return response_dict

    @staticmethod
    def check_all_success_responses(organizations:[], responses: dict):
        for organization in organizations:
            if DistributedAnalyticsClient.is_error_response(responses[organization]):
                return False
        return True

    @staticmethod
    def is_error_response(response):
        return response.get("errorResponse")

    def find_distributed_request(self, request_uuid: str,
                                 token_context: TokenContext = None):
        request_url = f"{self._get_distributed_requests_url()}/{request_uuid}"
        return self._do_get_request(request_url, token_context)

    def poll_response_message(self, request_uuid: str, organization: str, token_context: TokenContext = None):
        request_url = f"{self.distributed_analytics_api_url}/distributed-responses/poll/{request_uuid}/{organization}"
        return self._do_get_request(request_url, token_context)

    def acknowledge_response_message(self, response_message_uuid: str, token_context: TokenContext = None):
        request_url = f"{self.distributed_analytics_api_url}/distributed-responses/acknowledge/{response_message_uuid}"
        return self._do_post_request(request_url=request_url, token_context=token_context)

    def _get_distributed_requests_url(self):
        return f"{self.distributed_analytics_api_url}/distributed-requests"
