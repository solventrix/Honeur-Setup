import json
import logging
import uuid

from pyfeder8.TokenContext import TokenContext
from pyfeder8.config.Configuration import Configuration
from pyfeder8.distributed_analytics.DistributedAnalyticsClient import DistributedAnalyticsClient
from pyfeder8.distributed_analytics.DockerRequest import DockerRequest


def run_distributed_average(configuration: Configuration,
                            study: str,
                            organizations: [],
                            sql_query: str,
                            column_name: str,
                            token_context: TokenContext = None):
    da_client = DistributedAnalyticsClient(configuration)
    image_repo = configuration.central_service_connection_details.image_repo

    distributed_request_uuid = str(uuid.uuid4())

    query_request_dict = {}
    sql_query_docker_request_name_prefix = "distributed-average-data-preparation-"
    for organization in organizations:
        sql_query_docker_request = DockerRequest(name=sql_query_docker_request_name_prefix + organization,
                                                 description="Prepare data for distributed average",
                                                 image_name_tag=image_repo + "/distributed-analytics/run-query-and-export-to-csv:1.0.0",
                                                 env_vars={"DB_HOST": "postgres", "DB_DATABASE_NAME": "OHDSI",
                                                           "DB_OMOPCDM_SCHEMA": "omopcdm",
                                                           "FEDER8_SQL_QUERY": sql_query},
                                                 volumes={"shared": "/var/lib/shared"})

        request_messages = da_client.create_and_send_request_messages(study, [organization],
                                                                      sql_query_docker_request,
                                                                      distributed_request_uuid,
                                                                      token_context)
        query_request_dict[organization] = request_messages.get(organization)

    da_client.wait_for_responses(distributed_request_uuid, organizations, token_context)

    for organization in organizations:
        request_messages = query_request_dict[organization].get("requestMessages")
        sql_query_docker_request_name = sql_query_docker_request_name_prefix + organization
        sql_query_docker_request = [m for m in request_messages if sql_query_docker_request_name in m.get("payload")][0]
        r_uuid = sql_query_docker_request.get("uuid")
        database_uri = "/home/feder8/data/" + distributed_request_uuid + "/" + r_uuid + "/result.csv"
        distributed_average_docker_request = DockerRequest(name="distributed-average",
                                                 description="Distributed average",
                                                 image_name_tag=image_repo + "/distributed-analytics/vantage6-distributed-average:1.0.0",
                                                 env_vars={ "COLUMN_NAME": column_name, "DATABASE_URI": database_uri }, volumes={})
        da_client.create_and_send_request_messages(study, [organization],
                                                   distributed_average_docker_request,
                                                   distributed_request_uuid,
                                                   token_context)

    responses = da_client.wait_for_responses(distributed_request_uuid, organizations, token_context)

    # Now we can combine the partials to a global average.
    global_sum = 0
    global_count = 0
    for organization in organizations:
        logging.info(organization + ":\n" + responses[organization].get("payload"))
        output = json.loads(responses[organization].get("payload"))
        global_sum += output["sum"]
        global_count += output["count"]

    if global_count <= 0:
        logging.warning("Global count should be larger than 0!")
        return None

    return {"average": global_sum / global_count}
