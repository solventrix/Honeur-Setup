from pyfeder8.TokenContext import TokenContext
from pyfeder8.config.Configuration import Configuration
from pyfeder8.distributed_analytics.DistributedAnalyticsClient import DistributedAnalyticsClient
from pyfeder8.distributed_analytics.DockerRequest import DockerRequest


def run_custom_concepts_update(configuration: Configuration, study: str, organizations: [], token_context: TokenContext = None):
    da_client = DistributedAnalyticsClient(configuration)

    update_custom_concepts_docker_request = DockerRequest(name="omopcdm-update-custom-concepts-2.2",
                                                          description="Update custom concepts v2.2",
                                                          image_name_tag="harbor-dev.honeur.org/honeur/postgres:omopcdm-update-custom-concepts-2.2",
                                                          env_vars={"DB_HOST": "postgres", "DB_DATABASE_NAME": "OHDSI",
                                                                    "DB_OMOPCDM_SCHEMA": "omopcdm"},
                                                          volumes={"shared": "/var/lib/shared"})

    rebuild_concept_hierarchy_docker_request = DockerRequest(name="rebuild-concept-hierarchy-2.0.1",
                                                             description="Rebuild concept hierarchy v2.0.1",
                                                             image_name_tag="harbor-dev.honeur.org/honeur/postgres:results-rebuild-concept-hierarchy-2.0.1",
                                                             env_vars={"DB_HOST": "postgres",
                                                                       "DB_DATABASE_NAME": "OHDSI",
                                                                       "DB_RESULTS_SCHEMA": "results"},
                                                             volumes={"shared": "/var/lib/shared"})

    docker_requests = [update_custom_concepts_docker_request, rebuild_concept_hierarchy_docker_request]
    return da_client.run_docker_pipeline(study, organizations, docker_requests, token_context)