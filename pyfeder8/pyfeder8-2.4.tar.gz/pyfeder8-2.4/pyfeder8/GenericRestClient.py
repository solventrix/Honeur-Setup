import requests
import logging

from enum import Enum

from pyfeder8.TokenContextProvider import TokenContextProvider
from pyfeder8.config.Configuration import Configuration
from pyfeder8.TokenContext import TokenContext


class GenericRestClient:

    """
    A generic Python client to call the REST API of a HONEUR Service
    The environment determines the environment (PRD, UAT, DEV) to connect to
    """
    def __init__(self, configuration: Configuration):
        self._configuration = configuration
        self._token_context_provider = TokenContextProvider(configuration)

    @property
    def configuration(self):
        return self._configuration

    @property
    def verify_tls(self):
        return self._configuration.central_service_connection_details.verify_tls

    def _get_json(self, request_url, token_context: TokenContext = None):
        response = self._do_get_request(request_url, token_context)
        return GenericRestClient._handle_json_response(response)

    def _save_file(self, request_url, file, token_context=None):
        files = {"file": file}
        response = self._do_request(request_url, RequestMethod.POST, token_context, files)
        return self._handle_save_response(response)

    def _do_get_request(self, request_url, token_context=None):
        return self._do_request(request_url, RequestMethod.GET, token_context)

    def _do_post_request(self, request_url, data=None, json=None, token_context=None):
        headers = self._get_request_headers(content_type="application/json", token_context=token_context)
        return requests.post(request_url, data=data, json=json, headers=headers, verify=self.verify_tls)

    def _do_delete_request(self, request_url, token_context=None):
        return self._do_request(request_url, RequestMethod.DELETE, token_context)

    def _do_request(self, request_url, request_method, token_context=None, files=None):
        headers = self._get_request_headers(token_context=token_context)
        try:
            if RequestMethod.GET == request_method:
                return requests.get(request_url, headers=headers, verify=self.verify_tls)
            elif RequestMethod.POST == request_method:
                return requests.post(request_url, files=files, headers=headers, verify=self.verify_tls)
            elif RequestMethod.DELETE == request_method:
                return requests.delete(request_url, headers=headers, verify=self.verify_tls)
            else:
                logging.warning("Request method {} not supported!".format(request_method))
        except Exception as e:
            logging.error("{} request {} failed!".format(request_method, request_url), e)

    @staticmethod
    def _handle_file_response(response: requests.Response) -> bytes:
        if response.status_code == requests.codes.ok:
            return response.content
        else:
            logging.warning("Error response status code: {}".format(response.status_code))
            response.raise_for_status()

    @staticmethod
    def _handle_json_response(response: requests.Response):
        if response.status_code == requests.codes.ok:
            return response.json()
        else:
            logging.warning("Error response status code: {}".format(response.status_code))
            response.raise_for_status()

    @staticmethod
    def _handle_save_response(response: requests.Response):
        if response.status_code == 201:
            location = str(response.headers['Location'])
            logging.info("Location of saved file: {}".format(location))
            return GenericRestClient.parse_uuid_from_location(location)
        else:
            logging.error("The file could not be saved, status code: {}!".format(response.status_code))
            response.raise_for_status()

    @staticmethod
    def parse_uuid_from_location(location):
        return location[location.rindex("/")+1:]

    def _get_token_context(self) -> TokenContext:
        return self._token_context_provider.get_token_context()

    def _get_request_headers(self, content_type=None, token_context=None):
        if not token_context: token_context = self._get_token_context()
        if token_context and token_context.id_token:
            headers = { "Authorization": "Bearer " + token_context.id_token }
        if content_type :
            headers["Content-Type"] = content_type
        return headers


class RequestMethod(Enum):
    GET = "Get"
    POST = "Post"
    DELETE = "Delete"