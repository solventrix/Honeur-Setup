class HostDetails:

    def __init__(self, hostname, token_endpoint, task_manager_container_url=None):
        self._hostname = hostname
        self._token_endpoint = token_endpoint
        self._task_manager_container_url = task_manager_container_url

    @property
    def hostname(self):
        return self._hostname

    @property
    def token_endpoint(self):
        return self._token_endpoint

    @token_endpoint.setter
    def token_endpoint(self, token_endpoint):
        self._token_endpoint = token_endpoint

    @property
    def task_manager_container_url(self):
        return self._task_manager_container_url
