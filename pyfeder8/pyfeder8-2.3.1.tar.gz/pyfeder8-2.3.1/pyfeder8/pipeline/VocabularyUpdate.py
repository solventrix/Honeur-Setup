import logging
import uuid
from io import StringIO

import pandas as pd

from pyfeder8.TokenContext import TokenContext
from pyfeder8.config.Configuration import Configuration
from pyfeder8.distributed_analytics.DistributedAnalyticsClient import DistributedAnalyticsClient
from pyfeder8.distributed_analytics.DockerRequest import DockerRequest


class VocabularyUpdate:

    def __init__(self, configuration: Configuration, study: str):
        self._configuration = configuration
        self._study = study
        self._da_client = DistributedAnalyticsClient(configuration)
        self._distributed_request_uuid = str(uuid.uuid4())
        self._image_registry = configuration.central_service_connection_details.image_repo

    def run_vocabulary_update(self, organization: str, token_context: TokenContext = None):
        logging.info("Checking if base indexes are set...")
        base_indexes_set = self._check_base_indexes(organization, token_context)
        if base_indexes_set:
            logging.info("Base indexes found")
            self._run_delete_base_indexes(organization, token_context)
        logging.info("Checking if constraints are set...")
        constraints_set = self._check_constraints(organization, token_context)
        if constraints_set:
            logging.info("Constraints found")
            self._run_delete_constraints(organization, token_context)
        self._run_vocabulary_update(organization, token_context)
        self._run_custom_concepts_update(organization, token_context)
        if constraints_set:
            self._run_add_constraints(organization, token_context)
        if base_indexes_set:
            self._run_add_base_indexes(organization, token_context)
        self._run_rebuild_concept_hierarchy(organization, token_context)

    def _check_base_indexes(self, organization: str, token_context: TokenContext = None):
        index_count_query = "SELECT count(*) FROM pg_indexes WHERE schemaname = 'omopcdm' AND indexname = 'idx_concept_concept_id'"
        description="Checking whether base indexes are set..."
        index_count = self._run_count_query(index_count_query, description, organization, token_context)
        return index_count > 0

    def _run_delete_base_indexes(self, organization: str, token_context: TokenContext = None):
        logging.info("Trying to delete the base indexes...")
        delete_base_indexes_docker_request = DockerRequest(name="delete-base-indexes",
                                                           description="Delete base indexes before running the vocabulary update",
                                                           image_name_tag=self._image_registry + "/postgres:omopcdm-delete-base-indexes-2.0.0",
                                                           env_vars={"DB_HOST": "postgres", "DB_DATABASE_NAME": "OHDSI" },
                                                           volumes={"shared": "/var/lib/shared"})
        response = self._run_docker_request_and_wait(delete_base_indexes_docker_request, organization, token_context)
        if DistributedAnalyticsClient.is_error_response(response):
            raise Exception("The base indexes could not be deleted!")

    def _check_constraints(self, organization: str, token_context: TokenContext = None):
        constraint_count_query = "SELECT count(*) FROM pg_catalog.pg_constraint con INNER JOIN pg_catalog.pg_class rel ON rel.oid = con.conrelid INNER JOIN pg_catalog.pg_namespace nsp ON nsp.oid = connamespace WHERE nsp.nspname = 'omopcdm' AND rel.relname = 'concept' AND con.conname = 'fpk_concept_domain'"
        description = "Checking whether constraints are set..."
        index_count = self._run_count_query(constraint_count_query, description, organization, token_context)
        return index_count > 0

    def _run_delete_constraints(self, organization: str, token_context: TokenContext = None):
        logging.info("Trying to delete the constraints...")
        delete_constraints_docker_request = DockerRequest(name="delete-constraints",
                                                          description="Delete constraints before running the vocabulary update",
                                                          image_name_tag=self._image_registry + "/postgres:omopcdm-delete-constraints-2.0.0",
                                                          env_vars={"DB_HOST": "postgres", "DB_DATABASE_NAME": "OHDSI" },
                                                          volumes={"shared": "/var/lib/shared"})
        response = self._run_docker_request_and_wait(delete_constraints_docker_request, organization, token_context)
        if DistributedAnalyticsClient.is_error_response(response):
            raise Exception("The constraints could not be deleted!")

    def _run_vocabulary_update(self, organization: str, token_context: TokenContext = None):
        logging.info("Trying to update the vocabulary...")
        vocabulary_update_docker_request = DockerRequest(name="update-vocabulary",
                                                         description="Update vocabulary",
                                                         image_name_tag=self._image_registry + "/postgres:omopcdm-update-vocabulary-2.0.0",
                                                         env_vars={"DB_HOST": "postgres", "DB_DATABASE_NAME": "OHDSI"},
                                                         volumes={"shared": "/var/lib/shared"})
        response = self._run_docker_request_and_wait(vocabulary_update_docker_request, organization, token_context)
        if DistributedAnalyticsClient.is_error_response(response):
            raise Exception("The vocabulary could not be updated!")

    def _run_custom_concepts_update(self, organization: str, token_context: TokenContext = None):
        logging.info("Trying to update the custom concepts...")
        vocabulary_update_docker_request = DockerRequest(name="update-custom-concepts",
                                                         description="Update custom concepts",
                                                         image_name_tag=self._image_registry + "/postgres:omopcdm-update-custom-concepts-2.2",
                                                         env_vars={"DB_HOST": "postgres", "DB_DATABASE_NAME": "OHDSI"},
                                                         volumes={"shared": "/var/lib/shared"})
        response = self._run_docker_request_and_wait(vocabulary_update_docker_request, organization, token_context)
        if DistributedAnalyticsClient.is_error_response(response):
            raise Exception("The custom concepts could not be updated!")

    def _run_add_constraints(self, organization: str, token_context: TokenContext = None):
        logging.info("Trying to add database constraints...")
        add_constraints_docker_request = DockerRequest(name="add-constraints",
                                                       description="Add database constraints",
                                                       image_name_tag=self._image_registry + "/postgres:omopcdm-add-constraints-2.0.0",
                                                       env_vars={"DB_HOST": "postgres", "DB_DATABASE_NAME": "OHDSI"},
                                                       volumes={"shared": "/var/lib/shared"})
        response = self._run_docker_request_and_wait(add_constraints_docker_request, organization, token_context)
        if DistributedAnalyticsClient.is_error_response(response):
            raise Exception("The database constraints concepts could not be set!")

    def _run_add_base_indexes(self, organization: str, token_context: TokenContext = None):
        logging.info("Trying to add base database indexes...")
        add_indexes_docker_request = DockerRequest(name="add-base-indexes",
                                                   description="Add database indexes",
                                                   image_name_tag=self._image_registry + "/postgres:omopcdm-add-base-indexes-2.0.0",
                                                   env_vars={"DB_HOST": "postgres", "DB_DATABASE_NAME": "OHDSI"},
                                                   volumes={"shared": "/var/lib/shared"})
        response = self._run_docker_request_and_wait(add_indexes_docker_request, organization, token_context)
        if DistributedAnalyticsClient.is_error_response(response):
            raise Exception("The database indexes could not be set!")

    def _run_rebuild_concept_hierarchy(self, organization: str, token_context: TokenContext = None):
        logging.info("Trying to rebuild the concept hierarchy...")
        rebuild_concept_hierarchy_docker_request = DockerRequest(name="rebuild-concept-hierarchy",
                                                                 description="Add database indexes",
                                                                 image_name_tag=self._image_registry + "/postgres:results-rebuild-concept-hierarchy-2.0.0",
                                                                 env_vars={"DB_HOST": "postgres", "DB_DATABASE_NAME": "OHDSI"},
                                                                 volumes={"shared": "/var/lib/shared"})
        response = self._run_docker_request_and_wait(rebuild_concept_hierarchy_docker_request, organization, token_context)
        if DistributedAnalyticsClient.is_error_response(response):
            raise Exception("The concept hierarch could not be rebuild!")

    def _run_count_query(self, count_query: str, description: str, organization: str, token_context: TokenContext = None):
        count_query_docker_request = DockerRequest(name="count-query",
                                                   description=description,
                                                   image_name_tag=self._image_registry + "/script/run-query-and-export-to-csv:1.0.0",
                                                   env_vars={"DB_HOST": "postgres", "DB_DATABASE_NAME": "OHDSI",
                                                             "DB_OMOPCDM_SCHEMA": "omopcdm",
                                                             "FEDER8_SQL_QUERY": count_query},
                                                   volumes={"shared": "/var/lib/shared"})
        response = self._run_docker_request_and_wait(count_query_docker_request, organization, token_context)
        if DistributedAnalyticsClient.is_error_response(response):
            raise Exception(f"The following count query failed for organization {organization}: '{count_query}'!")
        count_df = pd.read_csv(StringIO(response.get("payload")))
        return count_df["count"][0]

    def _run_docker_request_and_wait(self, docker_request, organization: str, token_context: TokenContext = None):
        self._da_client.create_and_send_request_message(self._study, organization,
                                                        docker_request,
                                                        self._distributed_request_uuid,
                                                        token_context)
        return self._da_client.wait_for_response(self._distributed_request_uuid, organization, token_context)


