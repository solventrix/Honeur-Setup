class HostDetails:

    def __init__(self, hostname, token_endpoint):
        self._hostname = hostname
        self._token_endpoint = token_endpoint

    @property
    def hostname(self):
        return self._hostname

    @property
    def token_endpoint(self):
        return self._token_endpoint

    @token_endpoint.setter
    def token_endpoint(self, token_endpoint):
        self._token_endpoint = token_endpoint
