class TokenContext:
    """
    Represents a JWT token for Feder8
    """
    def __init__(self, access_token, id_token, refresh_token, creation_time):
        self._access_token = access_token
        self._id_token = id_token
        self._refresh_token = refresh_token
        self._creation_time = creation_time

    @property
    def access_token(self):
        return self._access_token

    @property
    def id_token(self):
        return self._id_token

    @property
    def refresh_token(self):
        return self._refresh_token

    def __str__(self):
        return f"access_token={self.access_token}, id_token={self.id_token}, refresh_token{self.refresh_token}"
