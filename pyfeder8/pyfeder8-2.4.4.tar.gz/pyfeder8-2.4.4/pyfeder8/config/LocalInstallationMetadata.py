import datetime
import json
from pyfeder8.catalogue.CatalogueClient import CatalogueClient
from pyfeder8.config.Configuration import Configuration
from pyfeder8.config.LocalPortalClient import LocalPortalClient
from pyfeder8.task_manager.TaskManagerClient import TaskManagerClient
from pyfeder8.TokenContext import TokenContext


def get_local_installation_metadata(configuration: Configuration,
                                    local_portal_base_url="http://local-portal:8080/portal"):
    local_portal_client = LocalPortalClient(local_portal_base_url)
    return local_portal_client.get_local_installation_metadata(configuration.name)


def build_metadata_filename(metadata: dict):
    cdm_source_name = metadata['omopCdmMetadata']['cdmSource']['cdm_source_name']
    cur_date = str(datetime.datetime.today().strftime('%Y%m%d'))
    return f"{cdm_source_name}_metadata_{cur_date}.json"


def capture_local_metadata_and_save(configuration: Configuration,
                                    local_portal_base_url="http://local-portal:8080/portal",
                                    token_context: TokenContext = None):
    metadata = get_local_installation_metadata(configuration, local_portal_base_url)
    filename = build_metadata_filename(metadata=metadata)
    catalogue_client = CatalogueClient(configuration)
    catalogue_client.save_local_metadata(metadata=metadata, filename=filename, token_context=token_context)


def capture_local_metadata_and_save_as_script_result(configuration: Configuration,
                                                     script_version_uuid,
                                                     local_portal_base_url="http://local-portal:8080/portal",
                                                     token_context: TokenContext = None):
    metadata = get_local_installation_metadata(configuration, local_portal_base_url)
    filename = build_metadata_filename(metadata=metadata)
    catalogue_client = CatalogueClient(configuration)
    catalogue_client.save_dictionary_as_json_script_result(script_version_uuid=script_version_uuid,
                                                           dd=metadata,
                                                           filename=filename,
                                                           token_context=token_context)


def capture_local_metadata_and_save_as_task_execution_result(configuration: Configuration,
                                                             task_execution_uuid,
                                                             local_portal_base_url="http://local-portal:8080/portal"):
    metadata = get_local_installation_metadata(configuration, local_portal_base_url)
    filename = build_metadata_filename(metadata=metadata)
    task_manager_client = TaskManagerClient(configuration)
    with open(filename, "w") as metadata_file:
        json.dump(metadata, metadata_file)
    with open(filename) as metadata_file:
        return task_manager_client.save_task_execution_result(task_execution_uuid=task_execution_uuid,
                                                              result_file=metadata_file)


def get_latest_metadata(configuration: Configuration, token_context: TokenContext = None):
    catalogue_client = CatalogueClient(configuration)
    return catalogue_client.get_latest_local_metadata(token_context)


