import requests, logging


class LocalPortalClient():
    """
    A Python client to call the REST API of the Local Portal
    """
    def __init__(self, local_portal_base_url="http://local-portal:8080/portal"):
        self._local_portal_base_url = local_portal_base_url

    def get_configuration_names(self):
        request_url = f"{self._local_portal_base_url}/configuration/names"
        return LocalPortalClient._get_json_response(request_url)

    def get_local_installation_metadata(self, configuration_name):
        request_url = f"{self._local_portal_base_url}/api/info/{configuration_name}"
        return LocalPortalClient._get_json_response(request_url)

    @staticmethod
    def _get_json_response(request_url):
        response = requests.get(request_url, verify=False)
        return LocalPortalClient._handle_json_response(response)

    @staticmethod
    def _handle_json_response(response: requests.Response):
        if response.status_code == requests.codes.ok:
            return response.json()
        else:
            logging.warning("Error response status code: {}".format(response.status_code))
            response.raise_for_status()