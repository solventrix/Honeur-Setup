import uuid, logging
from pyfeder8.GenericRestClient import GenericRestClient
from pyfeder8.TokenContext import TokenContext
from pyfeder8.config.Configuration import Configuration
from pyfeder8.distributed_analytics.DistributedRequestSearchCriteria import DistributedRequestSearchCriteria
from pyfeder8.distributed_analytics.DockerRequest import DockerRequest
from pyfeder8.distributed_analytics.RequestMessage import RequestMessage


class DistributedAnalyticsClient(GenericRestClient):
    """
    A Python client to call the REST API of the Feder8 Distributed Analytics Service
    The configuration determines the domain and environment to connect to
    """
    def __init__(self, configuration: Configuration):
        super().__init__(configuration)

    @property
    def distributed_analytics_api_url(self):
        return self._configuration.central_service_connection_details.distributed_analytics_api_url

    def search_distributed_requests(self, search_criteria: DistributedRequestSearchCriteria,
                                    token_context: TokenContext = None):
        request_url = f"{self._get_distributed_requests_url()}/search"
        return self._do_post_request(request_url, json=search_criteria.to_dict(), token_context=token_context)

    def run_docker_pipeline(self, study:str, organizations:[], docker_requests: [], token_context: TokenContext = None):
        request_uuid = str(uuid.uuid4())
        for docker_request in docker_requests:
            self.run_docker_image(study, organizations, docker_request, request_uuid, token_context)

    def run_docker_image(self, study:str, organizations:[], docker_request: DockerRequest,
                         request_uuid: str = str(uuid.uuid4()),
                         token_context: TokenContext = None):
        for organization in organizations:
            request_message = RequestMessage(request_uuid, study, organization,
                                             docker_request.to_json(),
                                             docker_request.description)
            self.send_request_message(request_message, token_context)

        pending_organizations = organizations
        completed_organizations = []
        response_dict = {}
        while len(pending_organizations) > 0:
            for organization in pending_organizations:
                response_message = self.poll_response_message(request_uuid, organization, token_context)
                if response_message.status_code == 204:
                    logging.info("No response yet from organization " + organization)
                elif response_message.status_code == 200:
                    response_dict[organization] = response_message.json()
                    completed_organizations.append(organization)
            pending_organizations = [o for o in pending_organizations if o not in completed_organizations]
        return  response_dict

    def send_request_message(self, request_message:RequestMessage,
                             token_context: TokenContext = None):
        return self._do_post_request(self._get_distributed_requests_url(),
                                     json=request_message.to_dict(),
                                     token_context=token_context)

    def find_distributed_request(self, request_uuid: str,
                                 token_context: TokenContext = None):
        request_url = f"{self._get_distributed_requests_url()}/{request_uuid}"
        return self._do_get_request(request_url, token_context)

    def poll_response_message(self, request_uuid: str, organization: str, token_context: TokenContext = None):
        request_url = f"{self.distributed_analytics_api_url}/distributed-responses/poll/{request_uuid}/{organization}"
        return self._do_get_request(request_url, token_context)

    def acknowledge_response_message(self, response_message_uuid: str, token_context: TokenContext = None):
        request_url = f"{self.distributed_analytics_api_url}/distributed-responses/acknowledge/{response_message_uuid}"
        return self._do_post_request(request_url, token_context)

    def _get_distributed_requests_url(self):
        return f"{self.distributed_analytics_api_url}/distributed-requests"
