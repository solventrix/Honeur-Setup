import json


class DockerRequest:

    def __init__(self, name: str, description: str, image_name_tag: str, env_vars: dict):
        self._name = name
        self._description = description
        self._image_name_tag = image_name_tag
        self._env_vars = env_vars

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @property
    def image_name_tag(self) -> str:
        return self._image_name_tag

    @property
    def env_vars(self) -> {}:
        return self._env_vars

    def to_dict(self):
        return { "name": self.name,
                 "description": self.description,
                 "image_name_tag": self.image_name_tag,
                 "env_vars": self.env_vars
               }

    def to_json(self):
        return json.dumps(self.to_dict())
