from enum import Enum


class DistributedRequestStatus(Enum):
    PENDING = "PENDING"
    PENDING_ERROR = "PENDING_ERROR"
    COMPLETED = "COMPLETED"
    COMPLETED_ERROR = "COMPLETED_ERROR"
