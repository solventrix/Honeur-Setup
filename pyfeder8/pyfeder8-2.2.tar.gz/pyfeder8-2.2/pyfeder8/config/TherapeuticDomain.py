from enum import Enum


class TherapeuticDomain(Enum):
    """
    Enum for each of the available Feder8 therapeutic domains
    """
    HONEUR = "honeur.org"
    PHEDERATION = "phederation.org"
    ESFURN = "esfurn.org"
    ATHENA = "athenafederation.org"
    LUPUS = "lupusfederation.org"

    def domain(self):
        return self.value
