from pyfeder8.config.CentralServiceConnectionDetails import CentralServiceConnectionDetails
from pyfeder8.config.Configuration import Configuration
from pyfeder8.config.DatabaseConnectionDetails import DatabaseConnectionDetails
from pyfeder8.config.Environment import Environment
from pyfeder8.config.Feder8Service import Feder8Service
from pyfeder8.config.HostDetails import HostDetails
from pyfeder8.config.TherapeuticDomain import TherapeuticDomain


def build_configuration(domain: TherapeuticDomain, env: Environment, hostname: str ="local-portal"):
    return Configuration(_build_configuration_name(domain, env),
                         _build_host_details(hostname),
                         _build_db_connection_details(),
                         _build_central_service_connection_details(domain, env))


def _build_configuration_name(ta: TherapeuticDomain, env:Environment):
    return ta.name + "_" + env.name


def _build_host_details(hostname: str):
    return HostDetails(hostname, f"http://{hostname}/portal/api/token")


def _build_db_connection_details():
    return DatabaseConnectionDetails("postgres", "5432", "OHDSI", "honeur", None, "honeur_admin", None)


def _build_central_service_connection_details(domain: TherapeuticDomain, env:Environment):
    return CentralServiceConnectionDetails(_get_oauth_token_uri(domain, env),
                                           "feder8-local", "qoV2hPEWQjz5mRat",
                                           Feder8Service.HARBOR.get_url(domain, env), None, None,
                                           Feder8Service.CATALOGUE.get_url(domain, env),
                                           Feder8Service.DISTRIBUTED_ANALYTICS.get_url(domain, env))


def _get_oauth_token_uri(domain: TherapeuticDomain, env:Environment):
    return Feder8Service.CAS.get_url(domain, env) + "/oidc/token"

