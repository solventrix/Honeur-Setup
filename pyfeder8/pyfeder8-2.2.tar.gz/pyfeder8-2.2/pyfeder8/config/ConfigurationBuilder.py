from pyfeder8.config.CentralServiceConnectionDetails import CentralServiceConnectionDetails
from pyfeder8.config.Configuration import Configuration
from pyfeder8.config.DatabaseConnectionDetails import DatabaseConnectionDetails
from pyfeder8.config.Environment import Environment
from pyfeder8.config.Feder8Service import Feder8Service
from pyfeder8.config.HostDetails import HostDetails
from pyfeder8.config.TherapeuticDomain import TherapeuticDomain


def build_configuration(domain: TherapeuticDomain, env:Environment):
    return Configuration(_build_configuration_name(domain, env),
                         _build_host_details(),
                         _build_db_connection_details(),
                         _build_central_service_connection_details(domain, env))


def _build_configuration_name(ta: TherapeuticDomain, env:Environment):
    return ta.name + "_" + env.name


def _build_host_details():
    return HostDetails("localhost", "http://local-portal/api/token")


def _build_db_connection_details():
    return DatabaseConnectionDetails("postgres", "5432", "OHDSI", "honeur", None, "honeur_admin", None)


def _build_central_service_connection_details(domain: TherapeuticDomain, env:Environment):
    return CentralServiceConnectionDetails(_get_oauth_token_uri,
                                           "feder8-oidc-local-client", None,
                                           Feder8Service.HARBOR.get_url(domain, env), None, None,
                                           Feder8Service.CATALOGUE.get_url(domain, env))


def _get_oauth_token_uri(domain: TherapeuticDomain, env:Environment):
    return Feder8Service.CAS.get_url(domain, env) + "/oidc/token"

