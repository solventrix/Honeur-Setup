from spring_config import ClientConfigurationBuilder
from spring_config.client import SpringConfigClient

from pyfeder8.config.CentralServiceConnectionDetails import CentralServiceConnectionDetails
from pyfeder8.config.DatabaseConnectionDetails import DatabaseConnectionDetails
from pyfeder8.config.Configuration import Configuration
from pyfeder8.config.HostDetails import HostDetails


class ConfigurationClient:

    def __init__(self, config_server="http://127.0.0.1:8888", config_name="feder8-config", username="root", password="s3cr3t"):
        self._config_name = config_name
        config_client_config = ClientConfigurationBuilder().app_name(config_name).address(config_server)\
            .profile("default").authentication((username, password)).build()
        self._config_client = SpringConfigClient(config_client_config)
        self._config = self._config_client.get_config()

    def get_configuration(self) -> Configuration:
        return Configuration(self._config_name,
                             self.get_host_details(),
                             self.get_db_connection_details(),
                             self.get_central_service_connection_details())

    def get_host_details(self) -> HostDetails:
        host_config = self._get_host_config()
        return HostDetails(
            hostname=host_config['name'],
            token_endpoint=host_config['token-url']
        )

    def get_db_connection_details(self) -> DatabaseConnectionDetails:
        ds_config = self._get_datasource_config()
        return DatabaseConnectionDetails(
            db_host=ds_config["host"],
            db_port=ds_config["port"],
            db_name=ds_config["name"],
            db_username=ds_config["username"],
            db_password=ds_config["password"],
            db_admin_username=ds_config["admin-username"],
            db_admin_password=ds_config["admin-password"],
            cdm_schema=ds_config["cdm-schema"],
            vocab_schema=ds_config["vocabulary-schema"],
            results_schema=ds_config["results-schema"],
            scratch_schema=ds_config["scratch-schema"]
        )

    def get_central_service_connection_details(self) -> CentralServiceConnectionDetails:
        cs_config = self._get_central_service_config()
        return CentralServiceConnectionDetails(
            oauth_token_uri=cs_config["oauth-token-uri"],
            oauth_client_id=cs_config["oauth-client-id"],
            oauth_client_secret=cs_config["oauth-client-secret"],
            image_repo = cs_config["image-repo"],
            image_repo_username=cs_config["image-repo-username"],
            image_repo_key=cs_config["image-repo-key"],
            catalogue_api_url=cs_config["catalogue-api-url"],
            distributed_analytics_api_url=cs_config["distributed-analytics-api-url"]
        )

    def _get_host_config(self):
        return self._config['feder8']['local']['host']

    def _get_datasource_config(self):
        return self._config['feder8']['local']['datasource']

    def _get_central_service_config(self):
        return self._config['feder8']['central']['service']
