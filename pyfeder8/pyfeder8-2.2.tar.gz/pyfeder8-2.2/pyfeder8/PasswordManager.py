import keyring
from pyfeder8.config.Environment import Environment
from pyfeder8.config.TherapeuticDomain import TherapeuticDomain

USER_NAME_KEY = "username"


def save_username_password(domain: TherapeuticDomain, env: Environment, username: str, password: str):
    """
    Stores the given username and password for the given therapeutic domain and environment
    in the password store of the OS that is running this code
    """
    service_name = _get_service_name(domain, env)
    keyring.set_password(service_name, USER_NAME_KEY, username)
    keyring.set_password(service_name, username, password)


def get_password(domain: TherapeuticDomain, env: Environment, username: str):
    """
    Retrieves the password for the given user and environment
    from the password store of the OS that is running this code
    """
    service_name = _get_service_name(domain, env)
    return keyring.get_password(service_name, username)


def get_credential(domain: TherapeuticDomain, env: Environment):
    """Retrieves the username and password credentials for the given environment
    from the password store of the OS that is running this code
    Only 1 username per environment is when this function is used!
    """
    service_name = _get_service_name(domain, env)
    username = keyring.get_password(service_name, USER_NAME_KEY)
    return keyring.get_credential(service_name, username)


def _get_service_name(domain: TherapeuticDomain, env: Environment):
    return domain.name + "_" + env.name
