from sseclient import SSEClient

class Feder8DockerClient:

    def pull_image(self, name: str, tag: str):
        messages = SSEClient(f"http://localhost:8080/docker/images/pull?imageName={name}&imageTag={tag}")
        for msg in messages:
            print(msg)