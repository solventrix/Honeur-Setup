from pyfeder8.GenericRestClient import *
from pyfeder8.TokenContext import TokenContext


class CatalogueClient(GenericRestClient):
    """
    A Python client to call the REST API of the HONEUR Catalogue Service (HCS)
    The environment determines the environment (PRD, UAT, DEV) to connect to
    """
    def __init__(self, environment: Environment, verify_tls: bool = True):
        super().__init__(environment, verify_tls)

    def list_studies(self, token_context: TokenContext = None):
        """Retrieves a list of all studies from the Study Catalogue"""
        request_url = self.catalogue_api_url + "/studies"
        return self._get_json(request_url, token_context)

    def get_study(self, study_id: int, token_context: TokenContext = None):
        """Retrieves the study with the given ID from the Study Catalogue"""
        request_url = self.catalogue_api_url + "/studies/" + str(study_id)
        return self._get_json(request_url, token_context)

    def save_script_result(self, script_version_uuid, result_file, token_context: TokenContext = None):
        """Saves the given result for the script with the given UUID"""
        request_url = "{}/scripts/{}/results".format(self.catalogue_api_url, script_version_uuid)
        return self._save_file(request_url, result_file, token_context)

    def list_script_results(self, study_id: int, script_version_uuid=None, latest_version_only=False, token_context: TokenContext = None):
        """Retrieves a list of script results for the given study"""
        if script_version_uuid:
            request_url = "{}/studies/{}/scripts/{}/results".format(self.catalogue_api_url, study_id, script_version_uuid)
        else:
            request_url = "{}/studies/{}/script-results".format(self.catalogue_api_url, study_id)
        if latest_version_only:
            request_url += "?latestVersionOnly=true"
        return self._get_json(request_url, token_context)
