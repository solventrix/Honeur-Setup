from setuptools import setup

__project__ = "pyfeder8"
__version__ = "2.0"
__description__ = "A Python package to interact with HONEUR services"
__packages__ = ["pyfeder8", "pyfeder8.catalogue", "pyfeder8.storage"]
__author__ = "Peter Moorthamer"
__author_email__ = "pmoorth1@its.jnj.com"
__classifiers__ = [
    "Development Status :: 5 - Production/Stable",
    "Intended Audience :: Healthcare Industry",
    "Programming Language :: Python :: 3",
]
__requires__ = ["requests", "uuid", "sqlalchemy", "keyring"]

setup(
    name = __project__,
    version = __version__,
    description = __description__,
    packages = __packages__,
    author = __author__,
    author_email = __author_email__,
    classifiers = __classifiers__,
    requires = __requires__
)