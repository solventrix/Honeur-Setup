import docker
import logging

from pyfeder8.config.Configuration import Configuration


class DockerClient:

    def __init__(self, configuration: Configuration):
        self._configuration = configuration
        self._docker_client = docker.from_env()
        self._repository = configuration.central_service_connection_details.image_repo

    def __del__(self):
        if self._docker_client:
            self._docker_client.close()
        logging.info("Destructor called, cleaning up resources...")

    def get_registry(self):
        return f"https://{self._configuration.central_service_connection_details.image_repo}/v2"

    def login(self):
        image_repo = self._configuration.central_service_connection_details.image_repo
        image_repo_url = f"https://{image_repo}/v2"
        logging.info(f"Login @ {image_repo_url}")
        image_repo_username = self._configuration.central_service_connection_details.image_repo_username
        image_repo_password = self._configuration.central_service_connection_details.image_repo_key
        return self._docker_client.login(username=image_repo_username, password=image_repo_password, registry=image_repo_url)

    def pull_image(self, repository: str, tag: str):
        self.login()
        logging.info(f"Start pulling {repository}:{tag} image...")
        image = self._docker_client.images.pull(repository, tag)
        logging.info(f"Done pulling {repository}:{tag} image.")
        return image

    def list_images(self):
        return self._docker_client.images.list()

    def create_container(self, image, command=None, name=None, environment=None, network=None, volumes=None):
        return self._docker_client.containers.create(image=image, command=command, name=name,
                                                     environment=environment, network=network, volumes=volumes)

    def run_container(self, image, command=None, remove=False, name=None, environment=None, network=None, volumes=None, detach=True, show_logs=True):
        container = self._docker_client.containers.run(image=image, command=command, remove=remove, name=name,
                                                       environment=environment, network=network, volumes=volumes,
                                                       detach=detach)
        if show_logs:
            self.stream_logs(container)

    def stream_logs(self, container):
        for line in container.logs(stream=True):
            print(line.decode('UTF-8').strip())

    def list_containers(self):
        return self._docker_client.containers.list()

    def get_container(self, containerId: str):
        return self._docker_client.containers.get(containerId)
