import logging

from pyfeder8.TokenContext import TokenContext
from pyfeder8.catalogue.CatalogueClient import CatalogueClient
from pyfeder8.config.Configuration import Configuration
from pyfeder8.distributed_analytics.DistributedAnalyticsClient import DistributedAnalyticsClient
from pyfeder8.distributed_analytics.DockerRequest import DockerRequest


def run_data_quality_pipeline(configuration: Configuration,
                              study_name: str, organizations: [],
                              token_context: TokenContext = None):
    da_client = DistributedAnalyticsClient(configuration)
    image_repo = configuration.central_service_connection_details.image_repo

    catalogue_client = CatalogueClient(configuration)
    study = catalogue_client.get_study_by_name(study_name=study_name, token_context=token_context)

    achilles_docker_request = create_achilles_docker_request(study=study,
                                                             image_repo=image_repo)
    analysis_table_generator_docker_request = create_analysis_table_generator_docker_request(study=study,
                                                                                             image_repo=image_repo)
    data_quality_dashboard_docker_request = create_data_quality_dashboard_docker_request(study=study,
                                                                                         image_repo=image_repo)
    data_profiler_docker_request = create_data_profiler_docker_request(study=study,
                                                                       image_repo=image_repo)

    docker_requests = [achilles_docker_request,
                       analysis_table_generator_docker_request,
                       data_quality_dashboard_docker_request,
                       data_profiler_docker_request]

    return da_client.run_docker_pipeline(study_name, organizations, docker_requests, token_context)


def create_achilles_docker_request(study, image_repo: str) -> DockerRequest:
    image_name = "achilles"
    image_name_tag = f"{image_repo}/distributed-analytics/{image_name}:1.0.1"
    env_vars = get_default_env_vars()
    script_version = find_script_version(study, image_name)
    if script_version:
        image_name_tag = script_version.get("imageNameTag")
        env_vars["SCRIPT_UUID"] = script_version.get("uuid")
    logging.info(f"Achilles image: {image_name_tag}")
    return DockerRequest(name=image_name,
                         description="Automated Characterization of Health Information at Large-scale Longitudinal Evidence Systems (ACHILLES)",
                         image_name_tag=image_name_tag,
                         env_vars=env_vars,
                         volumes=get_default_volume_mappings())


def create_analysis_table_generator_docker_request(study, image_repo: str) -> DockerRequest:
    image_name = "analysis-table-generator"
    image_name_tag = f"{image_repo}/distributed-analytics/{image_name}:1.0.1"
    env_vars = get_default_env_vars()
    script_version = find_script_version(study, image_name)
    if script_version:
        image_name_tag = script_version.get("imageNameTag")
        env_vars["SCRIPT_UUID"] = script_version.get("uuid")
    logging.info(f"Analysis table generation image: {image_name_tag}")
    return DockerRequest(name=image_name,
                         description="Generate an analysis table based on OMOP CDM",
                         image_name_tag=image_name_tag,
                         env_vars=env_vars,
                         volumes=get_default_volume_mappings())


def create_data_quality_dashboard_docker_request(study, image_repo: str) -> DockerRequest:
    image_name = "data-quality-dashboard"
    image_name_tag = f"{image_repo}/distributed-analytics/{image_name}:2.0.14"
    env_vars = get_default_env_vars()
    script_version = find_script_version(study, image_name)
    if script_version:
        image_name_tag = script_version.get("imageNameTag")
        env_vars["SCRIPT_UUID"] = script_version.get("uuid")
    logging.info(f"DQD image: {image_name_tag}")
    return DockerRequest(name=image_name,
                         description="Assess the quality of the OMOP CDM mappings",
                         image_name_tag=image_name_tag,
                         env_vars=env_vars,
                         volumes=get_default_volume_mappings())


def create_data_profiler_docker_request(study, image_repo: str) -> DockerRequest:
    image_name = "data-profiler"
    image_name_tag = f"{image_repo}/distributed-analytics/{image_name}:1.0.1"
    env_vars = get_default_env_vars()
    script_version = find_script_version(study, image_name)
    if script_version:
        image_name_tag = script_version.get("imageNameTag")
        env_vars["SCRIPT_UUID"] = script_version.get("uuid")
    logging.info(f"Data profiler image: {image_name_tag}")
    return DockerRequest(name=image_name,
                         description="Run data profiler",
                         image_name_tag=image_name_tag,
                         env_vars=env_vars,
                         volumes=get_default_volume_mappings())


def get_default_env_vars():
    return {"THERAPEUTIC_AREA": "HONEUR"}


def get_default_volume_mappings():
    return {"shared": "/var/lib/shared"}


def find_script_version(study, image_name):
    if not study or not study.get("scripts"):
        return None
    script_version = None
    for s in study.get("scripts"):
        if not s or not s.get("scriptVersions"): continue
        for sv in s.get("scriptVersions"):
            if sv and sv.get("createdDate") and sv.get("imageNameTag") and image_name in sv.get("imageNameTag") \
                    and (not script_version or script_version.get("createdDate") < sv.get("createdDate")):
                script_version = sv
    return script_version
