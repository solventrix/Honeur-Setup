import logging
from enum import Enum


class Environment(Enum):
    """
    Reference for a HONEUR, resp. PHederation PRD, UAT or DEV installation
    Provides the correct API URLs for each of the environments
    """

    HONEUR = "HONEUR"
    HONEUR_UAT = "HONEUR_UAT"
    HONEUR_DEV = "HONEUR_DEV"
    HONEUR_DEV_LOCAL = "HONEUR_DEV_LOCAL"

    PHEDERATION = "PHEDERATION"
    PHEDERATION_UAT = "PHEDERATION_UAT"
    PHEDERATION_DEV = "PHEDERATION_DEV"

    def get_hss_api_url(environment):
        """Return the URL of the HONEUR Storage Service (HSS) API for the given environment"""
        if Environment.HONEUR == environment:
            return "https://storage.honeur.org/api"
        elif Environment.HONEUR_UAT == environment:
            return "https://storage-uat.honeur.org/api"
        elif Environment.HONEUR_DEV == environment:
            return "https://storage-dev.honeur.org/api"
        elif Environment.HONEUR_DEV_LOCAL == environment:
            return "https://storage-local.honeur.org/api"
        elif Environment.PHEDERATION == environment:
            return "https://storage.phederation.org/api"
        elif Environment.PHEDERATION_UAT == environment:
            return "https://storage-uat.phederation.org/api"
        elif Environment.PHEDERATION_DEV == environment:
            return "https://storage-dev.phederation.org/api"
        else:
            logging.warning("Unsupported environment: {}".format(environment))

    def get_login_api_url(environment):
        """Return the URL of the login API for the given environment"""
        return Environment.get_hss_api_url(environment) + "/login"

    def get_catalogue_api_url(environment):
        """Return the URL of the Catalogue Service API for the given environment"""
        if Environment.HONEUR == environment:
            return "https://catalogue.honeur.org/api"
        elif Environment.HONEUR_UAT == environment:
            return "https://catalogue-uat.honeur.org/api"
        elif Environment.HONEUR_DEV == environment:
            return "https://catalogue-dev.honeur.org/api"
        elif Environment.HONEUR_DEV_LOCAL == environment:
            return "https://catalogue-local.honeur.org/api"
        elif Environment.PHEDERATION == environment:
            return "https://catalogue.honeur.org/api"
        elif Environment.PHEDERATION_UAT == environment:
            return "https://catalogue-uat.honeur.org/api"
        elif Environment.PHEDERATION_DEV == environment:
            return "https://catalogue-dev.honeur.org/api"
