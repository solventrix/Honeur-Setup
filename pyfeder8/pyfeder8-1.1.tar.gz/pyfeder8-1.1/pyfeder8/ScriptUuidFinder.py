import os, json
from pathlib import Path


def find_script_uuid_in_zeppelin(z):
    return z.get("script_uuid")


def find_script_uuid_in_metadata():
    script_metadata_filename = _find_script_metadata_file()
    with open(script_metadata_filename,'r') as script_metadata_file:
        metadata = json.load(script_metadata_file)
        return metadata['script_uuid']


def _find_script_metadata_file():
    PARENT_DIR = os.path.dirname(os.path.abspath(__file__))
    ROOT_DIR = PARENT_DIR[0:PARENT_DIR.rindex('/')]
    for path in Path(ROOT_DIR).rglob('metadata.json'):
        return path.name



