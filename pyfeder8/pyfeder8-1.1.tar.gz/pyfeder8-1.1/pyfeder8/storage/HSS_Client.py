from pyfeder8.GenericRestClient import *
from pyfeder8.TokenContext import TokenContext


class HSS_Client(GenericRestClient):
    """
    A Python client to call the REST API of the HONEUR Storage Service (HSS)
    The environment determines the environment (PRD, UAT, DEV) to connect to
    """
    def __init__(self, environment: Environment, verify_tls: bool = True):
        super().__init__(environment, verify_tls)

    @property
    def environment(self):
        return self._environment

    @property
    def hss_api_url(self):
        return self._hss_api_url

    @property
    def login_api_url(self):
        return self._login_api_url

    @property
    def catalogue_api_url(self):
        return self._catalogue_api_url

    def download_file(self, uuid: str, token_context: TokenContext = None):
        """Downloads the file with the given UUID"""
        request_url = self._hss_api_url + "/" + uuid
        response = self._do_get_request(request_url, token_context)
        return HSS_Client._handle_file_response(response)

    def delete_file(self, uuid, token_context: TokenContext = None):
        """Deletes the file with the given UUID"""
        request_url = self._hss_api_url + "/" + uuid
        response = self._do_delete_request(request_url, token_context)
        if response.status_code != requests.codes.no_content:
            logging.error("File with UUID '{}' could not be deleted!".format(uuid))
            return False
        return True

    def save_data_file(self, file, token_context: TokenContext = None):
        """Saves the given file in the data folder and returns the UUID of the saved file"""
        request_url = self._hss_api_url + "/data"
        return self._save_file(request_url, file, token_context)

    def list_data_files(self, token_context: TokenContext = None):
        """Returns a list of all files in the data folder"""
        request_url = self._hss_api_url + "/data/list"
        return self._get_json(request_url, token_context)

    def list_studies(self, token_context: TokenContext = None):
        """Returns a list of all studies from the Study Catalogue"""
        request_url = self.catalogue_api_url + "/studies"
        response = self._do_get_request(request_url, token_context)
        return self._handle_json_response(response)

    def list_study_files(self, study_id, token_context: TokenContext = None):
        """Returns a list of all files for the study with the given Study ID"""
        request_url = "{}/study-files/list/{}".format(self.hss_api_url, study_id)
        return self._get_json(request_url, token_context)

    def save_notebook_results(self, notebook_uuid, file, zip_file=None, token_context: TokenContext = None):
        """Saves the result files for the notebook with the given UUID"""
        request_url = "{}/notebook-results/{}".format(self.hss_api_url, notebook_uuid)
        if file:
            file_to_save = file
        elif zip_file:
            file_to_save = zip_file
        else:
            logging.warning("Missing file input parameter")
            return
        return self._save_file(request_url, file_to_save, token_context)

    def list_notebook_results(self, study_id, external_notebook_uuid=None, notebook_uuid=None,
                              latest_version_only=False, reverse_order=False, token_context: TokenContext = None):
        """
        Returns a list of results for the study with the given Study ID,
        additional criteria like the UUID of the notebook / shared notebook can be specified to further filter the list.
        The latest_version_only flag can be used to only return the latest version of the results, the reverse_order
        flag can be used to reverse the default order of the list
        """
        request_url = self._build_list_notebook_results_request_url(study_id,
                                                                    external_notebook_uuid, notebook_uuid,
                                                                    latest_version_only, reverse_order)
        return self._get_json(request_url, token_context)

    def _build_list_notebook_results_request_url(self, study_id, external_notebook_uuid=None, notebook_uuid=None,
                                                 latest_version_only=False, reverse_order=False):
        request_url = "{}/notebook-results/list/{}".format(self.hss_api_url, study_id)
        if external_notebook_uuid: request_url += "/" + external_notebook_uuid
        if notebook_uuid: request_url += "/" + notebook_uuid
        param_separator = "?"
        if latest_version_only:
            request_url += param_separator + "latestVersionOnly=true"
            param_separator = "&"
        if reverse_order:
            request_url += param_separator + "reverseOrder=true"
        return request_url

    def save_study_document(self, study_id, document_uuid, file, token_context: TokenContext = None):
        """Saves the given file in the documents folder and study sub folder and assigns the given UUID to it"""
        request_url = "{}/documents/{}/{}".format(self.hss_api_url, study_id, document_uuid)
        return self._save_file(request_url, file, token_context)

    def list_study_documents(self, study_id, token_context: TokenContext = None):
        """Returns a list of document files that belong to the study with the given ID"""
        request_url = "{}/documents/list/{}".format(self.hss_api_url, study_id)
        return self._get_json(request_url, token_context)

    def list_study_notebooks(self, study_id, external_notebook_uuid=None, token_context: TokenContext = None):
        """
        Returns a list of all shared notebooks of the study with the given Study ID.
        The UUID of the Zepl notebook can be specified to filter the list of notebooks
        """
        request_url = "{}/notebooks/list/{}".format(self.hss_api_url, study_id)
        if external_notebook_uuid: request_url += "/" + external_notebook_uuid
        return self._get_json(request_url, token_context)
