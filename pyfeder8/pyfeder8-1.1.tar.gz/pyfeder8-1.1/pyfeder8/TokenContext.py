class TokenContext:
    """
    Represents a JWT token and its associated fingerprint
    """

    def __init__(self, token, fingerprint):
        self._token = token
        self._fingerprint = fingerprint

    @property
    def token(self):
        return self._token

    @property
    def fingerprint(self):
        return self._fingerprint

    def __str__(self):
        return "token={}, fingerprint={}".format(self.token, self._fingerprint)
