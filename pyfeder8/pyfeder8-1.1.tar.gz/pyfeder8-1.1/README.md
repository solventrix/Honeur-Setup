# pyfeder8
Federate API in Python

## How to build
- Open the sphinx folder and run `make html` to generate the documentation in HTML format
- Run `python3 setup.py install` to install the pyfeder8 code as Python package
- Run `python3 setup.py sdist` to create a source distribution

## How to install 
- Make sure the dependencies of the pyfeder8 package are installed:
    - `pip3 install requests`
    - `pip3 install uuid`
    - `pip3 install sqlalchemy`
    - `pip3 install keyring`
- Option 1: install pyfeder8 directly from its private Github repository:
    - `pip install git+https://github.com/solventrix/pyfeder8`
- Option 2: Install pyfeder8 from the public HONEUR repository:
    - `pip3 install https://github.com/solventrix/Honeur-Setup/raw/master/pyfeder8/pyfeder8-1.0.tar.gz`
    
## How to use
```python
from pyfeder8.Environment import Environment
from pyfeder8.storage.HSS_Client import HSS_Client
from pyfeder8 import TokenContextProvider

environment = Environment.HONEUR
token_context = TokenContextProvider.get_token_context(environment, <your-username>, <your_password>)
hss_client = HSS_Client(environment)
data_files = hss_client.list_data_files(token_context)
```

 
 

