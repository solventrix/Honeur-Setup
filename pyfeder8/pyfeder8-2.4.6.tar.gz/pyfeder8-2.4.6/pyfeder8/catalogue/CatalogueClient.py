import json
from io import StringIO

import pandas as pd
from pandas import DataFrame

from pyfeder8.GenericRestClient import *
from pyfeder8.TokenContext import TokenContext
from pyfeder8.config.Configuration import Configuration


class CatalogueClient(GenericRestClient):
    """
    A Python client to call the REST API of the Feder8 Catalogue Service
    The configuration determines the domain and environment to connect to
    """
    def __init__(self, configuration: Configuration):
        super().__init__(configuration)

    @property
    def catalogue_api_url(self):
        return self._configuration.central_service_connection_details.catalogue_api_url

    def list_studies(self, token_context: TokenContext = None):
        """Retrieves a list of all studies from the Study Catalogue"""
        request_url = f"{self.catalogue_api_url}/studies"
        return self._get_json(request_url, token_context)

    def get_study_by_name(self, study_name: str, token_context: TokenContext = None):
        studies = self.list_studies(token_context)
        study = None
        for s in studies:
            if s.get("name") == study_name:
                study = s
                break
        if study:
            return self.get_study(study.get("id"), token_context)
        return study

    def get_study(self, study_id: int, token_context: TokenContext = None):
        """Retrieves the study with the given ID from the Study Catalogue"""
        request_url = f"{self.catalogue_api_url}/studies/{str(study_id)}"
        return self._get_json(request_url, token_context)

    def save_script_result(self, script_version_uuid, result_file, token_context: TokenContext = None):
        """Saves the given result for the script with the given UUID"""
        request_url = f"{self.catalogue_api_url}/scripts/{script_version_uuid}/results"
        return self._save_file(request_url, result_file, token_context)

    def save_dataframe_as_csv_script_result(self, script_version_uuid, df: DataFrame, filename: str, token_context: TokenContext = None):
        """Saves the given data frame as CSV file for the script with the given UUID"""
        df.to_csv(filename, index=False)
        with open(filename) as csv:
            return self.save_script_result(script_version_uuid, csv, token_context)

    def save_dataframe_as_json_script_result(self, script_version_uuid, df: DataFrame, filename: str, token_context: TokenContext = None):
        """Saves the given data frame as JSON file for the script with the given UUID"""
        df.to_json(filename, orient='columns')
        with open(filename) as json_file:
            return self.save_script_result(script_version_uuid, json_file, token_context)

    def save_dictionary_as_json_script_result(self, script_version_uuid, dd: dict, filename: str, token_context: TokenContext = None):
        """Saves the given data dictionary as JSON file for the script with the given UUID"""
        with open(filename, "w") as json_file:
            json.dump(dd, json_file)
        with open(filename) as json_file:
            return self.save_script_result(script_version_uuid, json_file, token_context)

    def save_local_metadata(self, metadata: dict, filename: str, token_context: TokenContext = None):
        """Saves the given metadata file"""
        request_url = f"{self.catalogue_api_url}/metadata"
        with open(filename, "w") as metadata_file:
            json.dump(metadata, metadata_file)
        with open(filename) as metadata_file:
            return self._save_file(request_url, metadata_file, token_context)

    def get_latest_local_metadata(self, token_context: TokenContext = None):
        """Retrieves the latest available local metadata for all sites"""
        request_url = f"{self.catalogue_api_url}/metadata/latest"
        return self._get_json(request_url, token_context)

    def list_script_results(self, study_id: int, script_uuid=None, script_version_uuid=None,
                            latest_version_only=False, token_context: TokenContext = None):
        """Retrieves a list of script results for the given study"""
        request_url = f"{self.catalogue_api_url}/studies/{study_id}/script-results"
        param_separator = "?"
        if script_uuid:
            request_url += param_separator + "scriptUuid=" + script_uuid
            param_separator = "&"
        if script_version_uuid:
            request_url += param_separator + "scriptVersionUuid=" + script_version_uuid
            param_separator = "&"
        if latest_version_only:
            request_url += param_separator + "latestVersionOnly=true"
        return self._get_json(request_url, token_context)

    def list_files(self, file_key_prefix: str, token_context: TokenContext = None):
        """Returns a list of files whose file key matches the given file key prefix"""
        request_url = f"{self.catalogue_api_url}/files/list?fileKeyPrefix={file_key_prefix}"
        return self._get_json(request_url, token_context)

    def download_file_with_key(self, file_key: str, token_context: TokenContext = None):
        """Downloads the file with the given file key"""
        request_url = f"{self.catalogue_api_url}/files?fileKey={file_key}"
        response = self._do_get_request(request_url, token_context)
        return CatalogueClient._handle_file_response(response)

    def download_file_with_key_as_dataframe(self, file_key: str, token_context: TokenContext = None):
        """Downloads the file with the given file key and returns it as pandas DataFrame"""
        file_content = self.download_file_with_key(file_key, token_context)
        file_content_str_io = StringIO(str(file_content, 'utf-8'))
        if file_key.lower().endswith(".csv"):
            return pd.read_csv(file_content_str_io)
        elif file_key.lower().endswith(".json"):
            return pd.read_json(file_content_str_io, orient='columns')
        else:
            raise Exception(f'File with key {file_key} cannot be converted to a pandas DataFrame!')

    def download_file_with_key_as_dictionary(self, file_key: str, token_context: TokenContext = None):
        """Downloads the file with the given file key and returns it as dictionary"""
        file_content = self.download_file_with_key(file_key, token_context)
        return json.loads(file_content.decode('utf-8'))
