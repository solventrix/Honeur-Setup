from pyfeder8.Feder8Utils import *
from pyfeder8.ScriptUuidFinder import *
from pyfeder8.config.Configuration import Configuration
from pyfeder8.task_manager.TaskManagerClient import TaskManagerClient


class Feder8Client:
    """
    A helper service to interact with the Feder8 platform
    The configuration provides the context in which the analysis is performed
    """
    def __init__(self, configuration: Configuration):
        self.configuration = configuration
        self.task_manager_client = TaskManagerClient(configuration)

    def save_result(self, result_file, zeppelin_context=None):
        task_execution_uuid = find_task_execution_uuid(zeppelin_context)
        if task_execution_uuid:
            return self.task_manager_client.save_task_execution_result(task_execution_uuid,
                                                                       result_file)
        shared_script_version_uuid = find_shared_script_version_uuid(zeppelin_context)
        if shared_script_version_uuid:
            return self.task_manager_client.save_shared_script_version_result(shared_script_version_uuid,
                                                                              self.configuration.name,
                                                                              result_file)
        logging.warning("Result cannot be saved! Task execution UUID and shared script version UUID are missing")

    def save_dataframe_as_csv_result(self, df: DataFrame, filename: str, zeppelin_context=None):
        """Saves the given data frame as CSV file for the script with the given UUID"""
        df.to_csv(filename, index=False)
        with open(filename) as csv:
            return self.save_result(csv, zeppelin_context)

    def save_dataframe_as_json_result(self, df: DataFrame, filename: str, zeppelin_context=None):
        """Saves the given data frame as JSON file for the script with the given UUID"""
        df.to_json(filename, orient='columns')
        with open(filename) as json_file:
            return self.save_result(json_file, zeppelin_context)

    def save_dictionary_as_json_result(self, dd: dict, filename: str, zeppelin_context=None):
        """Saves the given data dictionary as JSON file for the script with the given UUID"""
        with open(filename, "w") as json_file:
            json.dump(dd, json_file)
        with open(filename) as json_file:
            return self.save_result(json_file, zeppelin_context)
