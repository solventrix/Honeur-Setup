class CentralServiceConnectionDetails:

    def __init__(self, oauth_token_uri, oauth_client_id, oauth_client_secret,
                 image_repo, image_repo_username, image_repo_key, catalogue_api_url, distributed_analytics_api_url,
                 verify_tls = True):
        self._oauth_token_uri = oauth_token_uri
        self._oauth_client_id = oauth_client_id
        self._oauth_client_secret = oauth_client_secret
        self._image_repo = image_repo
        self._image_repo_username = image_repo_username
        self._image_repo_key = image_repo_key
        self._catalogue_api_url = catalogue_api_url
        self._distributed_analytics_api_url = distributed_analytics_api_url,
        self._username = None
        self._password = None
        self._verify_tls = verify_tls

    @property
    def oauth_token_uri(self):
        return self._oauth_token_uri

    @property
    def oauth_client_id(self):
        return self._oauth_client_id

    @property
    def oauth_client_secret(self):
        return self._oauth_client_secret

    @property
    def image_repo(self):
        return self._image_repo

    @property
    def image_repo_username(self):
        return self._image_repo_username

    @property
    def image_repo_key(self):
        return self._image_repo_key

    @property
    def catalogue_api_url(self):
        return self._catalogue_api_url

    @property
    def distributed_analytics_api_url(self):
        return ''.join(self._distributed_analytics_api_url)

    @property
    def username(self):
        return self._username

    @username.setter
    def username(self, username):
        self._username = username

    @property
    def password(self):
        return self._password

    @password.setter
    def password(self, password):
        self._password = password

    @property
    def verify_tls(self):
        return self._verify_tls

    @verify_tls.setter
    def verify_tls(self, verify_tls):
        self._verify_tls = verify_tls
