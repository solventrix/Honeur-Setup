import requests
import logging

from enum import Enum
from pyfeder8 import TokenContextProvider
from pyfeder8.Environment import Environment
from pyfeder8.TokenContext import TokenContext


class GenericRestClient:

    """
    A generic Python client to call the REST API of a HONEUR Service
    The environment determines the environment (PRD, UAT, DEV) to connect to
    """
    def __init__(self, environment: Environment, verify_tls: bool = True):
        self._environment = environment
        self._verify_tls = verify_tls
        self._hss_api_url = Environment.get_hss_api_url(environment)
        self._login_api_url = Environment.get_login_api_url(environment)
        self._catalogue_api_url = Environment.get_catalogue_api_url(environment)

    @property
    def environment(self):
        return self._environment

    @property
    def verify_tls(self):
        return self._verify_tls

    @property
    def hss_api_url(self):
        return self._hss_api_url

    @property
    def login_api_url(self):
        return self._login_api_url

    @property
    def catalogue_api_url(self):
        return self._catalogue_api_url

    def _get_json(self, request_url, token_context: TokenContext = None):
        response = self._do_get_request(request_url, token_context)
        return GenericRestClient._handle_json_response(response)

    def _save_file(self, request_url, file, token_context=None):
        files = {"file": file}
        response = self._do_request(request_url, RequestMethod.POST, token_context, files)
        return self._handle_save_response(response)

    def _do_get_request(self, request_url, token_context=None):
        return self._do_request(request_url, RequestMethod.GET, token_context)

    def _do_delete_request(self, request_url, token_context=None):
        return self._do_request(request_url, RequestMethod.DELETE, token_context)

    def _do_request(self, request_url, request_method, token_context=None, files=None):
        if not token_context: token_context = self._get_token_context()
        headers = {"token": token_context.token, "userFingerprint": token_context.fingerprint}
        cookies = {"userFingerprint": token_context.fingerprint}
        try:
            if RequestMethod.GET == request_method:
                return requests.get(request_url, headers=headers, cookies=cookies, verify=self.verify_tls)
            elif RequestMethod.POST == request_method:
                return requests.post(request_url, files=files, headers=headers, cookies=cookies, verify=self.verify_tls)
            elif RequestMethod.DELETE == request_method:
                return requests.delete(request_url, headers=headers, cookies=cookies, verify=self.verify_tls)
            else:
                logging.warning("Request method {} not supported!".format(request_method))
        except Exception as e:
            logging.error("{} request {} failed!".format(request_method, request_url), e)

    @staticmethod
    def _handle_file_response(response: requests.Response) -> bytes:
        if response.status_code == requests.codes.ok:
            return response.content
        else:
            logging.warning("Error response status code: {}".format(response.status_code))
            response.raise_for_status()

    @staticmethod
    def _handle_json_response(response: requests.Response):
        if response.status_code == requests.codes.ok:
            return response.json()
        else:
            logging.warning("Error response status code: {}".format(response.status_code))
            response.raise_for_status()

    @staticmethod
    def _handle_save_response(response: requests.Response):
        if response.status_code == 201:
            location = str(response.headers['Location'])
            logging.info("Location of saved file: {}".format(location))
            return GenericRestClient.parse_uuid_from_location(location)
        else:
            logging.error("The file could not be saved, status code: {}!".format(response.status_code))
            response.raise_for_status()

    @staticmethod
    def parse_uuid_from_location(location):
        return location[location.rindex("/")+1:]

    def _get_token_context(self) -> TokenContext:
        return TokenContextProvider.find_token_context(self.environment)


class RequestMethod(Enum):
    GET = "Get"
    POST = "Post"
    DELETE = "Delete"