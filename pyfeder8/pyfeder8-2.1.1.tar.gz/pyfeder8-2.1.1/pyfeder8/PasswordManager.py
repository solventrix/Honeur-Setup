import keyring
from pyfeder8.Environment import Environment

USER_NAME_KEY = "username"


def save_username_password(environment: Environment, username: str, password: str):
    """
    Stores the given username and password for the given environment
    in the password store of the OS that is running this code
    """
    keyring.set_password(environment.value, USER_NAME_KEY, username)
    keyring.set_password(environment.value, username, password)


def get_password(environment: Environment, username: str):
    """
    Retrieves the password for the given user and environment
    from the password store of the OS that is running this code
    """
    return keyring.get_password(environment.value, username)


def get_credential(environment: Environment):
    """Retrieves the username and password credentials for the given environment
    from the password store of the OS that is running this code
    Only 1 username per environment is when this function is used!
    """
    username = keyring.get_password(environment.value, USER_NAME_KEY)
    return keyring.get_credential(environment.value, username)
