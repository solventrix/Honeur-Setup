
/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000001082
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001082
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001082
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000001082
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001082
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001082
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001082
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000001102
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001102
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001102
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000001102
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001102
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001102
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001102
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000017
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000017
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000017
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000017
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000017
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000017
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000017
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000019
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000019
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000019
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000019
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000019
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000019
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000019
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000022
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000022
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000022
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000022
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000022
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000022
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000022
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000588
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000588
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000588
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000588
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000588
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000588
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000588
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000589
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000589
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000589
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000589
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000589
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000589
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000589
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000590
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000590
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000590
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000590
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000590
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000590
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000590
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000591
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000591
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000591
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000591
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000591
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000591
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000591
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000592
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000592
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000592
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000592
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000592
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000592
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000592
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000593
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000593
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000593
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000593
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000593
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000593
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000593
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000594
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000594
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000594
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000594
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000594
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000594
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000594
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000626
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000626
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000626
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000626
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000626
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000626
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000626
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000633
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000633
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000633
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000633
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000633
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000633
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000633
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000672
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000672
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000672
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000672
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000672
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000672
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000672
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000728
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000728
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000728
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000728
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000728
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000728
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000728
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000919
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000919
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000919
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000919
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000919
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000919
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000919
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000970
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000970
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000970
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000970
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000970
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000970
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000970
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000973
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000973
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000973
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000973
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000973
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000973
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000973
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000987
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000987
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000987
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000987
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000987
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000987
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000987
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000988
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000988
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000988
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000988
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000988
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000988
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000988
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000994
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000994
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000994
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000994
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000994
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000994
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000994
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000000995
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000995
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000995
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000000995
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000995
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000000995
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000000995
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000001021
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001021
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001021
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000001021
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001021
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001021
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001021
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000001026
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001026
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001026
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000001026
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001026
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001026
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001026
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3046299
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3046299
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3046299
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3046299
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3046299
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3046299
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3046299
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3018199
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3018199
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3018199
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3018199
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3018199
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3018199
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3018199
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3004809
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3004809
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3004809
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3004809
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3004809
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3004809
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3004809
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000001076
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001076
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001076
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000001076
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001076
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001076
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001076
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000001078
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001078
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001078
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000001078
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001078
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001078
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001078
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000001077
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001077
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001077
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000001077
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001077
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001077
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001077
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3019183
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3019183
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3019183
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3019183
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3019183
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3019183
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3019183
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =   42527796
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   42527796
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   42527796
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =   42527796
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   42527796
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   42527796
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   42527796
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3051825
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3051825
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3051825
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3051825
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3051825
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3051825
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3051825
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3017250
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3017250
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3017250
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3017250
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3017250
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3017250
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3017250
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000001111
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001111
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001111
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000001111
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001111
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001111
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001111
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000001105
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001105
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001105
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000001105
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001105
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001105
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001105
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000001112
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001112
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001112
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000001112
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001112
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001112
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001112
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000001106
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001106
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001106
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000001106
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001106
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001106
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001106
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000001113
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001113
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001113
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000001113
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001113
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001113
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001113
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000001107
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001107
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001107
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000001107
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001107
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001107
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001107
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000001080
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001080
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001080
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000001080
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001080
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001080
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001080
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000001096
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001096
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001096
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000001096
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001096
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001096
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001096
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId = 2000001098
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001098
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001098
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id = 2000001098
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001098
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id = 2000001098
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 = 2000001098
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3026361
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3026361
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3026361
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3026361
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3026361
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3026361
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3026361
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3009542
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3009542
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3009542
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3009542
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3009542
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3009542
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3009542
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3000963
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3000963
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3000963
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3000963
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3000963
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3000963
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3000963
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3007164
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3007164
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3007164
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3007164
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3007164
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3007164
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3007164
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =   44816761
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816761
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816761
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =   44816761
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816761
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816761
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816761
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =   44816756
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816756
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816756
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =   44816756
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816756
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816756
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816756
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =   44816757
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816757
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816757
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =   44816757
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816757
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816757
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816757
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3005719
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3005719
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3005719
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3005719
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3005719
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3005719
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3005719
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =   44816760
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816760
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816760
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =   44816760
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816760
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816760
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816760
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =   44816754
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816754
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816754
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =   44816754
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816754
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816754
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816754
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =   44816755
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816755
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816755
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =   44816755
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816755
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816755
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816755
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3028026
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3028026
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3028026
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3028026
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3028026
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3028026
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3028026
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =   44816762
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816762
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816762
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =   44816762
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816762
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816762
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816762
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =   44816758
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816758
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816758
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =   44816758
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816758
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816758
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816758
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =   44816759
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816759
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816759
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =   44816759
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816759
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =   44816759
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =   44816759
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3007778
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3007778
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3007778
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3007778
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3007778
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3007778
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3007778
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3053209
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3053209
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3053209
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3053209
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3053209
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3053209
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3053209
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3031501
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031501
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031501
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3031501
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031501
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031501
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031501
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3034860
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3034860
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3034860
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3034860
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3034860
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3034860
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3034860
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3047169
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3047169
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3047169
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3047169
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3047169
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3047169
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3047169
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3032372
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3032372
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3032372
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3032372
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3032372
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3032372
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3032372
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3010813
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3010813
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3010813
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3010813
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3010813
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3010813
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3010813
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3019198
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3019198
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3019198
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3019198
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3019198
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3019198
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3019198
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3031745
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031745
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031745
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3031745
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031745
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031745
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031745
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3007357
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3007357
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3007357
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3007357
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3007357
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3007357
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3007357
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3035941
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3035941
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3035941
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3035941
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3035941
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3035941
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3035941
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3024731
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3024731
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3024731
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3024731
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3024731
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3024731
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3024731
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3032340
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3032340
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3032340
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3032340
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3032340
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3032340
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3032340
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3032330
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3032330
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3032330
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3032330
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3032330
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3032330
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3032330
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3031747
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031747
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031747
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3031747
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031747
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031747
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031747
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3019069
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3019069
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3019069
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3019069
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3019069
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3019069
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3019069
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3014695
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3014695
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3014695
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3014695
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3014695
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3014695
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3014695
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3021120
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3021120
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3021120
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3021120
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3021120
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3021120
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3021120
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3017732
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3017732
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3017732
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3017732
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3017732
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3017732
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3017732
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3032942
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3032942
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3032942
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3032942
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3032942
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3032942
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3032942
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3032320
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3032320
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3032320
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3032320
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3032320
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3032320
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3032320
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3007461
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3007461
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3007461
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3007461
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3007461
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3007461
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3007461
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3031114
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031114
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031114
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3031114
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031114
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031114
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031114
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3036416
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3036416
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3036416
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3036416
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3036416
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3036416
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3036416
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3015586
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3015586
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3015586
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3015586
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3015586
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3015586
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3015586
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3031741
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031741
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031741
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3031741
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031741
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031741
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031741
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3001552
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3001552
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3001552
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3001552
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3001552
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3001552
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3001552
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3031793
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031793
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031793
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3031793
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031793
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031793
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031793
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3031772
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031772
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031772
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3031772
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031772
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031772
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031772
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3031805
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031805
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031805
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3031805
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031805
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031805
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031805
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3017354
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3017354
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3017354
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3017354
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3017354
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3017354
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3017354
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3001604
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3001604
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3001604
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3001604
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3001604
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3001604
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3001604
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3018718
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3018718
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3018718
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3018718
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3018718
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3018718
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3018718
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3031781
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031781
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031781
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3031781
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031781
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3031781
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3031781
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3018010
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3018010
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3018010
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3018010
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3018010
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3018010
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3018010
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3000192
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3000192
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3000192
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3000192
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3000192
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3000192
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3000192
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;

/*********
CONCEPT LEVEL check:
IS RIGHT DOMAIN: checks for a given concept_id if it's reported in the right domain. 
Can only be used to check observation vs measurement. 

Parameters used in this template:
cdmDatabaseSchema = cdm
vocabDatabaseSchema = cdm
cdmTableName = measurement
cdmFieldName = measurement_concept_id
conceptId =    3010997
cdmValueFieldName = unit_concept_id
**********/


SELECT num_violated_rows, CASE WHEN denominator.num_rows = 0 THEN 0 ELSE 1.0*num_violated_rows/denominator.num_rows END AS pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
FROM
(
	SELECT COUNT(*) AS num_violated_rows
	FROM
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3010997
        and unit_concept_id not in 
        (
            select concept_id_2 
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3010997
            and relation.relationship_id = 'Has unit'
        )
        and unit_concept_id is not null
        and exists 
        (
            select * from cdm.measurement
            where measurement_concept_id =    3010997
        )
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3010997
            and relation.relationship_id = 'Has unit'
        )
	) violated_rows
) violated_row_count,
( 
	SELECT COUNT(*) AS num_rows
	FROM 
	(
		SELECT cdmTable.* 
		FROM cdm.measurement cdmTable
		WHERE cdmTable.measurement_concept_id =    3010997
        and exists 
        (
            select *
            from cdm.concept_relationship relation
            WHERE relation.concept_id_1 =    3010997
            and relation.relationship_id = 'Has unit'
        )
	) as results_table	
) denominator
;
