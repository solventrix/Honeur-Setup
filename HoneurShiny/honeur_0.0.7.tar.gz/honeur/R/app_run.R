# Project: honeur
#
# Author: hbossier
###############################################################################


#' Run the shiny application
#' @param port which port to run on
#' @param installDependencies boolean, whether to first install packages listed
#' in the Suggests field of DESCRIPTION; default value is FALSE
#' @param ... further arguments that can be passed to \code{\link[shiny]{runApp}}
#' @return no return value
#' @importFrom shiny runApp
#' @importFrom devtools install_github dev_package_deps
#' @export
runShiny <- function(port = 3838, installDependencies = FALSE, ...){
  
  # (1) Install all suggested R packages (see DESCRIPTION)
  if (installDependencies) {
    
    ## (a) CRAN packages
    stats::update(dev_package_deps(pkgdir = system.file("app", package = "honeur"), 
            dependencies = "Suggests"))
    
  }
  
  # (2) Run the application
  ldots <- list(...)
  
  if (!is.null(ldots$appDir))
    runApp(...) else
    runApp(appDir = system.file("app", package = "honeur"), port = port, ...)
  
}

