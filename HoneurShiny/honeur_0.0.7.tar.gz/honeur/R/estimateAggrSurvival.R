# Project: honeur
#
# Description: function to estimate aggregated survival data
# Author: hbossier
###############################################################################

# Under development! Function now does for loop over all rows, which is cumbersome...

#' Dev code to estimate survival
#' 
#' @author hbossier
devCodeEstimateSurvival <- function(){
  
  ################################################################################
  #### CODE used to temp create the survival
  createSurvival <- FALSE
  if(createSurvival){
    aggregatedRes <- lapply(readRDS("/home/hbossier/git/honeur_jnj/honeur/inst/extdata/03_dataIntermediate/resQ1/survivalEMMOS_CMG_old.rds"), 
        function(x){
          filter(x, typeSite == 'aggregated') %>%
              select(- SEQuan, -se)
        })
    indSites <- split(allData[['KMdataDF']], factor(allData[['KMdataDF']]$variable))
    
    combData <- list()
    for(iList in 1:length(indSites)){
      toAdd <- bind_rows(select(indSites[[iList]] %>% rename(typeSite = site), 
              names(aggregatedRes[[iList]])),
          aggregatedRes[[iList]]
      )
      combData[[iList]] <- toAdd
    }
    names(combData) <- names(aggregatedRes)
    saveRDS(combData, "/home/hbossier/git/honeur_jnj/honeur/inst/extdata/03_dataIntermediate/resQ1/survivalEMMOS_CMG.rds")
    
    
    # Test out new function
    
    
    combData <- allData[['KMdataDF']]
    
#' Estimate the survival probability
#' 
#' Main function is \code{calculateSurvival}.
#' This is a wrapper splitting the computations over the 'variable' in the data.
#' 
#' @param aggregatedSurvData data frame with the aggregated survival data
#' @param individualSurvData data frame with the original survival data per site
#' @param alpha the coverage probability of the CI 
#' 
#' @note the individual survival data is only added for plotting purpose.
#' Function is work in progress as it takes a long time to compute rowwise!
#' 
#' @author hbossier
    estimateSurvival <- function(aggregatedSurvData, individualSurvData, alpha = 0.05){
      # First calculate the survival on the aggregated data
      aggrSurvival <- aggregatedKMdata %>% 
          mutate(typeSite = as.character('aggregated')) %>%
          split(.$variable, drop = FALSE) %>%
          lapply(., calculateSurvival, alpha = alpha)
      
      # Which columns will we get from our individual data set?
      if(length(aggrSurvival) > 0){
        colIDs <- match(names(aggrSurvival[[1]]), names(individualSurvData))
      } else {
        stop('Error in estimateSurvival()')
      }
      
      # Prepare original data 
      splitOrigData <- individualSurvData %>%
          select(na.omit(colIDs), site) %>% 
          filter(!is.na(plot)) %>%
          rename(typeSite = site) %>% 
          as_tibble() %>%
          split(.$variable, drop = FALSE)
      
      # Check
      if(!all(names(aggrSurvival) == names(splitOrigData))){
        stop('Splitting the data according to "variable" is not producing the same levels between original and aggregated data.')
      }
      
      # Now bind the data frames
      allData <- lapply(names(aggrSurvival), function(ind){
            bind_rows(aggrSurvival[[ind]], splitOrigData[[ind]])
          })
      names(allData) <- names(aggrSurvival)
      
      # End
      return(allData)
    }
    
#' Calculate current survival
#' 
#' Calculate survival at current time interval. This is not the final estimated 
#' survival as it will be multiplied with survival at previous time interval. 
#' 
#' @param nrisk integer, number of patients at risk at start of time interval
#' @param nevent integer, number of events during time interval
#' @author hbossier
    calcCurSurv <- function(nrisk, nevent){
      (nrisk - nevent)/nrisk
    }
    
#' Calculate quantity
#' 
#' Calculate quantity to be used in variance of point estimate of survival
#' 
#' @param nrisk integer, number of patients at risk at start of time interval
#' @param nevent integer, number of events during time interval
#' @author hbossier
    calcQuanSE <- function(nrisk, nevent){
      nevent/(nrisk*(nrisk - nevent))
    }
    
#' Calculate survival probability with SE
#' 
#' Estimate the survival using summary data (number at risk, 
#' number of events and number of censored events) of non-grouped data.
#' Formula: St = (rt - dt)/rt * S(t - 1).
#' The function is used in conjuction with splitting the data according to 'variable' 
#' found in the data.
#' 
#' The variance is calculated using the Greenwood formula. Note that I exclude
#' the censored observations when calculating the variance (it involves the cumulative sum
#' of a quantity and I assume this is a cumulative sum without the censored observations)
#' 
#' @param data the merged data containing n.risk, n.event, n.censor columns 
#' Note: columns such as surv, upper and lower will be overwritten!
#' @param alpha the coverage probability of the CI
#' @param perc boolean: return survival in percentage (default) or not. 
#' Note survival is rounded to 2 digits. 
#' @param removeNAR boolean: remove the nar = 1 lines (default = TRUE) before starting
#' the calculations.
#' @param sites vector: if provided combine data over the given sites.
#' 
#' @import dplyr
#' 
#' @return Returns the input dataframe with columns added: estimated probability
#' of survival with upper and lower bounds. 
#' 
#' @author hbossier
    calculateSurvival <- function(data, alpha, percentage = TRUE, removeNAR = TRUE, sites = NULL){
      # If provided, filter specific sites
      if(!is.null(sites)){
        data <- filter(data, site %in% sites)
      }
      
      # If true, remove the nar = 1 lines
      if(removeNAR){
        # We want to remove nar = 1, but not remove the first line for each grouped variable
        # as these correspond with survival = 100
        # So when time == 0, we set nar to 2
        data <- mutate(data, nar = ifelse(time == 0, 2, nar))
        # Now remove nar = 1
        data <- filter(data, (is.na(nar) | nar == 2))
      }
      
      # Add new columns to the data with initial vales. 
      # For the first row, we set the values manually
      data <- mutate(data, 
          surv = NA, 
          SEQuan = 0, 
          se = NA, 
          upper = NA, 
          lower = NA)
#      %>%
#      # First row
#      mutate(surv = ifelse(row_number() == 1, 1, surv),
#          SEQuan = ifelse(row_number() == 1, 0, SEQuan),
#          se = ifelse(row_number() == 1, 0, se),
#          upper = ifelse(row_number() == 1, 1, upper),
#          lower = ifelse(row_number() == 1, 1, lower),
#          n.riskCum = cumsum(n.risk),
#          n.eventCum = cumsum(n.event))
      
      # Empty vector which will store survival probabilities (as we use previous values)
      vectSurv <- c(1)
      
      # Which have non censored values?
      IDsNonCen <- data[, 'n.censor'] == 0
      
      # Loop over data, starting from second row
      for(iRow in 1:dim(data)[1]){
        
        # Reset if time = 0
        if(data[iRow, 'time']  == 0){
          # Manually set values
          data[iRow, 'surv'] <- 1
          data[iRow, 'se'] <- 0
          data[iRow, 'upper'] <- 1
          data[iRow, 'lower'] <- 1
          
          # Reset survival vector and current row position for cumulative sum
          #vectSurv <- c(1)
          curRow <- iRow
        } else {
          # Calculate survival: if censorring occures, then survival at t = i equals survival at t = i-1
          # Calculation of standard error: survival*sqrt(cumsum(quantity)), this quantity is obtained using calcQuanSE
          if(pull(data[iRow,], 'n.censor') > 0){
            # Same value when censoring occurs: so going back steps
            surv <- as.numeric(pull(data[(iRow - 1), ], 'surv'))
            SEQuan <- data[(iRow - 1), 'SEQuan']
            SE <- data[(iRow - 1), 'se']
          } else {
            # Otherwise calculate survival and update it
            surv <- as.numeric(calcCurSurv(nrisk = data[iRow, 'n.risk'], nevent = data[iRow, 'n.event']) * pull(data[(iRow - 1), ], 'surv'))
            SEQuan <- calcQuanSE(nrisk = data[iRow, 'n.risk'], nevent = data[iRow, 'n.event'])
            data[iRow, 'SEQuan'] <- SEQuan
            cumSum <- sum(data[IDsNonCen[curRow:iRow],'SEQuan'])
            SE <- as.numeric(surv * sqrt(cumSum))
          }
          
          # Width of SE
          widthSE <- qnorm((1-alpha/2), 0, 1) * SE
          
          # Add info to data and gather vector of survival which will be used in the next iteration
          data[iRow, 'surv'] <- surv
          data[iRow, 'se'] <- SE
          data[iRow, 'upper'] <- ifelse(surv + widthSE > 1, 1, surv + widthSE)
          data[iRow, 'lower'] <- ifelse(surv - widthSE < 0, 0, surv - widthSE)
          #vectSurv <- c(vectSurv, surv)
        }
      }
      
      # If percentage, surv*100 and round
      if(percentage){
        data$surv <- round(data$surv*100, 2)
        data$upper <- round(data$upper*100, 2)
        data$lower <- round(data$lower*100, 2)
      } else{
        data$surv <- round(data$surv, 2)
        data$upper <- round(data$upper, 2)
        data$lower <- round(data$lower, 2)
      }
      # END
      return(data)
    }
  }
  
  
}