# Project: honeur
#
# Author: hbossier
###############################################################################



#' Plot KM curve
#' 
#' @param survData data frame with processed survival data
#' @param variable the variable you want to plot
#' @param end_point the selected end point
#' @param line_number variable corresponding to the number of line patients are treated
#' @param sct_fl eligble for stem cell transplantation (1) or not (0)
#' @param site string: name of site if the individual site is requested
#' instead of plot with aggregated data
#' @param giveTable boolean to indicate whether table with numbers at risk should
#' be added (currently only available when site is not NULL).
#' @param timeUnit string unit of time variable
#' @param tableAttributes list with attributes for table (see also \code{setTableAttributes}
#' @param censorMarks boolean: add mark when censoring occurs (default = TRUE)?
#' 
#' @details tableAttributes can be used to set narSize, x_txtsize and legend_txtsize
#' 
#' @importFrom cowplot plot_grid
#' @import ggplot2
#' 
#' @author Nolen, hbossier
#' @export 
plotKMCurve <- function(survData, variable, end_point, line_number, sct_fl, 
    site = NULL, timeUnit = "year", censorMarks = TRUE,
    giveTable = FALSE, tableAttributes = NULL){
  
  # Make R CMD Checker happy
  time <- surv <- strata <- endpoint <- LINE_NUMBER <- SCT_FL <- NULL
  
  # Check whether data has the required columns
  inputDataChecker(survData[[variable]], 'survival')
  
  ####################
  # DATA PREPARATION #
  ####################
  # Filter on provided variables
  filteredData <- survData[[variable]] %>%
      filter(endpoint == end_point & LINE_NUMBER == line_number & SCT_FL == sct_fl) %>%
      select(-endpoint, -LINE_NUMBER, -SCT_FL)
  
  # If one site requested, filter this one out
  if(!is.null(site)){
    plotData <- filter(filteredData, typeSite == site, is.na(nar))
    # Variables related to the plot
    titlePlot <- paste0('KM Curve (', site, ')')
  } else {
    plotData <- filter(filteredData, typeSite == 'aggregated')
    # Variables related to the plot
    titlePlot <- paste0('Aggregated KM Curve (', variable, ')')
  }
  
  # Stop if no more data is left (HB, return string or NULL?)
  if(dim(plotData)[1] == 0) return('No data available...')
  
  # General plot elements
  numLvls <- length(unique(plotData$strata))
  if(numLvls >= 9){
    manColours <- brewer.pal(n = numLvls, name = 'Paired')
    lineSize <- 0.8
  } else {
    if(numLvls == 2) {
      manColours <- c('#3690c0', '#fb9a99')
    } else {
      manColours <- brewer.pal(n = numLvls, name = 'Set2')
    }
    lineSize <- 1
  }
  # X-axis ticks, vars related to number of strata
  xTicks <- 0:ceiling(max(plotData$time, na.rm = FALSE))
  fctrStrata <- factor(plotData$strata)  #Factor <- factor(risk.data$strata)
  maxCharStr <- max(nchar(levels(fctrStrata)))
  
  
  #################
  # SURVIVAL PLOT #
  #################
  
  # Actual plot
  plotSurv <- ggplot(plotData, aes(time, surv, group = as.factor(strata))) +
      geom_step(aes(color = as.factor(strata)), size = lineSize) +
      scale_colour_manual('strata', values = manColours) +
      scale_x_continuous(paste0("Time (",timeUnit,")"),
          breaks = xTicks, label = xTicks) + 
      scale_y_continuous("Survival (%) ", limits = c(0,100)) +
      geom_hline(yintercept = 50, linetype = 'dotted') + 
      labs(title = titlePlot, 
          subtitle = paste0('Line ', line_number,'. Endpoint: ',end_point)) + 
      # Have name of stratification variable on top
      guides(color = guide_legend(title.position = "top", 
              title.hjust = 0.5,
              title.theme = element_text(face = 'bold'))) + 
      theme_classic() +
      theme(panel.grid.minor = element_blank(),
          legend.position = 'top',
          legend.direction = "horizontal", 
          legend.box = "horizontal",
          plot.title = element_text(face = "bold"),
          panel.border = element_blank(),
          plot.margin = unit(c(1, 1, .5, 
                  ifelse(maxCharStr < 10, 1.5, 2.5)),"lines"),
          axis.text.x = element_text(7)
      )
  
  # Add censoring marks to the line:
  if(censorMarks){
    plotSurv <- plotSurv + 
        geom_point(data = subset(plotData, n.censor >= 1), 
            aes(color = as.factor(strata)),
            shape = 3)
  }
  
  
  ###################################################
  # Create table graphic to include at-risk numbers #
  ###################################################
  
  if(giveTable){
    if(is.null(site)){
      stop('Numbers at risk table currently not supported for this input data...')
    } else {
      # Data preparation: make the table ready
      riskData <- filteredData %>%
          filter(nar == 1, typeSite == site) %>%
          select(time, n.risk, strata) %>%
          mutate(strata = factor(strata))
      
      # Small check to see if factors are correctly labelled
      if(any(unique(riskData$strata) != levels(riskData$strata))){
        stop('Labelling in making strata variable factor does not match underlying factor levels in function!')
      }

      # Retreive plotting variables for tables
      if(is.null(tableAttributes)){
        tableAttributes <- setTableAttributes(list())
      } else {
        tableAttributes <- setTableAttributes(tableAttributes)
      }
      
      # Create the NAR table in ggplot world: note we flip y text and labels
      tableNAR <- ggplot(riskData, aes(x = time, y = rev(strata), 
                  label = format(n.risk, nsmall = 0))) +
          geom_text(size = tableAttributes[['narSize']]) +
          scale_y_discrete(breaks = as.character(levels(riskData$strata)), 
              labels = rev(levels(riskData$strata))) +
          scale_x_continuous("Numbers at risk") +
          xlab(NULL) + ylab(NULL) +
          theme_bw() +
          theme(axis.title.x = element_text(size = tableAttributes[['x_txtSize']], vjust = 1),
              panel.grid.minor = element_blank(), 
              panel.grid.major = element_blank(),
              panel.border = element_blank(), 
              axis.ticks = element_blank(),
              axis.text.x = element_blank(),
              legend.position = "none",
              axis.text.y = element_text(size = tableAttributes[['legend_txtSize']],
                  colour = rev(manColours), # gives a warning as we provide a number of colours
                  face = "bold", hjust = 1)) +
          theme(plot.margin = unit(c(-1.5, 1, 0.1, 
                      ifelse(maxCharStr < 10, 2.5, 3.5) - 0.22 * maxCharStr), 
                  "lines"))
      
      
      ## Create a blank plot for place-holding
      blank.pic <- ggplot(plotData, aes(time, surv)) +
          geom_blank() + 
          theme(axis.line=element_blank(),
              axis.text.x=element_blank(),
              axis.text.y=element_blank(),
              axis.ticks=element_blank(),
              axis.title.x=element_blank(),
              axis.title.y=element_blank(),
              legend.position="none",
              panel.background=element_blank(),
              panel.border=element_blank(),
              panel.grid.major=element_blank(),
              panel.grid.minor=element_blank(),
              plot.background=element_blank())
      
      ######################
      # Create final graph #
      ######################
      graphTable <- gridExtra::arrangeGrob(plotSurv, blank.pic, 
          tableNAR, clip = FALSE, nrow = 3,
          ncol = 1, heights = unit(c(2, 0.1, 0.3),c("null", "null", "null")))
    }
  }
    
  # Print the final plot object
  if(!giveTable){
    print(plotSurv)
  } else {
    gridExtra::grid.arrange(graphTable)
  }
}

#' Column name checker
#' 
#' Checks whether input data has columns that are needed.
#' @param plotType string type of plot checking input data for ('survival', 'alluvial')
#' @param inputData data frame which needs to be checked
#' 
#' @author hbossier
#' @export 
inputDataChecker <- function(inputData, plotType = c('survival', 'alluvial')){
  # Match type to be checked
  plotType <- match.arg(plotType, choices = c('survival', 'alluvial'))
  
  # Run check
  if(plotType == 'survival'){
    reqCols <- c('surv', 'time', 'strata', 'n.risk', 'n.censor')
    if(any(!reqCols %in% names(inputData))){
      stop(paste0('Missing one of required columns: ', paste(reqCols, collapse = ', ')))
    }
  }
}

#' Set table attributes for survival table
#' 
#' @param tableAttributes the list with table attributes
#' @details function checks whether a value exists and if missing, sets it to
#' default values. Included variables (default value) are:
#' narSize (3), x_txtSize (10) and legend_textSize (9)
#' @author hbossier
#' @export 
setTableAttributes <- function(tableAttributes){
  # Variables included with their default values
  elsWattr <- c('narSize', 'x_txtSize', 'legend_txtSize')
  defValues <- c(3, 10, 9)
  # Find missing entries
  miss <- which(!elsWattr %in% names(tableAttributes[elsWattr]), arr.ind = TRUE)
  if(length(miss) == 0){
    return(tableAttributes)
  } else {
    # Set default values for missing attributes
    tableAttributes[elsWattr[miss]] <- defValues[miss]
    return(tableAttributes)
  }
}

#' Plot alluvial curve
#' 
#' @param alluvData data frame with processed alluvial data
#' @param onDevice print to screen or file
#' @param fPath if onDevice == file, provide a file path to write the plot
#' 
#' @import ggalluvial
#' @import RColorBrewer
#' 
#' @author Nolen
#' @export 
plotAlluvial <- function(alluvData, onDevice = c('screen','file'),
    fPath = NULL){
  # Checks
  onDevice <- match.arg(onDevice, c('screen', 'file'))
  if(onDevice == 'file' & is.null(fPath)) stop('Provide fPath when writing to file.')
  
  # First retrieve numer of colors
  nb.cols <- length(levels(alluvData$stratum))
  myColors <- colorRampPalette(brewer.pal(8, "Set1"))(nb.cols)
  # If NA
  myColors[which((levels(alluvData$stratum)=="NA"))] <- "#FFFFFF"
  
  # Create plot figure
  toPlot <- ggplot(data = alluvData,
          aes(x = Line, stratum = stratum, 
              alluvium = alluvium,
              y = count, label = count, fill = stratum)) +
      scale_fill_manual(values = myColors) +
      geom_flow(stat = "alluvium", lode.guidance = "frontback") +
      geom_stratum(alpha = 0.9) + 
      geom_text(angle=0, size=3, fontface = 'bold', stat="stratum") +
      theme_minimal()+
      theme(legend.position = "top", 
          legend.text = element_text(size = 10, face = 'bold'), 
          legend.key.size = unit(0.75, "cm"),
          axis.text.x = element_text(angle = 90, face = 'bold'),
          axis.text=element_text(size=8),
          legend.title = element_blank())
  
  # Where to output?
  if(onDevice == 'file'){
    ggsave('alluvial.png', toPlot, path = fPath, width = 7, height = 6, 
        scale = 1.75)
  } else {
    print(toPlot)
  }
}




#' Create a forest plot
#' 
#' Plot data by treatment in a forest plot.
#' 
#' @param data input data
#' @param line treatment line, integer
#' @param site string the selected site
#' @param stratfactors variable to denote strata
#' @param endpoint the selected endpoint
#' @param modeltype string displayed in plot
#' @param fontSize size of fonts in the plot (in points).
#' @param cexErr size of error bars in the plot.
#' 
#' @import ggplot2
#' @import dplyr
#' @importFrom grid convertX
#' @importFrom grDevices axisTicks
#' 
#' @author Nolen (J&J), adapted by HBossier
#' @export 
honeurForest <-function(data, line,  site, stratfactors = NULL, 
    endpoint = NULL, modeltype = "by Variable", fontSize = 2.5, cexErr = 0.8){
  
  if (is.null(line)) stop("Line Number is not provided.")
  if (is.null(site)) stop("Site is not provided.")
  
  if (is.null(endpoint) & is.null(stratfactors)){
    df <- data %>% filter(LINE_NUMBER==!!line & site==!!site) %>% 
        mutate(HRplot=as.numeric(as.character((HR))),
            Lower.CIplot = as.numeric(as.character((Lower.CI))), 
            Upper.CIplot = as.numeric(as.character((Upper.CI))))
    df$label_Plot <- factor(unlist(sapply(strsplit(as.character(df$label), "vs."),function(x) x[1])))
    df$label_Plot <- factor(df$label_Plot, levels=rev(levels(df$label_Plot))) 
    p = ggplot(data=df,
            aes(x = label_Plot,y = HRplot, ymin = Lower.CIplot, ymax = Upper.CIplot))+
        geom_pointrange(aes(col=label_Plot), size = 0.5, shape=15)+
        geom_hline(aes(fill=label_Plot),yintercept = 1, linetype = 2)+
        xlab(' ') +
        ylab("Hazard Ratio (95% Confidence Interval)") +
        geom_errorbar(aes(ymin=Lower.CIplot, ymax= Upper.CIplot,col=label_Plot), width = 0.5, cex = 1)+ 
        facet_grid(variable~endpoint,space="free",scales = "free_y") +  
        scale_y_log10()+
        coord_flip() + 
        theme_bw() + 
        theme(strip.text.y = element_text(angle = 90, size=7), 
            strip.text.x = element_text(size=7),
            text = element_text(size = 7),
            legend.position="none",
            panel.grid.minor = element_blank(),
            panel.grid.major.y = element_blank())
    
  }
  else{
    if (is.null(stratfactors)) stop("Variable(s) to plot are not available.")
    stratfactorplot <- as.vector(unlist(strsplit(stratfactors, split = " ")))
    
    HR <- data
    HR$p <- ifelse(grepl('<0.001', HR$p), 0.000001, HR$p)
    HR$p <- as.numeric(HR$p)
    HR$p <- ifelse(is.na(HR$p), 100, HR$p)
    # HR$p <- ifelse((as.character(HR$p) == "NA"), 100, as.numeric(as.character(HR$p)))
    # HR$p <- ifelse(is.na((HR$p)), 0.000001, HR$p)
    
    HR <- HR %>% mutate(var=variable, level=label, N = as.numeric(as.character(n.max)), 
        p.value=p, estimate=as.numeric(as.character(HR)),
        conf.low=as.numeric(as.character(Lower.CI)), 
        conf.high=as.numeric(as.character(Upper.CI))) %>% filter(endpoint==!!endpoint, LINE_NUMBER==!!line & site==!!site & variable%in%stratfactorplot)
    HR$pos <- c(1:nrow(HR))
    toShow <- HR[,c("var", "level", "N", "p.value", "estimate", "conf.low", "conf.high", "pos", "variable")]
    
    toShow$variable <- as.factor(toShow$variable)
    toShow$level <- factor(unlist(sapply(strsplit(as.character(toShow$level), "vs."),function(x) x[1])))
    noDigits <- 2
    refLabel <- "reference"
    cpositions <- c(-0.02, 0.08, 0.45)
    hjust_ci <- 1.5
    main <- paste0("Hazard Ratio (", endpoint, ") \n Line ", line, ", Site ", site , ", Modeled ", modeltype )
    
    # Get estimates and CIs
    toShowExp <- toShow[,c('estimate', 'conf.low', 'conf.high')]
    toShowExp[is.na(toShowExp)] <- 0
    toShowExp <- format((toShowExp), digits = noDigits)
    toShowExpClean <- data.frame(toShow,
        pvalue = round(toShow[,'p.value'], noDigits+1),
        toShowExp)
    toShowExpClean$stars <- paste0(round(toShowExpClean$p.value, noDigits+1), " ",
        ifelse(toShowExpClean$p.value < 0.05, "*",""),
        ifelse(toShowExpClean$p.value < 0.01, "*",""),
        ifelse(toShowExpClean$p.value < 0.001, "*",""))
    toShowExpClean$ci <- paste0("(",toShowExpClean[,"conf.low.1"]," - ",toShowExpClean[,"conf.high.1"],")")
    toShowExpClean$estimate.1[(toShowExpClean$estimate==1)] = refLabel
    toShowExpClean$stars[which(toShowExpClean$p.value < 0.001)] = "<0.001 ***"
    toShowExpClean$stars[which(toShowExpClean$p.value == 100)] = refLabel
    toShowExpClean$stars[is.na(toShowExpClean$estimate)] = ""
    toShowExpClean$ci[is.na(toShowExpClean$estimate)] = ""
    toShowExpClean$estimate[is.na(toShowExpClean$estimate)] = 0
    toShowExpClean$var = as.character(toShowExpClean$var)
    toShowExpClean$var[duplicated(toShowExpClean$var)] = ""
    
    toShowExpClean$estimate[which(toShowExpClean$estimate < 0.00000000001)] = NA
    toShowExpClean$conf.low[which(toShowExpClean$conf.low < 1.00e-07)] = NA
    toShowExpClean$conf.high[which(toShowExpClean$conf.high < 1.00e-07 | toShowExpClean$conf.high=="Inf")] = NA
    
    toShowExpClean <- toShowExpClean[nrow(toShowExpClean):1, ]
    
    # Range of breaks
    rangeb <- c(min(min(log(toShowExpClean$conf.low), log(toShowExpClean$conf.high), 
                na.rm = TRUE), -5), max(max(log(toShowExpClean$conf.low), log(toShowExpClean$conf.high), 
                na.rm = TRUE),1))
    breaks <- axisTicks(rangeb/5, log = TRUE, nint=7)
    
    
    rangeplot <- rangeb
    rangeplot[1] <- rangeplot[1] - diff(rangeb)
    rangeplot[2] <- rangeplot[2] + 0.15 * diff(rangeb)
    width <- diff(rangeplot)
    y_variable <- (rangeplot[1] + cpositions[1] * width)
    y_nlevel <- (rangeplot[1] + cpositions[2] * width)
    y_cistring <- (rangeplot[1] + cpositions[3] * width)
    y_stars <- (rangeb[2])
    x_annotate <- seq_len(nrow(toShowExpClean))*2  
    
    # geom_text fontSize is in mm (https://github.com/tidyverse/ggplot2/issues/1828)
    annot_size_mm <- fontSize *
        as.numeric(convertX(unit(theme_get()$text$size, "pt"), "mm"))
    
    toShowExpClean$estimate[which(is.na(toShowExpClean$estimate))] = min(breaks)
    toShowExpClean$conf.low[which(is.na(toShowExpClean$conf.low))] =  min(breaks)
    toShowExpClean$conf.high[which(is.na(toShowExpClean$conf.high))] = max(breaks)
    toShowExpClean$variable <- factor(toShowExpClean$variable, levels=rev(levels(toShowExpClean$variable))) 
    
    p <- ggplot(toShowExpClean, aes(x_annotate, 
                estimate, ymin = (conf.low), ymax = (conf.high) )) + 
        geom_pointrange(shape = 15, size = 0.2) + 
        geom_errorbar(aes(ymin = conf.low, ymax = conf.high, col = variable),
            cex = cexErr) + 
        geom_hline(yintercept = 1, linetype = 3) + 
        coord_flip(ylim = exp(rangeplot)) +
        scale_y_log10(labels = sprintf("%g", breaks),
            expand = c(0.02, 0.02),
            breaks = breaks) + 
        scale_fill_manual(values = c("#FFFFFF33", "#00000033"), guide = "none") + 
        annotate(geom = "text", x = max(x_annotate) + 2.2, 
            y = exp(y_variable), 
            label = "Variables", fontface = "bold", hjust = 0, 
            size = annot_size_mm) +
        annotate(geom = "text", x = x_annotate, y = exp(y_variable), 
            label = toShowExpClean$var, fontface = "bold", hjust = 0, 
            size = annot_size_mm) + 
        annotate(geom = "text", x = max(x_annotate) + 2, 
            y = exp(y_nlevel),
            hjust = 0, label = "Categories", fontface = "bold",
            vjust = -0.1, size = annot_size_mm) + 
        annotate(geom = "text", x = x_annotate, y = exp(y_nlevel),
            hjust = 0, label = toShowExpClean$level, 
            vjust = -0.1, size = annot_size_mm) + 
        annotate(geom = "text", x = max(x_annotate) + 2,
            y = exp(y_cistring-hjust_ci), 
            label = "N", fontface = "bold", hjust = 0, 
            size = annot_size_mm) + 
        annotate(geom = "text", x = x_annotate, 
            y = exp(y_cistring-hjust_ci), 
            label = toShowExpClean$N, 
            fontface = "italic", hjust = 0, 
            size = annot_size_mm) + 
        annotate(geom = "text", x = max(x_annotate) + 2, 
            y = exp(y_cistring), 
            label = "Hazard Ratio", fontface = "bold",
            size = annot_size_mm)+
        annotate(geom = "text", x = x_annotate, 
            y = exp(y_cistring), 
            label = toShowExpClean$estimate.1, 
            size = annot_size_mm, 
            vjust = ifelse(toShowExpClean$estimate.1 == "reference", 0.5, -0.1)) + 
        annotate(geom = "text", x = max(x_annotate) + 2,
            y = exp(y_cistring+hjust_ci), 
            label = "95% CI", size = annot_size_mm,  fontface = "bold") + 
        annotate(geom = "text", x = x_annotate, 
            y = exp(y_cistring + hjust_ci), 
            label = toShowExpClean$ci, 
            size = annot_size_mm,  fontface = "italic") + 
        annotate(geom = "text", x = max(x_annotate) + 2,
            y = exp(y_stars), 
            label = "P-value", size = annot_size_mm, 
            hjust = -0.2, fontface = "bold") + 
        annotate(geom = "text", x = x_annotate, 
            y = exp(y_stars), 
            label = toShowExpClean$stars, size = annot_size_mm, 
            hjust = -0.2, fontface = "italic") + 
        labs(title = main, x = "", y = "") +
        theme_light() + 
        theme(
            panel.grid.minor = element_blank(), 
            panel.grid.major.y = element_blank(), 
            legend.position = "none", 
            panel.border = element_blank(), 
            axis.title.y = element_blank(), 
            axis.text.y = element_blank(), 
            axis.ticks.y = element_blank(), 
            plot.title = element_text(hjust = 0.5))
    
    
  }
  return(p)
}
