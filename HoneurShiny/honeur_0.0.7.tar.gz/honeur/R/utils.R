# Project: honeur
#
# Author: hbossier
###############################################################################


#' Key legend
#' 
#' Small dev function returning key and legends
#' 
#' @author hbossier
#' @export 
keys <- function(){
  info <- list(
      'IND_ID' = 'ID of the disease (indicator id, 437233 = Multiple Myeloma)',
      'SCT_FL' = 'Are patients eligble for stem cell transplantation (0: NO/ 1:YES)',
      'LINE_NUMBER' = 'Treatment line (I think the number of treatment plans)',
      'NAR' = 'Number of patients at risk',
      'time' = 'Measured in years',
      'regimen' = 'a prescribed course of medical treatment, diet, or exercise for the promotion or restoration of health.'
  )
  print(info)
}


#' End point key legend
#' 
#' Given the end point abbreviation, return full name.
#' 
#' @param endPs vector with the abbreviated end points
#' 
#' @author hbossier
#' @export 
getFullEndP <- function(endPs){
  case_when(
      endPs == 'OS' ~ 'Insert Name [OS]',
      endPs == 'PFS' ~ 'Insert Name [PFS]',
      endPs == 'PFS2' ~ 'Insert Name [PFS2]',
      endPs == 'PFS3' ~ 'Insert Name [PFS3]',
      endPs == 'NEXT_TRT' ~ 'Insert Name [NEXT_TRT]',
      endPs == 'FU' ~ 'Insert Name [FU]',
      endPs == 'FR' ~ 'Insert Name [FR]',
      TRUE ~ paste0('Abbreviation not found for ', endPs)
  )
}


#' Structure names of information in the data
#' 
#' Input are the names for continuous, database, patient, regimens and KM data entries
#' in the JSON files. Output is a more informative name used in the R package.
#' 
#' @param contN string name of continous data (mostly patient level data I assume)
#' @param dbN string name of data related to database characteristics (categorical)
#' @param patN string name of (categorical) patient data
#' @param avRegN string name of the available regimens (e.g. SumaryTab)
#' @param regClassN string name of regimens grouped by class (e.g. SummaryReg)
#' @param classSeqCountN string name of regimens counts grouped by class sequence
#' @param regCountN string name of regimens counts
#' @param regSeqN string name of regimens sequences
#' @param trtByLineNN string name of treatments by line 
#' @param kmN string name of data related to KM
#' @param ... extra arguments
#' 
#' @details Currently implemented data sources are continous, database,
#' patient, several variables related to the regimens and KM.
#' Might need to find a more flexible approach for this.
#' 
#' @author hbossier
#' @export 
descTabs <- function(contN = NULL, dbN = NULL, patN = NULL, 
    avRegN = NULL, regClassN = NULL, classSeqCountN = NULL,
    regCountN = NULL, regSeqN = NULL, trtByLineNN = NULL,
    kmN = NULL, ...){
  
  # Capture extra arguments, for future code
  args <- list(...)
  
  # Capture input in list to check NULL status later on
  listVars <- list(contN, dbN, patN, avRegN, regClassN,
      classSeqCountN, regCountN, regSeqN, trtByLineNN, kmN)
  
  # Variables currently available in honeur package
  availVars <- c('continuous', 'database', 'patChar',
      'avRegimens', 'regimensByClass', 'trtSeqCounts' ,'regimensCounts',
      'regimensSequences', 'trtByLineNumbers', 'KM') 
  
  # Vector of vars: concatenate removes the NULL variables (which we don't need if not provided)
  selVars <- c(contN, dbN, patN, avRegN, regClassN, 
      classSeqCountN, regCountN, regSeqN, trtByLineNN, kmN)
  listVar <- sapply(selVars, list)
  # Select the variables that are not null.
  names(listVar) <- availVars[which(!unlist(lapply(listVars, is.null)))]
  return(listVar)
}

#' Return either abbreviated or full name of variables.
#' 
#' Function to return either the abbreviation given the full name of a variable
#' or vice versa.
#' 
#' @param shortN string the abbreviated (short) name
#' @param fullN string the full name of the variable
#' 
#' @details Should not provide both short and full name.
#' 
#' @return string with either the abbreviation (short) or full name
#' @author hbossier
#' @export 
abbrevs <- function(shortN = NULL, fullN = NULL){
  if(sum(!is.null(shortN), !is.null(fullN)) == 2){
    stop('Either provide a short name or a full name.')
  } 
  # The abbreviations
  SHORT_NAME <- c("AGEGROUP", "LINE_START_YEAR_CAT", "AGE65", "AGE18", "GENDER",
      "ORR_RESP_CAT", "VGPR_BETTER_RESP_CAT", "MIN_RESP_CAT", "LOT2CAT",
      "PR_RESP_CAT", "VGPR_RESP_CAT", "CR_RESP_CAT", "SCR_RESP_CAT",
      "PD_RESP_CAT", "SD_RESP_CAT", "CLIN_BEN_RESP_CAT", "STATUSCAT_OS",
      "STATUSCAT_PFS", "TRTMNT", "LINE_REGIMEN", "LINE_REGIMEN_COMBI",
      "IND_START_YEAR_CAT","DURATION_RESP", "AGE_YEARS", "AGE_DIAGNOSIS", "TIME_TO_OS",
      "TIME_TO_FU", "TIME_TO_DISCON", "TIME_TO_NEXT_TRT", "TIME_TO_TFI",
      "TIME_TO_PFS", "TIME_TO_PFS2", "TIME_TO_PFS3",
      "TIME_TO_PD", "TIME_TO_PD2", "TIME_TO_PD3",
      "TIME_TO_PR", "TIME_TO_CR", "TIME_TO_FR", "TIME_TO_VGPR", "TIME_TO_MIN",
      "DURATION_RESP2", "DURATION_RESP3", "var_ISS_ID", "var_DURIE_SALMON_ID",
      "var_ECOG_ID", "LINE_NUMBER", "LOT4CAT"
  )
  
  # The full name
  CONCEPT_NAME <- c("Age Categories", "Line Start Year", "Age (cut-off=65)", "Age (cut-off=18)", "Gender",
      "Overall response (sCR+CR+VGPR+PR)" , "VGPR or better (sCR + CR + VGPR)", "Minimum Response (MR)", "Line of Treatment (1 or >=2)",
      "Partial Response (PR)", "Very Good Partial Response (VGPR)", "Complete Response (CR)", "Stringent Complete Response (sCR)",
      "Progressive Disease (PD)", 'Stable Disease (SD)', "Clinical benefit (Overall response + MR)", "OS status",
      "PFS status", 'Treatment Class Grouping', "Regimens", "Grouped Regimens",
      "Diagnosis Start Year","Duration of Response", "Age (in years)", "Age at Diagnosis", "Overall Survival (OS)",
      "Duration of Follow-up", "Time to Treatment Discontinuation (TTD)", "Time to Next Treatment (TTNT)", "Treatment-free Interval (TFI)",
      "Progression-free Survival (PFS)", "Progression-free Survival Censored at Next Line Start Date", "Progression-free Survival (Next Line Start Date as Progression Date ))",
      "Progression", "Progression Censored at Next Line Start Date", "Progression (Next Line Start Date as Progression Date ))",
      "Time to Partial Response", "Time to Complete Response", "Time to First Response", "Time to VGPR", "Time to Minimum Response",
      "Duration of Response(2)", "Duration of Response (3)", "ISS", "SALMON & DURIE STAGE",
      "ECOG Score", "Line of Treatment", "Line of Treatment (1, 2, 3 or >= 4)"
  )
  # In data frame to provide lookup
  namesDat <- data.frame(SHORT_NAME, CONCEPT_NAME, stringsAsFactors = FALSE)
  
  # Rename time
  if(!is.null(shortN)){
    # Adding special cases for the endpoints
    if(any(shortN %in% c('OS', 'PFS' ,'PFS2' ,'PFS3' ,'NEXT_TRT' ,'FU' ,'FR'))){
      shortN <- paste0("TIME_TO_", shortN)
    }
    # Now rename
    toReturn <- try(namesDat[match(shortN, namesDat[,'SHORT_NAME']), 'CONCEPT_NAME'], silent = TRUE)
  } else {
    toReturn <- try(namesDat[match(fullN, namesDat[,'CONCEPT_NAME']), 'SHORT_NAME'], silent = TRUE)
  }
  # End
  return(toReturn)
}


#' Return named list with abbreviations as input.
#' 
#' Given a vector of abbreviations, return a named list.
#' 
#' @param vecAbbr vector of abbreviations
#' @param reverse boolean to return the short name as names for the list 
#' rather than the full name (default = FALSE)
#' 
#' @return a list where each entry of the abbreviation is named with the 
#' full name.
#' @author hbossier
#' @export 
getNamedList <- function(vecAbbr, reverse = FALSE){
  if(!reverse){
    makeList <- as.list(vecAbbr)
    names(makeList) <- sapply(vecAbbr, abbrevs)
  } else{
    makeList <- sapply(vecAbbr, abbrevs, simplify = FALSE, USE.NAMES = TRUE)
  }
  makeList
}


