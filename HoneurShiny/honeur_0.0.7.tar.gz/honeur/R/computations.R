# Project: honeur
#
# Description: several functions related to survival analysis on aggregated data
# Author: hbossier
###############################################################################




#' Calculate summary statistics on aggregated data.
#' 
#' Runs several functions to calculate aggregated statistics
#' on currently implemented data structures:
#' continous, database, patient, regiments and KM data. 
#' @param allData data frame with data of each site (appended rowwise)
#' @param entries function to provide the names of the entries in the JSON file.
#' The names correspond to the continuous, database, patient characteristics, regiments
#' KM name of the JSON files, see \code{descTabs}.
#' @param RoundDigits integer, round the number of digits (default = 3)
#' @param ... extra arguments (for future code)
#' 
#' @author hbossier
#' @return named list with the results
#' @export 
getAggregatedStats <- function(allData, entries = descTabs(), 
    RoundDigits = 3, ...){
  
  # Capture extra arguments
  args <- list(...)
  
  # Prepare results
  results <- list()
  
  # Run the appropriate aggregation tools on the provided variables in descTab
  if('continuous' %in% names(entries)){
    results$contSum <- getContSummary(data = allData[[entries$continuous]],
        RoundDigits = RoundDigits)
  }
  
  if('database' %in% names(entries)){
    results$DBSum <- getDatabaseSummary(data = allData[[entries$database]],
        RoundDigits)
  }
  
  if('patChar' %in% names(entries)){
    results$patientSum <- getPatientSummary(data = allData[[entries$patChar]],
        RoundDigits = RoundDigits)
  }
  
  if('avRegimens' %in% names(entries)){
    # Info on default values
    infoRegimens <- infoRegComp(typeRegSum = 'avRegN')
    # Retrieve calculations
    results$avRegSum <- getRegSummary(data = allData[[entries$avRegimens]],
        groupingVar = infoRegimens$groupingVar, dropVar = infoRegimens$dropVar,
        sortingVar = infoRegimens$sortingVar, RoundDigits)
  }
  
  if('regimensByClass' %in% names(entries)){
    # Info on default values
    infoRegimens <- infoRegComp(typeRegSum = 'regClassN')
    # Retrieve calculations
    results$regimensByClassSum <- getRegSummary(data = allData[[entries$regimensByClass]],
        groupingVar = infoRegimens$groupingVar, dropVar = infoRegimens$dropVar,
        sortingVar = infoRegimens$sortingVar, RoundDigits)
  }
  
  if('trtSeqCounts' %in% names(entries)){
    # Info on default values
    infoRegimens <- infoRegComp(typeRegSum = 'classSeqCountN')
    # Retrieve calculations
    results$trtSeqCSum <- getRegSummary(data = allData[[entries$trtSeqCounts]],
        groupingVar = infoRegimens$groupingVar, dropVar = infoRegimens$dropVar,
        sortingVar = infoRegimens$sortingVar, RoundDigits)
  }
  
  if('regimensCounts' %in% names(entries)){
    # Info on default values
    infoRegimens <- infoRegComp(typeRegSum = 'ClassSeqAll')
    # Retrieve calculations
    results$regCSum <- getRegSummary(data = allData[[entries$regimensCounts]],
        groupingVar = infoRegimens$groupingVar, dropVar = infoRegimens$dropVar,
        sortingVar = infoRegimens$sortingVar, RoundDigits)
  }
  
  if('regimensSequences' %in% names(entries)){
    # Info on default values
    infoRegimens <- infoRegComp(typeRegSum = 'RegSeqAll')
    # Retrieve calculations
    results$regSeqSum <- getRegSummary(data = allData[[entries$regimensSequences]],
        groupingVar = infoRegimens$groupingVar, dropVar = infoRegimens$dropVar,
        sortingVar = infoRegimens$sortingVar, RoundDigits)
  }
  
  if('trtByLineNumbers' %in% names(entries)){
    trtData <- allData[[entries$trtByLineNumbers]]
    trtGroupVars <- names(trtData)[grepl('TRTMNT', names(trtData))]
    results$trtByLineSum <- combTrtByLineC(data = trtData,
        groupingVar = trtGroupVars)
  }
  
  if('KM' %in% names(entries)){
    results$KMSum <- 'Data loaded in seperately'
  }
  # END
  return(results)
}




#' Combine aggregated with individual site data
#' 
#' After aggregating results, we can append the original site data
#' to filter out individual sites vs aggregated sites later on.
#' 
#' @param aggStats data frame with the results coming from \code{getAggregatedStats}
#' @inheritParams getAggregatedStats
#' 
#' @author hbossier
#' @export 
bindIndAggSites <- function(aggStats, allData, entries = descTabs()){
  
  # Make a copy and add a new column to each entry in the aggregated statistics data frame (except KMSum)
  toReplace <- lapply(aggStats[-which(names(aggStats) == 'KMSum')],
      transform, site = 'aggregated')
  # Also, have it as character (not factor)
  toReplace <- lapply(toReplace,
      transform, site = as.character(site))

  # For loop over the entries in toReplace
  for(iEntry in names(toReplace)){
    
    # Get correct name and select the site data
    switchName <- switch(iEntry,
        'contSum' = 'continuous',
        'DBSum' = 'database',
        'patientSum' = 'patChar',
        'avRegSum' = 'avRegimens',
        'regimensByClassSum' = 'regimensByClass',
        'trtSeqCSum' = 'trtSeqCounts',
        'regCSum' = 'regimensCounts',
        'regSeqSum' = 'regimensSequences',
        'trtByLineSum' = 'trtByLineNumbers',
        'KMSum' = 'KM')
    siteData <- allData[[entries[[switchName]]]]
    
    ## Now retrieve the different parts of the data
    # Continous
    if('continuous' == switchName){
      # rename, select and append
      toReturn <- rename(siteData, 
              average = Mean, median = Median, min = Min, max = Max, N = n) %>%
          select(names(toReplace[[iEntry]])) %>% 
          as_tibble() %>%
          bind_rows(toReplace[[iEntry]], .)
    }
    
    # Database
    if('database' == switchName){
      # rename, select and append
      toReturn <- rename(toReplace[[iEntry]],
              n = nAgg, prop = propAgg) %>%
          bind_rows(., siteData)
    }
    
    # Patient characteristics
    if('patChar' == switchName){
      # rename, select and append
      toReturn <- rename(siteData, nAgg = count, propAgg = prop) %>% 
          select(names(toReplace[[iEntry]])) %>% 
          bind_rows(toReplace[[iEntry]], .) %>% 
          rename(n = nAgg, prop = propAgg) 
    }
    
    # Available regimens
    if('avRegimens' == switchName){
      # filter the regimens, rename, select and append
      toReturn <- rename(siteData, nAgg = count, propAgg = prop) %>% 
          select(names(toReplace[[iEntry]])) %>% 
          bind_rows(toReplace[[iEntry]], .) %>% 
          rename(n = nAgg, prop = propAgg) %>% 
          group_by(site) %>%
          arrange_all(.by_group = TRUE) %>%
          ungroup()
    }
    
    # Treatment regimens by class
    if('regimensByClass' == switchName){
      # rename, select and append
      toReturn <- rename(siteData, nAgg = count, propAgg = prop) %>% 
          select(names(toReplace[[iEntry]])) %>% 
          bind_rows(toReplace[[iEntry]], .) %>%
          rename(n = nAgg, prop = propAgg) 
    }
    
    # Treatment sequences by class
    if('trtSeqCounts' == switchName){
      # rename, select and append
      toReturn <- rename(siteData, nAgg = count, propAgg = prop) %>% 
          select(names(toReplace[[iEntry]])) %>% 
          bind_rows(toReplace[[iEntry]], .) %>%
          rename(n = nAgg, prop = propAgg) %>%
          # Also add the number of treatments, counted by the number of arrows
          mutate(arrows = countArrows(trtmntSequence),
              maxNumTrt = arrows + 1)
    }
    
    # Regimens count
    if('regimensCounts' == switchName){
      # rename, select and append
      toReturn <- rename(siteData, nAgg = count, propAgg = prop) %>% 
          select(names(toReplace[[iEntry]])) %>% 
          bind_rows(toReplace[[iEntry]], .) %>%
          rename(n = nAgg, prop = propAgg) %>%
          # Also add the number of treatments, counted by the number of arrows
          mutate(arrows = countArrows(classSequence),
              maxNumTrt = arrows + 1)
    }
    
    # Regimens sequences (needs more work on this, HB TODO)
    if('regimensSequences' == switchName){
      # rename, select and append
      toReturn <- rename(siteData, nAgg = count, propAgg = prop) %>% 
          select(names(toReplace[[iEntry]])) %>% 
          bind_rows(toReplace[[iEntry]], .) %>%
          rename(n = nAgg, prop = propAgg) %>%
          # Also add the number of treatments, counted by the number of arrows
          mutate(arrows = countArrows(trtSequence),
              maxNumTrt = arrows + 1)
    }
    
    # Treatment by line numbers: only aggregated data here
    if('trtByLineNumbers' == switchName){
      toReturn <- toReplace[[iEntry]]
    }
    
    # Now replace the entry in copy with the new data
    toReplace[[iEntry]] <- toReturn
  }
  
  # Survival is done in preprocessing
  toReplace[['KMSum']] <- aggStats[['KMSum']]
  
  # END
  return(toReplace)
}


#' Weighted sample variance
#' 
#' Calculate a weighed sample variance over all sites
#' 
#' @param siteMeans vector with the averages per site
#' @param wMean integer the weighted average over all sites
#' @param nSites vector the counts per site
#' @param varSites vector with the sample variances per site
#' 
#' @author hbossier
#' @export 
empVar <- function(siteMeans, wMean, nSites, varSites){
  nTotal <- sum(nSites)
  deviations <- (siteMeans - wMean)^2
  wSamVar <- sum(((nSites*varSites)/nTotal)) + sum((nSites*deviations)/nTotal)
  return(wSamVar)
}

#' Summarise continuous data
#' 
#' Function to summarise continuous data over all sites. 
#' Options are average, median, min and max and number of measurements.
#' The former two are weighted on the number of cases
#' within each site.
#' 
#' @param data the combined data over all sites
#' @param summary the requested summary statistic (options are average, median, min and max)
#' @param groupingVars vector with columns names to group calculations on
#' @param RoundDigits the number of digits after comma (default = 3)
#' 
#' @importFrom tibble as_tibble
#' @import dplyr
#' 
#' @return returns data frame where calculations are grouped per name found in
#' groupingVars (default: CONCEPT_NAME, IND_ID, SCT_FL and LINE_NUMBER)
#' 
#' @author hbosssier (OA)
#' @export 
getContSummary <- function(data, summary = c('average', 'median', 'min', 'max', 'numMeas'), 
    groupingVars = c('CONCEPT_NAME', 'IND_ID', 'SCT_FL', 'LINE_NUMBER'),
    RoundDigits = 3){
  
  # Check arguments
  summary <- match.arg(summary, 
      choices = c('average', 'median', 'min', 'max', 'numMeas'), several.ok = TRUE)
  if(any(!groupingVars %in% names(data))) stop('Grouping variable not found in data.')
  
  # Empty data: expect data for each unique level in grouping variable
  groupLvLs <- lapply(data[,groupingVars], unique)
  returnData <- expand.grid(groupLvLs, stringsAsFactors = FALSE) %>%
    as_tibble()
  
  # Grouped data: note there should be one line per site!
  grData <- data %>%
      as_tibble() %>% 
      # Grouping variables
      group_by_at(groupingVars) %>%
      # For each group we count the total number of cases to get the weight for each site
      mutate(TotalCases = sum(n),
          weightN = n/TotalCases)
  
  # All weights should sum to 1
  sumWeights <- group_by_at(grData, groupingVars) %>% 
      summarise(checkWeight = sum(weightN)) %>% 
      pull(checkWeight)
  if(any(sumWeights != 1)) stop('Error when calculating weights')
  
  # Now add summaries 
  if('max' %in% summary){
    returnData <- grData %>%
        summarise(max = max(Max, na.rm = TRUE)) %>%
        full_join(returnData, by = groupingVars)
  }
  if('min' %in% summary){
    returnData <- grData %>%
        summarise(min = min(Min, na.rm = TRUE)) %>%
        full_join(returnData, by = groupingVars)
  }
  if('median' %in% summary){
    returnData <- grData %>%
        summarise(median = matrixStats::weightedMedian(x = Median, w = weightN, 
                na.rm = TRUE)) %>%
        full_join(returnData, by = groupingVars)
  }
  if('average' %in% summary){
    returnData <- grData %>%
        summarise(average = matrixStats::weightedMean(x = Mean, w = weightN, 
                na.rm = TRUE)) %>%
        full_join(returnData, by = groupingVars)
  }
  if('numMeas' %in% summary){
    returnData <- grData %>%
        summarise(N = sum(n, na.rm = TRUE)) %>%
        full_join(returnData, by = groupingVars)
  }
  
  # Ungroup and rename
  returnData <- ungroup(returnData) %>%
      mutate_if(is.numeric, round, digits = RoundDigits)
  return(returnData)
}

#' Calculate aggregated frequency distribution summarizing the database.
#' 
#' Frequencies are re-calculated and aggregated proportions are returned.
#' Used to summarise a database.
#' 
#' @inheritParams getContSummary
#' @param groupingVar vector with variable names used to do grouping
#' 
#' @import dplyr
#' 
#' @details data needs to have a column n and var. 
#' In addition, function is still non-generic.
#' 
#' @author hbossier
#' @export 
getDatabaseSummary <- function(data, groupingVar = 'var', RoundDigits = 3){
  # Make R CMD Check happy
  var <- NULL
  
  # Empty data
  returnData <- data.frame() %>% 
      as_tibble()
  
  # Dev warning
  #warning('groupingVar in dev phase (not used consistently in function getDatabaseSummary)!')
  
  # Checks
  if(!'n' %in% names(data)) stop('Column "n" is missing in data.')
  if(!'var' %in% names(data)) stop('Column "var" is missing in data.')
  if(!'value' %in% names(data)) stop('Column "value" is missing in data.')
  
  # Grouped preprocessed data
  grData <- data %>%
      as_tibble() %>%
      group_by(var) %>%
      mutate(casesPerVar = sum(n)) %>%
      ungroup() %>%
      group_by(var, value) %>%
      mutate(casesPerVarVal = sum(n)) %>%
      ungroup() 
  
  # Now add aggregated proportion, then select the variables and removing the duplicated rows
  returnData <- grData %>%
      mutate(propAgg = casesPerVarVal / casesPerVar) %>%
      select(var, value, nAgg = casesPerVarVal, propAgg) %>%
      distinct() %>%
      arrange(var) %>%
      mutate_if(is.numeric, round ,digits = RoundDigits)
  
  # End
  return(returnData)
}


#' Calculate aggregated frequency distribution to summarise patient level data
#' 
#' Frequencies are recalculated and aggregated proportions are returned.
#' Used to summarise the patient distribution. Two levels of grouping variables
#' need to be provided. Data is first grouped at level one where the number of 
#' cases is calculated. A second level of variables contains less variables where 
#' the proportion per dropped variable is counted (e.g. there is a variable age 
#' with two categories, then age can be added in first level and then dropped so 
#' that proportion is calculated per age category).
#' 
#' @inheritParams getContSummary
#' @param firstLvlGroupVars a vector of variables used to group data at level 1
#' @param secondLvlGroupVars a vector of variables used to group data at level 2
#' This vector contains as many or less number of variables than firstLvlGroupVars
#' @param arrangingVars variables to sort the returning data frame
#' 
#' @import dplyr
#' 
#' @details Data should contain a column count.
#' 
#' @author hbossier
#' @export 
getPatientSummary <- function(data, 
    firstLvlGroupVars = c('SCT_FL', 'LINE_NUMBER', 'IND_ID', 'Characteristics', 
        'CONCEPT_ID', 'CONCEPT_NAME'), 
    secondLvlGroupVars = c('SCT_FL', 'LINE_NUMBER', 'IND_ID', 'LEVELS',
        'Characteristics', 'CONCEPT_ID', 'CONCEPT_NAME'),
    arrangingVars = c('Characteristics', 'LEVELS', 'LINE_NUMBER'), RoundDigits = 3){
  
  # Empty data
  returnData <- data.frame() %>% 
      as_tibble()
  
  # Checks
  if(length(firstLvlGroupVars) > length(secondLvlGroupVars)){
    stop('secondLvlGroupVars should be nested withing firstLvlGroupVars')
  }
  if(!'count' %in% names(data)) stop('Column "count" is missing in data.')
  
# Grouped preprocessed data
  grData <- data %>%
      as_tibble() %>% 
      group_by_at(firstLvlGroupVars) %>%
      mutate(casesPerVar = sum(count)) %>%
      ungroup() %>%
      group_by_at(secondLvlGroupVars) %>%
      mutate(casesPerVarVal = sum(count)) %>%
      ungroup() 
  
# Now add aggregated proportion, then select the variables and removing the duplicated rows
  returnData <- grData %>%
      mutate(propAgg = casesPerVarVal / casesPerVar) %>%
      select(secondLvlGroupVars, nAgg = casesPerVarVal, propAgg) %>%
      distinct() %>%
      arrange_at(arrangingVars) %>%
      mutate_if(is.numeric, round ,digits = RoundDigits)
  
  # End
  return(returnData)
}


#' Calculate summary for regimens variables
#' 
#' For various types of regimens variables, calculate the proportion of levels
#' within a nested variable.
#' Frequencies are recalculated and aggregated proportions are returned.
#' 
#' @inheritParams getContSummary
#' @param groupingVar vector with the variables at highest level grouping the computations on
#' @param dropVar vector with variables from second level that are dropped from the groupingVar
#' @param sortingVar optional variable to sort the table on
#' 
#' @import dplyr
#' 
#' @details Note: [...]
#' 
#' @author hbossier
#' @export 
getRegSummary <- function(data, groupingVar, dropVar, 
    sortingVar = NULL, RoundDigits = 3){
  
  # Checks
  if(!'count' %in% names(data)) stop('column count not found')
  if(!dropVar %in% groupingVar) stop('dropVar not found in groupingVar')
  
  # Empty data and preparation
  returnData <- data.frame() %>% 
      as_tibble()
  secLvlVars <- groupingVar[-which(groupingVar == dropVar)]
  
  # Sorting based on grouping unless specified.
  if(is.null(sortingVar)) sortingVar <- secLvlVars
  
# Grouped preprocessed data
  grData <- data %>%
      as_tibble() %>% 
      group_by_at(groupingVar) %>%
      mutate(casesLvLow= sum(count)) %>%
      ungroup() %>%
      group_by_at(secLvlVars) %>%
      mutate(casesLvHigh  = sum(count)) %>%
      ungroup()
  
# Now add aggregated proportion, then select the variables and removing the duplicated rows
  returnData <- grData %>%
      mutate(propAgg = casesLvLow / casesLvHigh) %>% 
      select(groupingVar, nAgg = casesLvLow, propAgg) %>%
      distinct() %>%
      arrange_at(sortingVar, .funs = desc) %>%
      mutate_if(is.numeric, round ,digits = RoundDigits)
  
  # End
  return(returnData)
}

#' Retrieve info for regimens computations.
#' 
#' Small function to retrieve the default grouping variables, dropVars and
#' sortingVars for each regimen variable used in \code{getRegSummary}.
#' 
#' @param typeRegSum type of regimens summary variable requested (choose between
#' avRegN, regClassN, classSeqCountN, ClassSeqAll or RegSeqAll)
#' 
#' @author hbossier
#' @export 
infoRegComp <- function(typeRegSum = c('avRegN', 'regClassN', 'classSeqCountN',
        'ClassSeqAll', 'RegSeqAll')){
  # Check arguments
  match.arg(typeRegSum, choices = c('avRegN', 'regClassN', 'classSeqCountN',
          'ClassSeqAll', 'RegSeqAll'), several.ok = FALSE)
  
  # Retrieve info
  groupingVar <- switch(typeRegSum,
      avRegN = c('SCT_FL', 'LINE_NUMBER', 'IND_ID', 'Regimens'),
      regClassN = c('SCT_FL', 'LINE_NUMBER', 'IND_ID', 'TRTMNT', 'LINE_REGIMEN_COMBI', 
          'LEVELS', 'variable'),
      classSeqCountN = c('SCT_FL', 'IND_ID', 'trtmntSequence'),
      ClassSeqAll = c('SCT_FL', 'IND_ID', 'classSequence'),
      RegSeqAll = c('SCT_FL', 'IND_ID', 'trtSequence')
  )
  dropVar <- switch(typeRegSum,
      avRegN = 'Regimens',
      regClassN = 'LEVELS',
      classSeqCountN = 'trtmntSequence',
      ClassSeqAll = 'classSequence',
      RegSeqAll = 'trtSequence'
  )
  sortingVar <- switch(typeRegSum,
      avRegN = NULL,
      regClassN = NULL,
      classSeqCountN = 'propAgg',
      ClassSeqAll = 'propAgg',
      RegSeqAll = 'propAgg'
  )
  return(list(groupingVar = groupingVar,
          dropVar = dropVar, sortingVar = sortingVar))
}


#' Retrieve table with info on estimated survival for each stratum.
#' 
#' Given a filtered survival dataset, retrieve number of patients, events, censored events,
#' median survival time per stratum.
#' 
#' @param filtSurvData survival data for several strata (but only one time course per stratum).
#' Needs columns: surv, n.risk, n.event, n.censor and time
#' @param strataVar the name of the variable denoting the strata
#' @param perc decimal the percentile requested (default = median, 0.5)
#' @param RoundDigits integer, round the number of digits (default = 2)
#' 
#' @details Function only returns the number of patients, events, censored events
#' and median survival time. 
#' 
#' @author hbossier
#' @export 
getSurvInfo <- function(filtSurvData, strataVar, perc = 0.5, RoundDigits = 2){
  # Make R CMD Check happy
  time <- NULL
  
  # Input checks
  reqCols <- c('surv','n.risk','n.event', 'n.censor', 'time')
  checkNames <- !reqCols %in% names(filtSurvData)
  if(any(checkNames)){
    stop(paste0("column(s): '",
            paste(reqCols[checkNames], sep = '', collapse = '; '), "' not found in filtSurvData"))
  }
  
  # Switch to decimals
  if(max(filtSurvData$surv, na.rm = TRUE) > 1){
    filtSurvData$survDec <- filtSurvData$surv / 100
  } else {
    filtSurvData$survDec <- filtSurvData$surv
  }
  
  # Calculate table using strata as grouping variable
  returnTable <- filtSurvData %>%
    group_by_at(strataVar) %>%
        summarise(numPat = max(n.risk),
            numEvents = sum(n.event),
            numCensor = sum(n.censor),
            medTime = min(time[survDec < (1 - perc)], na.rm = TRUE))
    
   # Styling
  datTmp <- data.frame(t(returnTable[,-1]))
  names(datTmp) <- unlist(returnTable[,1])
  datTmp <- round(datTmp, digits = RoundDigits)
  row.names(datTmp) <- c('No of Patients at Risk', 'Events',
      'Censored', 'Median Survival (years)')
  
  # End
  return(datTmp)
}


#' Combine treatment by line counts
#' 
#' Just sum the counts per instance treatment by line.
#' 
#' @param data input data, each site included
#' @inheritParams getRegSummary
#' 
#' @import ggalluvial
#' 
#' @details Note: a vector in long format that can be used to plot an alluvial 
#' curve is returned.
#' 
#' @author hbossier, Nolen
#' @export 
combTrtByLineC <- function(data, groupingVar){
  
  # Checks
  if(!'count' %in% names(data)) stop('column count not found')
  
  # We just need to sum counts over the grouping variables while summarising
  sumData <- data %>%
      as_tibble() %>% 
      group_by_at(groupingVar) %>%
      summarise(numCases = sum(count)) %>%
      rename(count = numCases) %>%
      ungroup() 

  # Reshape data 
  temp_long <- ggalluvial::to_lodes_form(sumData,
      key = "Line",
      axes=1:9) 
  temp_long$Line <- gsub("^.*_", "", temp_long$Line)
  returnData <- temp_long[which(temp_long$stratum!="NA"),]
  
  # End
  return(returnData)
}


#' Count number of arrows in vector
#' @param vData vector with e.g. the treatment regimen class sequences
#' 
#' @author hbossier
#' @export 
countArrows <- function(vData){
  sapply(vData, function(x){
        value <- c(gregexpr('-->', x)[[1]])
        sum(value >= 1)
      })
}





