# Project: honeur
#
# Author: hbossier
###############################################################################



#' Combine data from multiple sites
#' 
#' Function to load data from different sites and return in a named list.
#' Note that we read in one site first, than match the entries of the JSON files
#' of the subsequent sites with the first site. 
#' 
#' @param fPath character with location of the json files
#' @param globalInfoFile csv file containing columns 'ResearchQ', 'Site'	and 'dfNames'.
#' These columns contain subsequently the site and the names of the json entries returned by the site.
#' @param startingSite optional string to denote the first site to read data from (otherwise it takes first site from globalInfoFile)
#' @param deleteVars vector with variables within json results that should not be combined into the final result (default = c(1,2))
#' 
#' Function reads a starting site, then tries to match entries found in the other site
#' and returns a combined data frame.
#' 
#' @import dplyr
#' @importFrom tidyr spread
#' 
#' @author hbossier
#' @export
bindSites <- function(fPath, globalInfoFile, startingSite = NULL, 
    deleteVars = c(1,2)){
  
  # Make R CMD Check happy
  plot <- NULL
  
  # Checks
  if(sum(c('ResearchQ', 'Site', 'dfNames') %in% names(globalInfoFile)) != 3){
    stop('globalInfoFile should contain columns ResearchQ, Site and dfNames')
  }
  
  # Info of sites to be reading in
  toReadSites <- unique(globalInfoFile$Site)
  resQ <- as.numeric(unique(globalInfoFile$ResearchQ))
  
  # Switch startingSite depending on user input
  if(is.null(startingSite)){
    startingSite <- toReadSites[1]
  } 
  
  # Try reading in data
  StartSite <- try(
      parseSite(fullPath = paste0(fPath, '/FS1_', startingSite, '_results.json'),
          deleteVars, site = startingSite), 
      silent = TRUE)
  
  # Check
  if(class(StartSite) == 'try-error') stop('Merging data failed in function "bindSites"')
  
  # Assign the names of this site to the list
  names(StartSite) <- globalInfoFile[globalInfoFile$Site == startingSite, 'dfNames']
  # Make a copy
  allData <- StartSite
  
  # Now we read in the next sites
  # Start for loop
  for(iSite in toReadSites[-which(startingSite == toReadSites)]){
    fullPathtmp <- paste0(fPath, '/FS1_', iSite, '_results.json')
    iSite_results <- parseSite(fullPath = fullPathtmp, deleteVars, site = iSite)
    
    # Now loop over the entries and try to match these with previous record
    for(iEntry in 1:length(iSite_results)){
      # Names of variables within the entry
      curNamesVars <- sort(names(iSite_results[[iEntry]]))
      # find a matching ID: lapply goes over each list entry, then the names within that entry are matched
      # against the current variables
      matchIDs <- which(unlist(lapply(StartSite, 
                  function(vars){
                    if(length(vars) == length(curNamesVars)){
                      all(sort(names(vars)) == curNamesVars)
                    } else {
                      FALSE
                    }
                  })), arr.ind = TRUE)
      # If no match is found, do not merge. For now, just leave variable as it is
      if(length(matchIDs) == 0){
        print(paste0('No match found for entry ', iEntry, '. Skipping this one!'))
        next
      }
      # If multiple IDs are found, take the min, unless previous record has already data of this site
      if(length(matchIDs) > 1){
        matchID <- min(matchIDs)
        while(iSite %in% allData[[matchID]]$site){
          matchID <- matchIDs[c(matchID + 1)]
        }
      } else {
        matchID <- matchIDs
      }
      # Print message
      if(iEntry != matchID) print(paste0('Moving entry ', iEntry, ' to position ', matchID,' in allData!'))
      # Finally combine the records in: the current entry should go to matching position of allData!
      allData[[matchID]] <- bind_rows(allData[[matchID]], iSite_results[[iEntry]])
    }
  }
  
  # Now we do some pre-processing steps
  if('KMdataDF' %in% names(allData)){
    allData[['KMdataDF']] <- allData[['KMdataDF']] %>%
        # Change name of columns
        mutate(strata = as.factor(toupper(gsub("PERFORMANCE STATUS ","",strata)))) %>%  
        mutate(strata = as.factor(toupper(gsub("STRATA=","",strata)))) %>%
        # Survival to percentage if plot equals 1
        mutate(surv = ifelse(plot == 1, round(surv*100, 2), surv))
  }
  if('HRAllDF' %in% names(allData)){
    allData[['HRAllDF']] <- allData[['HRAllDF']] %>%  
        mutate(label = as.factor((gsub("performance status ","",(label)))))
  }
  if('CrossLineYear' %in% names(allData)){
    allData[['CrossLineYear']] <- allData[['CrossLineYear']] %>%
        dplyr::select(-n, -prop) %>%
        spread(LOT4CAT, "xxx")
  }
  if('CrossLineSCT' %in% names(allData)){
    allData[['CrossLineSCT']] <- allData[['CrossLineSCT']] %>%
        dplyr::select(-n,-prop) %>%
        spread(SCT_FL, "xxx")
  }
  if('SummaryTab2' %in% names(allData)){
    # This entry is used twice in the application. So I create a seperate entry; 
    # First for patients.
    allData[['SummaryPatient']] <- allData[['SummaryTab2']]
    # Now for regimens which I then rename
    allData[['SummaryTab2']] <- allData[['SummaryTab2']] %>%
        dplyr::filter(Characteristics == 'LINE_REGIMEN') %>% 
        dplyr::rename(Regimens = LEVELS)
    names(allData)[which(names(allData) == 'SummaryTab2')] <- 'SummaryTab'
  }
  
  # End
  return(allData)
}



#' Parse (prepare) JSON file from site
#' 
#' Function to read in data from a site (comming from a JSON file)
#' and prepare to be used in \code{bindSites}
#' 
#' @param fullPath the full path of the JSON file to read in (so containing the JSON file itself)
#' @inheritParams bindSites
#' @param site string the current site reading in data for
#' 
#' @importFrom rjson fromJSON
#' @import dplyr
#' 
#' @author hbossier
#' @export 
parseSite <- function(fullPath, deleteVars = c(1,2), site){
  print(paste0('Parsing file ', fullPath))
  # Create empty list
  parsedList <- list()
  
  # Check and read JSON
  if(is.null(deleteVars)){
    # Read in result
    results_site <- fromJSON(file = fullPath)
  } else {
    results_site <- fromJSON(file = fullPath)[-deleteVars]
  }
  
  # Transform
  for(iEntry in 1:length(results_site)){
    # Unlist any nested list
    for(jLevel in 1:length(results_site[[iEntry]])){
      if (class(results_site[[iEntry]][[jLevel]]) == "list"){
        results_site[[iEntry]][[jLevel]] <- c(unlist(results_site[[iEntry]][[jLevel]])) 
      } 
    }
    # Switch to data frame and add site
    x <- data.frame(results_site[[iEntry]], stringsAsFactors = FALSE)
    x$site = site
    # Problem: columns that have NA, are read in as "NA", which is a character.
    # Thus some columns have numbers but are written as c("123", "NA"), not usefull.
    # We cannot convert each column with a character to numeric as some have meaningful 
    # characters (e.g. <0.001 for p-values). 
    # Solution: convert all "NA" to NA (which is ideal for R).
    x <- mutate_if(x, is.character, replaceNA)
    # Now apply a check: if you convert true characters (e.g. "<0.001") to numeric, then
    # this gives a warning (e.g. coercing characters to NA). 
    # However if you convert columns with NAs and numeric values between quotes, then
    # no warning is generated! So here we try to replace the column with numeric values. 
    # If no warning, then convert! Otherwise the column was probably a character
    # and thus leave as it was!
    x <- mutate_if(x, is.character, tryNumeric)
    parsedList[[iEntry]] <- x
  }
  # END
  return(parsedList)
}


#' Try transform character to numeric
#' 
#' Try transforming a character input. If this gives a warning by R, then
#' characters are converted which means they should not have been converted in the
#' first place and thus we return the original input.
#' Otherwise we return numeric values.
#' 
#' @param input character vector which ought to be checked
#' 
#' @author hbossier
#' @export 
tryNumeric <- function(input){
  # If all values are NA, then skip check
  if(all(is.na(input))) return(as.numeric(input))
  tryTransform <- tryCatch({as.numeric(input)}, 
      warning = function(w){
        'character'
      })
  # If first value is NA, then we know there was no warning
  if(is.na(tryTransform[1])) return(tryTransform)
  # If warning, it should say character
  if(tryTransform[1] == 'character'){
    return(input)
  } else {
    # Note tryTransform, if succeeded without warning is equal to as.numeric(input)
    return(tryTransform)
  }
}

#' Change "NA" to NA
#' 
#' @param col the columns
#' @author hbossier
#' @export 
replaceNA <- function(col){
  colIDs <- grepl("NA", col)
  col[colIDs] <- NA
  return(col)
}









