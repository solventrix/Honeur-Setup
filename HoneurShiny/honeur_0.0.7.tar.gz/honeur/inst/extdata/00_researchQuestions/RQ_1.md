# A retrospective analysis of RWD investigating the treatment patterns and outcomes among Newly Diagnosed MM
<br>
<hr>

## Participating Site(s)

* Registry of Monoclonal Gammopathies (RMG) database by the Czech Myeloma Group
* EMMOS

## Objective

To describe and characterise the following:

* Patient Characteristics
* Disease Characteristics
* Treatment regimens used
* Regimens by Class
* Treatment Sequence
* Time-to event Outcomes and Responses

## Inclusion Criteria

Patients >= 18 years, non-eligible for transplantation, treated in front-line from January 2008 to June 2019

###  Notes
Patients were excluded if Treatment Line has: </span>
* Missing Line Number
* Line_Start date = 1970-01-01 (Missing)
* Line Start Date > Next Treatment Line Start Date

Baseline Laboratory Characteristics Extraction by Line:
* Characteristics captured at the start of each treatment line with a search window of [-28, +7] days

With Missing Dates ("1970-01-01")
* LINE_START_DATE = 1970 - excluded
* LINE_END_DATE = 1970 - will be used for Time on Treatment

Transplant ineligible is defined as patients who did not have any of the following:
* Autologous peripheral blood stem cell transplant
* Peripheral blood stem cell graft
* Allogeneic peripheral blood stem cell transplant

Censor date: minimum of (Last Date the Patient is known to be alive in the database (laboratory Measurement, Observation, Treatment dates,...), Analysis Cut-off)
* Patients with Last Contact date greater than Death date

### Data Inconsistencies
* Patients with Treatment Line Start Date greater than the Line End Date when Line end Date is not Missing (1970-01-01)
