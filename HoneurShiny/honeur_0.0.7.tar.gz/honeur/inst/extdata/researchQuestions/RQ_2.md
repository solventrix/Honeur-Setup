# Second Research Question
## First results
<br>
<hr>

## Participating Site(s)

* University Hospital Ghent
* UAntwerpen

## Objective

To gain insights.

## Inclusion Criteria

Patients >= 18 years

###  Notes

This is fictional!
