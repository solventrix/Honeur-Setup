# Project: honeur
#
# Author: hbossier
###############################################################################

shiny::shinyUI(fluidPage(
        useShinyjs(),
        
        # For debug
        uiOutput("debug"),
        
#        # If needed: report & console output
#        tags$div(style = "margin-top:10px;",
#            downloadButton("downloadReport", label = "Download report"),
#            downloadButton("downloadConsole", "Download console output")
#        ),
        
        helpText(
            actionLink(inputId = "about", label = h5("Manual", align = "right")) 
        ),
        
        titlePanel(title = div(
                img(src = "honeur_logo.png", height = "100px", hspace = "90px"),
                "Aggregated Analyses Portal"), 
            windowTitle = "Aggregated Analyses Portal"),
        
        tags$div(style = "color:gray; margin-right:15px", textOutput("version"), align = "right"),
        
        tags$br(),
        
        # Tabs
        tabsetPanel(id = "tabs",
            source(file.path("uiFiles", "1_uiResQ.R"), local = TRUE)$value,
            source(file.path("uiFiles", "2_uiDescriptives.R"), local = TRUE)$value,
            source(file.path("uiFiles", "3_uiAnalysis.R"), local = TRUE)$value,
            source(file.path("uiFiles", "4_uiDownload.R"), local = TRUE)$value
        )
    )
)


