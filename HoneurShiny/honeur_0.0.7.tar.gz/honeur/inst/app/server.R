jsCode <- "shinyjs.pageCol = function(params){$('body').css('background', params);}"

serverFunction <- function(input, output, session){
  
  # Section for debugging
  output$debug <- renderUI({
        
        if (doDebug)
          tags$p(
              actionLink("debug_console", "Connect with R Console", icon = icon("exchange")),
              verbatimTextOutput("debug_print")
          )
        
      })
  
  # For debugging
  observe({
        
        if (is.null(input$debug_console))
          return(NULL)
        
        if (input$debug_console > 0) {
          
          options(browserNLdisabled = TRUE)
          saved_console <- ".RDuetConsole"
          if (file.exists(saved_console)) {load(saved_console)}
          isolate(browser())
          save(file = saved_console, list = ls(environment()))
          
        }
        
      })
  
  # Package versions
  output$version <- renderText({
        paste0("Application version: ", packageVersion("honeur"))
      })
  
  # Source server files
  source(file.path("serverFiles", "1_serverResQ.R"), local = TRUE)$value
  source(file.path("serverFiles", "2_serverDescriptives.R"), local = TRUE)$value
  source(file.path("serverFiles", "3_serverAnalysis.R"), local = TRUE)$value
  source(file.path("serverFiles", "4_serverDownload.R"), local = TRUE)$value
  
  
}


