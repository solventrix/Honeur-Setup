
function activateTableLink(o) {
	var inputid = o.getAttribute("inputid");
	var row = o.getAttribute("row");
	var d = new Date();
	Shiny.onInputChange(inputid, d);
	Shiny.onInputChange(inputid, row);	
}

