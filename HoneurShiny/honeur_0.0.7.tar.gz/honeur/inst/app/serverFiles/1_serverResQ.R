# Project: honeur
#
# Author: hbossier
###############################################################################

# Reactive values
inputValues <- reactiveValues(
    selectedRQ = NULL,
    availSites = NULL,
    loadedData = NULL,
    prevConLine = 1
)
outputValues <- reactiveValues(
    summaries = NULL
)

# Observe input values
observe({
      input$con_lineNumber
      inputValues$prevConLine <- input$con_lineNumber
    })


#######################
### 1. Shiny Reactivity
#######################

# Update values when research question is selected
observeEvent(input$resQ, {
      # Selected research question
      selRQ <- unlist(possResQ[match(input$resQ, possResQ$Value), 'Key'])
      # Available sites
      file <- paste0('../extdata/01_dataSites/', selRQ, '/data_', selRQ,'.csv')
      avSites <- unique(unlist(data.table::fread(file)$Site))
      
      # Update checkboxes
      updatePrettyCheckboxGroup(session, inputId = "avSites", 
          label = 'Available sites to be included in the analysis:',
          choices = avSites, selected = avSites, inline = TRUE, 
          prettyOptions = list(shape = 'round', outline = TRUE, status = 'info'))
      
      # File path for data and global information
      fPath <- file.path("../extdata/01_dataSites", selRQ)
      
      # Update reactive value
      inputValues$selectedRQ <- selRQ
      inputValues$availSites <- avSites
      inputValues$fPath <- fPath
      inputValues$globalInfoFile <- read.csv(paste0(fPath,'/data_',selRQ,'.csv'))
    })


# Research question information is assembled in Markdown files in extdata/00_researchQuestions
output$markdownInfo <- renderUI({
      if(!is.null(inputValues$selectedRQ)){
        # Depending on input
        file <- switch(inputValues$selectedRQ,
            resQ1 = "../extdata/00_researchQuestions/RQ_1.md",
            resQ2 = "../extdata/00_researchQuestions/RQ_2.md",
            resQ3 = "../extdata/00_researchQuestions/RQ_3.md",
            stop("Unknown option: contact a developer.")
        )
        includeMarkdown(file)
      } else {
        NULL
      }
    })



###################
### 2. CALCULATIONS
###################



# Aggretate data when button is pushed
observeEvent(input$mergeData, {
      req(inputValues$availSites)
      
      # Display message
      shiny::showModal(shiny::modalDialog("Aggregating Sites...", footer = NULL))
      
      # Information (starting site --> EMMOS comes from dev phase)
      if('EMMOS' %in% inputValues$availSites){
        startingSite <- 'EMMOS'
      } else {
        startingSite <- inputValues$availSites[1]
      }
      
      # Make data available (set to NULL if no sites were selected)
      if(inputValues$availSites[1] == ""){
        inputValues$loadedData <- NULL
      } else {
        inputValues$loadedData <- bindSites(fPath = inputValues$fPath, 
            globalInfoFile = inputValues$globalInfoFile,
            startingSite = startingSite)
      }
      
      # Get summary statistics based on the aggregated data
      if(!is.null(inputValues$loadedData)){
        outputValues$summaries <- getAggregatedStats(inputValues$loadedData,
            descTabs(
                contN = "SummaryTabCont",
                dbN = "LOTFreq",
                patN = "SummaryPatient",
                avRegN = "SummaryTab", 
                regClassN = "SummaryReg", 
                classSeqCountN = "TrtmntSeqAll",
                regCountN = "ClassSeqAll",
                regSeqN = "RegSeqAll",
                trtByLineNN = 'TrtByLineNumbers',
                kmN = "KMdataDF"),
            RoundDigits = 30)
        
        # Read in survival data which has been pre-processed and saved in extdata.
        # It takes too long to compute 
        # (alternative option: switch to lag-1 approach and compute on the fly?).
        outputValues$summaries[['KMSum']] <- 
            readRDS(paste0('../extdata/03_dataIntermediate/',inputValues$selectedRQ,'/survivalEMMOS_CMG.rds'))
        
        # Bind individual sites to aggregated stats
        outputValues$allInfo <- bindIndAggSites(aggStats = outputValues$summaries, 
            allData = inputValues$loadedData, 
            entries = descTabs(
                contN = "SummaryTabCont",
                dbN = "LOTFreq",
                patN = "SummaryPatient",
                avRegN = "SummaryTab", 
                regClassN = "SummaryReg", 
                classSeqCountN = "TrtmntSeqAll",
                regCountN = "ClassSeqAll",
                regSeqN = "RegSeqAll",
                trtByLineNN = 'TrtByLineNumbers',
                kmN = "KMdataDF"))
        
      } else {
        outputValues$summaries <- NULL
        outputValues$allInfo <- NULL
      }
      
      # Write the alluvial plots to a temp folder: maybe move this to pre-processing
#      plotAlluvial(alluvData = outputValues$summaries[['trtByLineSum']],
#          onDevice = 'file', fPath = tmpDir)
#      # Same for ind sites?

      
      # Finish
      shiny::removeModal()
      
      # Switch to descriptive statistics 
      updateTabsetPanel(session, "tabs", 
          selected = "Descriptive Statistics")
    })


# Update UI values when output data changes or another sct_fl value is selected
observeEvent({
      outputValues$summaries
      input$con_sct_fl
    }, {
      # Requires both the input of continuous as summary data
      req(input$con_sct_fl)
      req(outputValues$summaries)
      
      # Common UI input: note I take the ID from continuous data, 
      # but I suppose this is the same for all variables
      updateSelectizeInput(session, 'ind_id', label = 'Select disease id', 
          choices = c(unique(outputValues$summaries[['contSum']]$IND_ID)))
      
      # Continuous: with selection variable
      optionsTrtmntCon <- outputValues$summaries[['contSum']] %>%
          filter(SCT_FL == input$con_sct_fl) %>%
          tidyr::drop_na() %>%
          pull(LINE_NUMBER) %>%
          unique()
      newSelectionCont <- min(as.numeric(inputValues$prevConLine), max(optionsTrtmntCon))
      
      # Update options to select from
      updatePrettyRadioButtons(session, inputId = "con_lineNumber", 
          label = 'Treatment Line',
          choices = optionsTrtmntCon,
          selected = newSelectionCont, inline = TRUE, 
          prettyOptions = list(shape = 'round', outline = TRUE, status = 'info'))
      
      # Categorical: database
      updateSelectizeInput(session, 'DB_plot', 
          label = "Plot 'variable'",
          choices = getNamedList(unique(outputValues$summaries[['DBSum']]$var)))
      
      # Categorical: patient characteristics
      updateSelectizeInput(session, 'pat_selVar', 
          label = 'Select Concept',
          choices = na.omit(unique(outputValues$summaries[['patientSum']]$CONCEPT_NAME)))
      
      # Treatment sequence (regimen)
      updateSelectizeInput(session, 'trtmntSeq_selVar', label = 'Select Class', 
          choices = unique(outputValues$summaries[['regimensByClassSum']]$TRTMNT))
      
      # Survival
      updatePrettyRadioButtons(session, 
          inputId = 'KM_showSites', 
          label = 'Select sites to plot next to aggregated curve',
          choices = c(inputValues$availSites), inline = TRUE,
          prettyOptions = list(shape = 'round', outline = TRUE, status = 'info'))
      updateSelectizeInput(session, 'KM_selVar', label = 'Select Stratification Variable', 
          choices = getNamedList(names(outputValues$summaries[['KMSum']])))
    })




