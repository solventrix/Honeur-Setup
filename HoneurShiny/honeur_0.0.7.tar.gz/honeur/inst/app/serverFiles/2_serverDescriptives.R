# Project: honeur
#
# Author: hbossier
###############################################################################

# HB TODO: check number of colours exceeding available colours in survival curve

##################
## PREPARATION
##################

# Reactive values
reaValDes <- reactiveValues(
    DBBarPlot = NULL,
    prevPatLine = 1,
    prevTrtmSeqLine = 1,
    prevSurvLine = 1,
    prevSurvEndP = 1
)

# Make sure the reactive value of inputs are updated (needed for preservation of selection of radiobuttons)
observe({
      input$pat_lineNumber
      input$trtmntSeq_lineNumber
      input$KM_lineNumber
      input$KM_endpoint
      reaValDes$prevPatLine <- input$pat_lineNumber
      reaValDes$prevTrtmSeqLine <- input$trtmntSeq_lineNumber
      reaValDes$prevSurvLine <- input$KM_lineNumber
      reaValDes$prevSurvEndP <- input$KM_endpoint
    })


# Common UI values
output$siteInputUI <- renderUI({
      if(input$descriptive_main_panel != 'survival') {
        prettyRadioButtons(inputId = "avSitesDescTabs", 
            label = 'Show data for:',
            shape = 'round', outline = TRUE, status = 'info',
            inline = TRUE, 
            choices = c(inputValues$availSites, 'ALL SITES (aggregated)' = 'aggregated'),
            selected = 'aggregated')
      }
      
    })

## ---------------- ##
## Categorical DB   ##
## ---------------- ##

# Prepare plotting
observeEvent({
      input$DB_plot
      input$avSitesDescTabs
    }, {
      # Requirements
      req(input$avSitesDescTabs)
      if(input$DB_plot == ""){
        NULL
      } else {
        reaValDes$DBBarPlot <- filter(outputValues$allInfo[['DBSum']],
                site == input$avSitesDescTabs,
                var == input$DB_plot) %>%
            mutate(proportion = round(prop * 100, 2))
        reaValDes$DBBarPlot$value <- factor(reaValDes$DBBarPlot$value, 
            levels = reaValDes$DBBarPlot$value)
      }
    })


## ---------------------- ##
## Categorical Patients   ##
## ---------------------- ##


# Depending on selection of variable, update UI of categorical patient
observeEvent({
      input$pat_selVar
      input$avSitesDescTabs
      input$pat_sct_fl
    }, {
      req(input$avSitesDescTabs)
      # Only run after variable is selected
      if(input$pat_selVar == ""){
        NULL
      } else {
        # Update the values using input$selVar
        lineNumbs <- outputValues$allInfo[['patientSum']] %>%
            filter(SCT_FL == as.numeric(input$pat_sct_fl),
                CONCEPT_NAME == input$pat_selVar, 
                site == input$avSitesDescTabs) %>%
            pull(LINE_NUMBER) %>%
            unique(.) %>% as.numeric(.) %>% sort(.)
        # Check with previous selection
        newSelection <- min(as.numeric(reaValDes$prevPatLine), max(lineNumbs))
        #print(paste0('New selection = ', newSelection))
        
        # Note: seleted tries to keep the previous selected value
        updatePrettyRadioButtons(session, inputId = "pat_lineNumber", 
            label = 'Treatment Line', choices = lineNumbs,
            selected = newSelection,
            inline = TRUE, 
            prettyOptions = list(shape = 'round', outline = TRUE, status = 'info'))
      }
    })



# Prepare plotting
observeEvent({
      input$pat_selVar
      input$ind_id
      input$avSitesDescTabs
      input$pat_lineNumber
    }, {
      req(input$avSitesDescTabs)
      if(input$pat_selVar == "" || input$ind_id == ""){
        NULL
      } else {
        # Create data frame that will be used to plot
        reaValDes$catPatPlot <- outputValues$allInfo[['patientSum']] %>%
            filter(site == input$avSitesDescTabs,
                SCT_FL == input$pat_sct_fl, 
                LINE_NUMBER == input$pat_lineNumber,
                IND_ID == input$ind_id, 
                CONCEPT_NAME == input$pat_selVar) %>%
            rename(total = n, proportion = prop) %>%
            select(LEVELS, proportion) %>%
            mutate(proportion = round(proportion*100,2))
        # Make factor for ordening
        reaValDes$catPatPlot$LEVELS <- factor(reaValDes$catPatPlot$LEVELS, 
            levels = reaValDes$catPatPlot$LEVELS)
      }
    })

## ------------- ##
## TRMTNT SEQ    ##
## ------------- ##

# Depending on selection of variable, update UI of treatment sequences
observeEvent({
      input$trtmntSeq_selVar
      input$avSitesDescTabs
    }, {
      req(input$avSitesDescTabs)
      # Only run after variable is selected
      if(input$trtmntSeq_selVar == ""){
        NULL
      } else {
        # Using input$selVar
        lineNumbs <- outputValues$allInfo[['regimensByClassSum']] %>%
            filter(TRTMNT == input$trtmntSeq_selVar,
                site == input$avSitesDescTabs) %>%
            pull(LINE_NUMBER) %>%
            unique(.) %>% sort(.)
        # Check with previous selection
        newSelection <- min(as.numeric(reaValDes$prevTrtmSeqLine), max(lineNumbs))
        
        updatePrettyRadioButtons(session, inputId = "trtmntSeq_lineNumber", 
            label = 'Treatment Line',
            choices = lineNumbs, selected = newSelection, inline = TRUE, 
            prettyOptions = list(shape = 'round', outline = TRUE, status = 'info'))

      }
    })

## ----------- ##
## Survival    ##
## ----------- ##

# Depending on selection of variable, update UI of survival
observeEvent(input$KM_selVar, {
      # Only run after variable is selected
      if(input$KM_selVar == ""){
        NULL
      } else {
        # Using input$KM_selVar
        lineNumbs <- unique(outputValues$summaries[['KMSum']][[input$KM_selVar]]$LINE_NUMBER)
        endPnts <- unique(outputValues$summaries[['KMSum']][[input$KM_selVar]]$endpoint)
        # Rename endpoints
        endPRename <- getFullEndP(endPnts)
        newSelLine <- min(as.numeric(reaValDes$prevSurvLine), max(lineNumbs))
        newSelEndPnts <- ifelse(reaValDes$prevSurvEndP %in% endPnts, 
            reaValDes$prevSurvEndP,
            endPnts[1])
        print(paste0('Current selected endpoint = ', newSelEndPnts))
        
        # Update values
        updatePrettyRadioButtons(session, 'KM_endpoint', 
            label = 'Select endpoint', 
            choices = getNamedList(endPnts), 
            selected = newSelEndPnts,
            inline = FALSE,
            prettyOptions = list(shape = 'round', outline = TRUE, status = 'info'))
        updatePrettyRadioButtons(session, inputId = "KM_lineNumber", 
            label = 'Treatment Line',
            choices = lineNumbs,
            selected = newSelLine, inline = TRUE, 
            prettyOptions = list(shape = 'round', outline = TRUE, status = 'info'))
      }
    })


##################
## GRAPHICS/TABLES
##################


## ------------- ##
## Continuous    ##
## ------------- ##

# Continuous variables: table
output$tableCont <- renderDT({
      # Only run when there is data
      if(any(is.null(input$avSitesDescTabs), 
          is.null(outputValues$allInfo[['contSum']]))){
        NULL
      } else {
        dataToShow <- filter(outputValues$allInfo[['contSum']], 
                site == input$avSitesDescTabs,
                IND_ID == input$ind_id & 
                    SCT_FL == input$con_sct_fl &
                    LINE_NUMBER == input$con_lineNumber) %>% 
            select(-IND_ID, -SCT_FL, -LINE_NUMBER, -site) %>%
            mutate_if(., is.numeric, round, digits = 2)
        DT::datatable(dataToShow, 
            options = list(scrollX = TRUE), class = 'cell-border stripe',
        )
      }
    })

## ---------------- ##
## Categorical DB   ##
## ---------------- ##

# Categorical data: table
output$tableDB <- renderDT({
      # Only run when there is data
      if(is.null(outputValues$allInfo[['DBSum']])){
        NULL
      } else {
        dataToShow <- outputValues$allInfo[['DBSum']] %>%
            filter(site == input$avSitesDescTabs) %>%
            rename(variable = var, total = n, proportion = prop) %>%
            mutate(proportion = round(proportion * 100, 2)) %>%
            select(-site)
        DT::datatable(dataToShow, 
            options = list(scrollX = TRUE), class = 'cell-border stripe',
        )
      }
    })

# Categorical data: barplot
output$barPlotDB <- renderPlotly(
    plot_ly(
            x = reaValDes$DBBarPlot$value,
            y = reaValDes$DBBarPlot$proportion,
            name = input$DB_plot,
            type = "bar"
        ) %>% 
        layout(title = input$DB_plot,
            yaxis = list(title = "Proportion (%)"))
)

## ---------------------- ##
## Categorical Patients   ##
## ---------------------- ##

# Categorical data: table
output$tablePat <- renderDT({
      # Only run when there is data
      if(is.null(outputValues$allInfo[['patientSum']])){
        NULL
      } else {
        dataToShow <- outputValues$allInfo[['patientSum']] %>%
            filter(site == input$avSitesDescTabs,
                SCT_FL == input$pat_sct_fl, 
                LINE_NUMBER == input$pat_lineNumber,
                IND_ID == input$ind_id, 
                CONCEPT_NAME == input$pat_selVar) %>%
            rename(total = n, proportion = prop) %>%
            select(LEVELS, total, proportion, -site) %>%
            mutate(proportion = round(proportion*100,2))
        DT::datatable(dataToShow, 
            options = list(scrollX = TRUE), class = 'cell-border stripe',
        )
      }
    })

# Barplot
output$barplotPat <- renderPlotly(
    plot_ly(
            x = reaValDes$catPatPlot$LEVELS,
            y = reaValDes$catPatPlot$proportion,
            name = input$selVar_pat,
            type = "bar"
        ) %>% 
        layout(title = input$selVar_pat,
            yaxis = list(title = "Proportion (%)"))
)


## ------------------ ##
## TRTMNT REGIMENS    ##
## ------------------ ##

# Regimens table
output$tableRegSeq <- renderDT({
      # Only run when there is data
      if(is.null(outputValues$allInfo[['avRegSum']])){
        NULL
      } else {
        
        # Available regimens
        if(input$selRegimenTable == 'Available Regimens'){
          dataToShow <- outputValues$allInfo[['avRegSum']] %>%
              filter(site == input$avSitesDescTabs,
                  SCT_FL == as.numeric(input$trtmntSeq_sct_fl),
                  LINE_NUMBER == as.numeric(input$trtmntSeq_lineNumber),
                  IND_ID == input$ind_id) %>%
              mutate(prop = round(prop * 100, 2)) %>%
              rename(total = n, 'proportion (%)' = prop) %>%
              select(-SCT_FL, -LINE_NUMBER, -IND_ID, -site) %>%
              arrange(desc(total))
        } 
        
        # Regimens by class
        if(input$selRegimenTable == 'Regimens by Class'){
          # Only run when all options are available
          if(input$trtmntSeq_selVar == ""){
            dataToShow <- NULL
          } else {
            dataToShow <- outputValues$allInfo[['regimensByClassSum']] %>%
                filter(site == input$avSitesDescTabs,
                    TRTMNT == input$trtmntSeq_selVar,
                    SCT_FL == as.numeric(input$trtmntSeq_sct_fl),
                    IND_ID == input$ind_id)
            # Line of treatment selection depends on checkbox in UI
            if(input$regByClass_indTrtLine == 1){
              dataToShow <- filter(dataToShow,
                  LINE_NUMBER == as.numeric(input$trtmntSeq_lineNumber))
            } else {
              dataToShow <- filter(dataToShow,
                  LINE_NUMBER <= as.numeric(input$trtSeq_lineN_Max))
              # Need to re-calculate proportions!
            }
            # Continue with mutating, selecting and renaming
            dataToShow <- dataToShow %>%
                mutate(prop = round(prop * 100, 2)) %>%
                rename(total = n, 'proportion (%) of level within combi' = prop) %>%
                select(-variable, -SCT_FL, -LINE_NUMBER, -IND_ID, -TRTMNT, -site)
          }
        } 
        
        # Class sequence counts
        if(input$selRegimenTable == 'Treatment Class Sequence Count'){
          dataToShow <- outputValues$allInfo[['trtSeqCSum']] %>%
              filter(site == input$avSitesDescTabs,
                  SCT_FL == as.numeric(input$trtmntSeq_sct_fl),
                  IND_ID == input$ind_id) %>%
              # Filter on max number of treatments
              filter(maxNumTrt <= input$levelClassSeqCount) %>%
              mutate(prop = round(prop * 100, 2)) %>% 
              rename(total = n, 'proportion (%)' = prop, 
                  'Treatment Class Sequence' = trtmntSequence) %>%
              select(-SCT_FL, -IND_ID, -site, -maxNumTrt, -arrows)
        } 
        
        # Grouped Regimen counts
        if(input$selRegimenTable == 'Grouped Regimen Count'){
          dataToShow <- outputValues$allInfo[['regCSum']] %>%
              filter(site == input$avSitesDescTabs,
                  SCT_FL == as.numeric(input$trtmntSeq_sct_fl),
                  IND_ID == input$ind_id) %>% 
              # Filter on max number of treatments
              filter(maxNumTrt <= input$levelGrRegCount) %>%
              mutate(prop = round(prop * 100, 2)) %>% 
              rename(total = n, 'proportion (%)' = prop, 
                  'Grouped Regimen Sequence' = classSequence) %>%
              select(-SCT_FL, -IND_ID, -site, -maxNumTrt, -arrows)
        } 
        
        # Treatment Regimen Sequence
        if(input$selRegimenTable == 'Treatment Regimen Sequence'){
          dataToShow <- outputValues$allInfo[['regSeqSum']] %>%
              filter(site == input$avSitesDescTabs,
                  SCT_FL == as.numeric(input$trtmntSeq_sct_fl),
                  IND_ID == input$ind_id) %>% 
              # Filter on max number of treatments
              filter(maxNumTrt <= input$levelSeqRegimen) %>%
              mutate(prop = round(prop * 100, 2)) %>% 
              rename(total = n, 'proportion (%)' = prop, 
                  'Treatment Regimen Sequence' = trtSequence) %>%
              select(-SCT_FL, -IND_ID, -site, -maxNumTrt, -arrows)
        } 
        
        # Print the table
        DT::datatable(dataToShow, 
            options = list(scrollX = TRUE), class = 'cell-border stripe',
        )
      }
    })

# Alluvial plot: for speed, this has been written in tmp folder
#output$alluvial <- renderPlot({
#      plotAlluvial(outputValues$summaries[['trtByLineSum']])
#    }, height = 800)

output$alluvial <- renderImage({
      # Select the appropriate filename
      fileSwitch <- switch(input$avSitesDescTabs,
          'CMG' = 'alluvial_CMG.png',
          'EMMOS' = 'alluvial_EMMOS.png',
          'aggregated' = 'alluvial_aggregated.png',
          NULL = ""
          )
      # Read alluvial width and height. 
      width  <- session$clientData$output_alluvial_width
      height <- session$clientData$output_alluvial_height
      #filename <- normalizePath(file.path(tmpDir, '/alluvial.png'))
      filename <- normalizePath(file.path('../extdata/03_dataIntermediate/resQ1/', fileSwitch))
      
      # Return a list containing the filename
      list(src = filename,
          width = width,
          height = height)
      
    }, deleteFile = FALSE)

## ----------- ##
## Survival    ##
## ----------- ##

# Plots
output$KMPlotAll <- renderPlot({
      plotKMCurve(outputValues$summaries[['KMSum']],
          variable = input$KM_selVar,
          end_point = input$KM_endpoint, 
          line_number = input$KM_lineNumber,
          sct_fl = input$KM_sct_fl)
    })
output$KMPlotIndividual <- renderPlot({
      plt <- plotKMCurve(survData = outputValues$summaries[['KMSum']],
          variable = input$KM_selVar,
          end_point = input$KM_endpoint, 
          line_number = input$KM_lineNumber,
          sct_fl = input$KM_sct_fl,
          site = input$KM_showSites,
          giveTable = TRUE)
      if(plt == 'No data available...'){
        showNotification(paste0('No data available for site ', input$KM_showSites), duration = 4, 
            type = 'warning')
      } else {
        plt
      }
    })

# Tables
output$tableSurvivalAll <- renderDT({
      filtSurvData <- 
          outputValues$summaries[['KMSum']][[input$KM_selVar]] %>%
          filter(typeSite == 'aggregated',
              endpoint == input$KM_endpoint,
              LINE_NUMBER == input$KM_lineNumber,
              SCT_FL == input$KM_sct_fl)
      toShow <- getSurvInfo(filtSurvData, 'strata')
      DT::datatable(toShow, 
          options = list(scrollX = TRUE, dom = 't'), class = 'cell-border stripe',
      )
    })

output$tableSurvivalIndividual <- renderDT({
      filtSurvData <- 
          outputValues$summaries[['KMSum']][[input$KM_selVar]] %>%
          filter(typeSite == input$KM_showSites,
              endpoint == input$KM_endpoint,
              LINE_NUMBER == input$KM_lineNumber,
              SCT_FL == input$KM_sct_fl)
      toShow <- getSurvInfo(filtSurvData, 'strata')
      DT::datatable(toShow, 
          options = list(scrollX = TRUE, dom = 't'), class = 'cell-border stripe',
      )
    })
output$siteSurvival <- renderText(
    input$KM_showSites
)
