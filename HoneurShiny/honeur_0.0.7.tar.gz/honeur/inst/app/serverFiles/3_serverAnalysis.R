# Project: honeur
#
# Author: hbossier
###############################################################################



##################
## CALCULATIONS
##################

plotPars <- reactiveValues(
    avVars = NULL,
    pltHeight = NULL)

# Generate UI
output$siteInputUIAnalysis <- renderUI({
        prettyRadioButtons(inputId = "avSitesAnTab", 
            label = 'Show univariate analysis for:',
            shape = 'round', outline = TRUE, status = 'info',
            inline = TRUE, 
            choices = inputValues$availSites)
    })

# Update UI Values
observeEvent({
      inputValues$loadedData
      input$avSitesAnTab
    }, {
      req(input$avSitesAnTab)
      # Only when data is av.
      if(is.null(inputValues$loadedData)){
        NULL
      } else {
        # Available values
        avLineNumbers <- inputValues$loadedData[['HRAllDF']] %>%
            filter(site == input$avSitesAnTab) %>%
            pull(LINE_NUMBER) %>% unique(.)
        avVariables <- inputValues$loadedData[['HRAllDF']] %>%
            filter(site == input$avSitesAnTab) %>%
            pull(variable) %>% unique(.)
        # Also make the available variables available in reactive value (for usage later on)
        plotPars$avVars <- avVariables
        avEndpoints <- inputValues$loadedData[['HRAllDF']] %>%
            filter(site == input$avSitesAnTab) %>%
            pull(endpoint) %>% unique(.)
        
        updatePrettyRadioButtons(session, inputId = "lineNumber_UniSite", 
            label = 'Treatment Line',
            choices = avLineNumbers, inline = TRUE, 
            prettyOptions = list(shape = 'round', outline = TRUE, status = 'info'))
        updateSelectizeInput(session, 'selVar_UniSite',
            label = 'Select variable', 
            choices = getNamedList(vecAbbr = avVariables))
        updatePrettyRadioButtons(session, 'endpoint_UniSite', 
            label = 'Select endpoint', 
            choices = getNamedList(avEndpoints), inline = FALSE,
            prettyOptions = list(shape = 'round', outline = TRUE, status = 'info'))
      }
    })



##################
## VISUALIZATIONS
##################

# Table with regression results
output$univariateSite <- renderDT({
      if(is.null(input$avSitesAnTab)){
        return(NULL)
      } else {
        dataTable <- inputValues$loadedData[['HRAllDF']] %>%
            filter(site == input$avSitesAnTab,
                variable == input$selVar_UniSite,
                LINE_NUMBER == input$lineNumber_UniSite,
                endpoint == input$endpoint_UniSite,
                SCT_FL == input$sct_fl_UniSite) %>%
            rename(Comparisson = label,
                n = records,
                Events = events,
                Median_days = median,
                Hazard_Ratio = HR,
                LCL = Lower.CI,
                UCL = Upper.CI,
                Pvalue = p) %>%
            select(Comparisson, n, Events, Median_days, Hazard_Ratio,
                LCL, UCL, Pvalue)
        DT::datatable(dataTable, 
            options = list(scrollX = TRUE, dom = 't'), 
            class = 'cell-border stripe',
        ) %>% formatRound(columns=c('Pvalue'), digits=3)
      }
    })

# Forrest plot
#plotHeight <- reactive({
#      if(is.null(input$avSitesAnTab)){
#        myData <- numeric(0)
#      } else {
#        myData <- inputValues$loadedData[['HRAllDF']] %>%
#            filter(site == input$avSitesAnTab)
#      }
#      if (length(myData) < 18) 
#        return(400)
#      if (length(myData) >= 18) 
#        return(800) 
#    })


# HB TODO make height dynamic
output$forest <- renderPlot({
      if(is.null(input$avSitesAnTab) | input$selVar_UniSite == "" | 
          input$endpoint_UniSite == 'placeholder' | is.null(plotPars$avVars)){
        toPlot <- NULL
      } else {
        myData <- inputValues$loadedData[['HRAllDF']] %>%
            filter(site == input$avSitesAnTab,
                SCT_FL == input$sct_fl_UniSite)
        plotPars$pltHeight <- plotHeight(myData)
        # Create stratification variables
        if(input$selVar_UniSite_All){
          strtFactors <- plotPars$avVars
        } else {
          strtFactors <- input$selVar_UniSite
        }
        # Create plot
        toPlot <- honeurForest(data = myData, 
            line = as.numeric(input$lineNumber_UniSite),
            site = input$avSitesAnTab,
            stratfactors = strtFactors,
            endpoint = input$endpoint_UniSite,
            fontSize = 1.2,
            cexErr = 1.3)

        print(plotPars$pltHeight)
      }
      toPlot
    }, height = 600, unit = 'px')




