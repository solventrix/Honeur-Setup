# Project: honeur
#
# Author: hbossier
###############################################################################

tabPanel("Download Results",
    
    wellPanel("Under construction"),
    shinysky::actionButton('downRes', label = 'Download Results',
        styleclass = "primary", block = FALSE)
)