# Project: honeur
#
# Author: hbossier
###############################################################################


tabPanel("Analysis",
    
    # Slider customization
    chooseSliderSkin("Modern"),
    setSliderColor('LightSeaGreen', c(1,2)),
    
    sidebarLayout(
        ## ---------- ##
        ## Side Panel ##
        ## ---------- ##
        
        sidebarPanel(
            h4(HTML("Data Selection Tools")),
            tags$hr(),
            fluidRow(
                htmlOutput("siteInputUIAnalysis"),
                #selectizeInput('ind_id_UniSite', label = 'Select disease id', choices = NULL),
                shinyWidgets::prettyRadioButtons('sct_fl_UniSite', 
                    label = 'Patients eligible for transplantation?', 
                    choices = c('Yes' = 1, 'No' = 0), inline = TRUE, 
                    selected = 1, shape = 'round', outline = TRUE, status = 'info'),
                # Update in server
                conditionalPanel(condition = 'input.selVar_UniSite_All == false',
                    selectizeInput('selVar_UniSite', label = 'Select variable', 
                        choices = NULL)
                    ),
                # Or show them all
                shinyWidgets::prettyCheckbox(inputId = 'selVar_UniSite_All',
                    label = 'Or plot all variables at once.',
                    value = FALSE, status = "info", fill = FALSE,
                    shape = "square", outline = TRUE
                ),
                shinyWidgets::prettyRadioButtons(inputId = "lineNumber_UniSite", 
                    label = 'Treatment Line',
                    shape = 'round', outline = TRUE, status = 'info',
                    inline = TRUE, choices = c(1, 2), 
                    selected = 1),
                shinyWidgets::prettyRadioButtons('endpoint_UniSite', 
                    label = 'Select endpoint', choices = 'placeholder',
                    selected = 'placeholder'),
            ),
        
        ),
        
        ## ---------- ##
        ## Main Panel ##
        ## ---------- ##
        mainPanel(tabsetPanel(id="analysis_main_panel",
                tabPanel("Site Specific Univariate Analysis",
                    tabsetPanel(id = 'coxRegPerSitePanels',
                        tabPanel('Figures', value = 'coxRegPlots',
                            plotOutput('forest', width = "100%")
                        ),
                        tabPanel('Tables', value = 'coxRegTables',
                            DT::dataTableOutput('univariateSite'),
                            tags$br()
                        )
                    )
                ),
                tabPanel("Covariate Adjustment"
                ),
                tabPanel("Propensity Score Analysis"
                )
            )
        )
    )
)
