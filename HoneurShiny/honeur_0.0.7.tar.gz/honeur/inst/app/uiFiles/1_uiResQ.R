# Project: honeur
#
# Author: hbossier
###############################################################################




# Overview on research questions and available sites to aggregate results.
tabPanel("Research Questions",
    
    tags$br(),
    
    fluidRow(
        column(3,
            wellPanel(
                # Choices are obtained from extdata folder
                selectizeInput("resQ", label = 'Select research question', 
                    choices = possResQ$Value,
                    multiple = FALSE),
                # Choices are getting updated in server as they depend on research question
                prettyCheckboxGroup(inputId = "avSites", 
                    label = 'Available sites to be included in the analysis:',
                    shape = 'round', outline = TRUE, status = 'info',
                    inline = TRUE, choices = c('EMMOS', 'CMG'), 
                    selected = c('EMMOS', 'CMG')),
                tags$hr(),
                tags$p("Statistics will be calculated on the sites selected here (it is possible to deselect sites)."),
                tags$p("Proceed to the next tab by clicking on 'Aggregate Sites'."),
                conditionalPanel(condition = 'input.avSites != ""',
                    shinysky::actionButton('mergeData', label = 'Aggregate Sites',
                        styleclass = "primary", block = TRUE))
            )
        ),
        column(9,
            uiOutput("markdownInfo")
        )
    )
)
