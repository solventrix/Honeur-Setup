# Project: honeur
#
# Author: hbossier
###############################################################################

tabPanel("Descriptive Statistics",
    
    # Slider customization
    chooseSliderSkin("Modern"),
    setSliderColor('LightSeaGreen', c(1,2)),
    
    ## ---------- ##
    ## Side Panel ##
    ## ---------- ##
    sidebarLayout(
        sidebarPanel(
            h4(HTML("Data Selection Tools")),
            tags$hr(),
            # Common UI elements (gets updated in server)
            fluidRow(
                htmlOutput("siteInputUI"),
                selectizeInput('ind_id', label = 'Select disease id', choices = NULL)
            ),
            
            # UI depending on continuous variables
            conditionalPanel(condition = "input.descriptive_main_panel == 'continuous'",
                fluidRow(
                    shinyWidgets::prettyRadioButtons('con_sct_fl', 
                        label = 'Patients eligible for transplantation?', 
                        choices = c('Yes' = 1, 'No' = 0), inline = TRUE, 
                        selected = 1, shape = 'round', outline = TRUE, status = 'info'),
                    # Update values in server
                    shinyWidgets::prettyRadioButtons(inputId = "con_lineNumber", 
                        label = 'Treatment Line',
                        shape = 'round', outline = TRUE, status = 'info',
                        inline = TRUE, choices = c(1, 2), 
                        selected = 1)
                #tags$b('NP: Entry =  SummaryTabCont')
                )
            ),
            
            # UI depending on categorical variables: database characteristics
            conditionalPanel(condition = "input.descriptive_main_panel == 'DB'",
                fluidRow(
                    selectizeInput('DB_plot', label = "Plot 'variable'", choices = NULL)
                #tags$b('NP: Entry =  LOTFreq')
                )
            ),
            
            # UI depending on categorical variables: patient characteristics
            conditionalPanel(condition = "input.descriptive_main_panel == 'patients'",
                fluidRow(
                    # The following values are updated in server
                    selectizeInput('pat_selVar', label = 'Select Concept', 
                        choices = NULL),
                    shinyWidgets::prettyRadioButtons('pat_sct_fl', 
                        label = 'Patients eligible for transplantation?', 
                        choices = c('Yes' = 1, 'No' = 0), inline = TRUE, 
                        selected = 1, shape = 'round', outline = TRUE, status = 'info'),
                    shinyWidgets::prettyRadioButtons(inputId = "pat_lineNumber", 
                        label = 'Treatment Line',
                        shape = 'round', outline = TRUE, status = 'info',
                        inline = TRUE, choices = c(1, 2), 
                        selected = 1)
                #tags$b('NP: Entry =  SummaryTab2')
                )
            ),
            
            # UI depending on treatment sequence
            conditionalPanel(condition = "input.descriptive_main_panel == 'trtmnt_seq'",
                conditionalPanel(condition = "input.tabsTrtmSeq == 'regTables'",
                    fluidRow(
                        # Available Regimen tables
                        prettyRadioButtons('selRegimenTable',
                            label = 'Display table:',
                            choices = c('Available Regimens', 'Regimens by Class',
                                'Treatment Class Sequence Count',
                                'Grouped Regimen Count','Treatment Regimen Sequence'),
                            selected = 'Available Regimens',
                            shape = 'round', outline = TRUE, status = 'info'),
                        tags$hr(),
                        # Common UI for all Regimen Tables
                        shinyWidgets::prettyRadioButtons('trtmntSeq_sct_fl', 
                            label = 'Patients eligible for transplantation?', 
                            choices = c('Yes' = 1, 'No' = 0), inline = TRUE, 
                            selected = 1, shape = 'round', outline = TRUE, status = 'info'),
                        ############################
                        ############################
                        # Only for Regimens by Class
                        conditionalPanel(condition = "input.selRegimenTable == 'Regimens by Class'",
                            
                            # Regimen class, updated in server
                            selectizeInput('trtmntSeq_selVar', label = 'Select Class', 
                                choices = NULL),
                            # Treatment Line: max line
                            conditionalPanel(condition = "input.regByClass_indTrtLine == false",
                                shinyWidgets::prettyRadioButtons(inputId = "trtSeq_lineN_Max", 
                                    label = 'Maximum Line of Treatment.',
                                    shape = 'round', outline = TRUE, status = 'info',
                                    inline = TRUE, choices = c('1' = 1, '2' = 2,
                                        '3' = 3, '4 and above' = +Inf), 
                                    selected = +Inf)
                            ),
                            # Or select individual treatment line
                            shinyWidgets::prettyCheckbox(inputId = 'regByClass_indTrtLine',
                                label = 'Rather select individual Treatment Line?',
                                value = FALSE, status = "info", fill = FALSE,
                                shape = "square", outline = TRUE
                            ),
                            # Individual treatment line
                            conditionalPanel(condition = "input.regByClass_indTrtLine == true",
                                # Treatment line, updated in server
                                shinyWidgets::prettyRadioButtons(inputId = "trtmntSeq_lineNumber", 
                                    label = 'Treatment Line',
                                    shape = 'round', outline = TRUE, status = 'info',
                                    inline = TRUE, choices = c(1, 2), 
                                    selected = 1),
                            )
                        ),
                        # Only for Treatment Class Sequence Count
                        conditionalPanel(condition = "input.selRegimenTable == 'Treatment Class Sequence Count'",
                            # Max Line of Treatment
                            shinyWidgets::prettyRadioButtons(inputId = "levelClassSeqCount", 
                                label = 'Maximum Line of Treatment.',
                                shape = 'round', outline = TRUE, status = 'info',
                                inline = TRUE, choices = c('1' = 1, '2' = 2,
                                    '3' = 3, '4 and above' = +Inf), 
                                selected = +Inf)
                        ),
                        # Only for Grouped Regimen Count
                        conditionalPanel(condition = "input.selRegimenTable == 'Grouped Regimen Count'",
                            # Max Line of Treatment
                            shinyWidgets::prettyRadioButtons(inputId = "levelGrRegCount", 
                                label = 'Maximum Line of Treatment.',
                                shape = 'round', outline = TRUE, status = 'info',
                                inline = TRUE, choices = c('1' = 1, '2' = 2,
                                    '3' = 3, '4 and above' = +Inf), 
                                selected = +Inf)
                        ),
                        # Only for Treatment Regimen Sequence
                        conditionalPanel(condition = "input.selRegimenTable == 'Treatment Regimen Sequence'",
                            # Max Line of Treatment
                            shinyWidgets::prettyRadioButtons(inputId = "levelSeqRegimen", 
                                label = 'Maximum Line of Treatment.',
                                shape = 'round', outline = TRUE, status = 'info',
                                inline = TRUE, choices = c('1' = 1, '2' = 2,
                                    '3' = 3, '4 and above' = +Inf), 
                                selected = +Inf)
                        )
                    ############################
                    ############################
                    )
                )
            ),
            
            # UI depending on survival
            conditionalPanel(condition = "input.descriptive_main_panel == 'survival'",
                fluidRow(
                    shinyWidgets::prettyRadioButtons('KM_showSites', 
                        label = 'Select data from individual site',
                        choices = "EMMOS",
                        selected = 1, shape = 'round', outline = TRUE, status = 'info'),
                    shinyWidgets::prettyRadioButtons('KM_sct_fl', 
                        label = 'Patients eligible for transplantation?', 
                        choices = c('Yes' = 1, 'No' = 0), inline = TRUE, 
                        selected = 1, shape = 'round', outline = TRUE, status = 'info'),
                    
                    # The following values are updated in server
                    selectizeInput('KM_selVar', label = 'Select stratification variable', 
                        choices = NULL),
                    
                    shinyWidgets::prettyRadioButtons('KM_endpoint', 
                        label = 'Select endpoint', choices = 'placeholder',
                        selected = 'placeholder'),
                    shinyWidgets::prettyRadioButtons(inputId = "KM_lineNumber", 
                        label = 'Treatment Line',
                        shape = 'round', outline = TRUE, status = 'info',
                        inline = TRUE, choices = c(1, 2), 
                        selected = 1)
                #tags$b('NP: Entry =  KMdataDF')
                )
            ),
            
            # Download figures and button table
            fluidRow(
                column(6, shinysky::actionButton('downFigure', label = 'Download Figure',
                        styleclass = "primary", block = FALSE)),
                column(6, shinysky::actionButton('downTable', label = 'Download Table',
                        styleclass = "primary", block = FALSE))
            )
        ),
        
        ## ---------- ##
        ## Main Panel ##
        ## ---------- ##
        mainPanel(
            tabsetPanel(id="descriptive_main_panel",
                tabPanel("Continuous Variables", value = 'continuous',
                    DT::dataTableOutput('tableCont')
                ),
                tabPanel("Database Characteristics", value = 'DB',
                    DT::dataTableOutput('tableDB'),
                    tags$br(),
                    column(6,
                        plotlyOutput('barPlotDB')
                    )
                ),
                tabPanel("Patient Characteristics", value = 'patients',
                    DT::dataTableOutput('tablePat'),
                    tags$br(),
                    column(6,
                        plotlyOutput('barplotPat')
                    )
                ),
                tabPanel("Treatment Regimens", value = 'trtmnt_seq',
                    tabsetPanel(id = 'tabsTrtmSeq',
                        tabPanel('Tables', value = 'regTables',
                            DT::dataTableOutput('tableRegSeq'),
                            tags$br()
                        ),
                        tabPanel('Figures', value = 'regPlots',
                            plotOutput('alluvial', height = 800, width = '100%')
                        )
                    )
                ),
                tabPanel("Survival", value = 'survival',
                    tabsetPanel(id = 'tabsSurvival',
                        tabPanel('Survival Plots', value = 'survPlots',
                            fluidRow(
                                column(6, plotOutput('KMPlotIndividual', height = 600, width = "100%")),
                                column(6, plotOutput('KMPlotAll', height = 600, width = "100%"))
                            )
                        ),
                        tabPanel('Tables', value = 'survTable',
                            HTML("<b> aggregated stats </b>"),
                            DT::dataTableOutput('tableSurvivalAll'),
                            tags$hr(),
                            tags$hr(),
                            htmlOutput("siteSurvival"),
                            DT::dataTableOutput('tableSurvivalIndividual')
                        )
                    )
                )
            )
        )
    )
)
