## (1) Load packages for the app

library(honeur)

library(shinyjs)            # for several UI features
library(shinysky)           # more UI features
library(shinyFeedback)      # direct feedback on user input
library(DT)                 # for nice UI tables
library(shinyWidgets)       # More UI
library(plotly)             # Plotly graphs
library(data.table)         # For fast reading in csv files


## (2) General settings for the app

options(stringsAsFactors = FALSE)
`%then%` <- shiny:::`%OR%`

# Colors
jsCode <- "shinyjs.pageCol = function(params){$('body').css('background', params);}"

# Temp dir
tmpDir <- tempdir(check = TRUE)

## (3) Debugging

onStop(function() {
      if (file.exists(".RDuetConsole"))
        file.remove(".RDuetConsole")
    })
doDebug <- TRUE
if (!exists("doDebug"))
  doDebug <- FALSE

  
## (4) Global sites information
# Possible research questions
possResQ <- data.table::fread("../extdata/overviewAvRQ.csv")

# Small function
plotHeight <- function(myData){
  if (length(myData) < 18) 
    return(400)
  if (length(myData) >= 18) 
    return(800) 
}