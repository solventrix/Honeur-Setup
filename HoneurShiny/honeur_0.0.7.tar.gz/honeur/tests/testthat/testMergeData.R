# TITLE
# 
# Author: hbossier
###############################################################################

context("test_merging_data")

# Info
startingSite <- 'EMMOS'
fPath <- "/home/hbossier/git/honeur_jnj/honeur/inst/extdata/01_dataSites/resQ1"
globalInfoFile <- read.csv(paste0(fPath,'/data_resQ1.csv'))

# Read in data
allData <- bindSites(fPath = fPath, globalInfoFile = globalInfoFile,
    startingSite = startingSite)

# Combine and extract results
entriesJSON <- names(allData)
sel <- entriesJSON[c(8, 1, 7, 9, 19)]
results <- getAggregatedStats(allData, descTabs(
        contN = "SummaryTabCont",
        dbN = "LOTFreq",
        patN = "SummaryPatient",
        avRegN = "SummaryTab", 
        regClassN = "SummaryReg", 
        classSeqCountN = "TrtmntSeqAll",
        regCountN = "ClassSeqAll",
        regSeqN = "RegSeqAll",
        kmN = "KMdataDF"))

# Check how to keep all information
allInfo <- bindIndAggSites(aggStats = results, allData = allData, 
    entries = descTabs(
        contN = "SummaryTabCont",
        dbN = "LOTFreq",
        patN = "SummaryPatient",
        avRegN = "SummaryTab", 
        regClassN = "SummaryReg", 
        classSeqCountN = "TrtmntSeqAll",
        regCountN = "ClassSeqAll",
        regSeqN = "RegSeqAll",
        trtByLineNN = 'TrtByLineNumbers',
        kmN = "KMdataDF"))
str(allInfo)

## SummaryTab
#avRegN = 'SummaryTab'
#regClassN = 'SummaryReg'
#classSeqCountN = 'TrtmntSeqAll'
#regCountN = 'ClassSeqAll'
#regSeqN = 'RegSeqAll'


# Regimens
head(allData[['SummaryTab']])

# Univariate results
head(allData[['HRAllDF']])

# Test









