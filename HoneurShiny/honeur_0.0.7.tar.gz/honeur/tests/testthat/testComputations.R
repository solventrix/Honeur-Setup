
context("test_computations")

# Info
startingSite <- 'EMMOS'
fPath <- "/home/hbossier/git/honeur_jnj/honeur/inst/extdata/01_dataSites/resQ1"
globalInfoFile <- read.csv(paste0(fPath,'/data_resQ1.csv'))

# Read in data
allData <- bindSites(fPath = fPath, globalInfoFile = globalInfoFile,
    startingSite = startingSite)

entriesJSON <- names(allData)
sel <- entriesJSON[c(8, 1, 22, 9, 19)]
results <- getAggregatedStats(allData, entries = descTabs(
        contN = "SummaryTabCont",
        dbN = "LOTFreq",
        patN = "SummaryPatient",
        avRegN = "SummaryTab", 
        regClassN = "SummaryReg", 
        classSeqCountN = "TrtmntSeqAll",
        regCountN = "ClassSeqAll",
        regSeqN = "RegSeqAll",
        trtByLineNN = 'TrtByLineNumbers',
        kmN = "KMdataDF"))
results[['KMSum']] <- readRDS("/home/hbossier/git/honeur_jnj/honeur/inst/extdata/03_dataIntermediate/resQ1/survivalEMMOS_CMG.rds")


# Check results
head(results)

plotKMCurve(survData = results[['KMSum']],
    variable = 'GENDER',
    end_point = 'FR', 
    line_number = 1,
    sct_fl = 1,
    site = 'CMG')

# Check continuous summary
results[['contSum']] %>% 
    filter(LINE_NUMBER == 1)

# Create table with information
survDataEx <- results[['KMSum']][['GENDER']] %>% 
    filter(typeSite == 'aggregated',
        endpoint == 'FR',
        LINE_NUMBER == 1,
        SCT_FL == 1)
head(survDataEx)
getSurvInfo(filtSurvData = survDataEx,
    strataVar = 'strata')


## Implement maximum line of treatment
results[['trtSeqCSum']] %>%
    filter(SCT_FL == 1,
        IND_ID == 437233) 


########### Plot alluvial curve
groupingVar <- names(allData[['TrtByLineNumbers']])[1:9]
alluVData <- combTrtByLineC(allData[['TrtByLineNumbers']] %>%
        filter(site == 'EMMOS'), groupingVar)

## Write to file: 
#plotAlluvial(alluVData, 'file', '~/Desktop/')

# Test using plotly sunburst
library(plotly)

fig <- plot_ly(
    labels = c("Eve", "Cain", "Seth", "Enos", "Noam", "Abel", "Awan", "Enoch", "Azura"),
    parents = c("", "Eve", "Eve", "Seth", "Seth", "Eve", "Eve", "Awan", "Eve"),
    values = c(10, 14, 12, 10, 2, 6, 6, 4, 4),
    type = 'sunburst'
)

#fig
head(allData[['TrtByLineNumbers']])
labels <- unique(c(na.omit(unlist(allData[['TrtByLineNumbers']][,1:9]))))


# Plot forrest plot 
HRAllDF <- allData[['HRAllDF']]  %>%  
    mutate(label = as.factor((gsub("performance status ","",(label)))))

line <- 1
site <- 'CMG'
stratfactors = 'TRTMNT'
endpoint <- 'OS'
#honeurForest(data = HRAllDF, 1,'CMG','TRTMNT', 'OS')


head(allData[['HRAllDF']])


## Depth
allInfo[['ClassSeqAll']]

descTabs(regCountN = 'ClassSeqAll')
str(allInfo)
head(allInfo[['regCSum']])

allInfo[['regCSum']]$classSequence

vData <- allInfo[['regCSum']]$classSequence


test <- c('A goes to --> B then --> C')
test <- c('A goes to B')
gregexpr('-->', test)[[1]][1]
?grep
attr(gregexpr('-->', test)[[1]], 'match.length')

tail( sapply(vData, function(x){
        value <- c(gregexpr('-->', x)[[1]])
        sum(value >= 1)
      }))

tail(vData)
countArrows(vData)


allInfo[['regCSum']] %>%
    mutate(arrows = countArrows(classSequence),
        maxNumTrt = arrows + 1) %>% tail()


# Survival curve with extra options
# First we need the table
results[['KMSum']][[1]] %>%
    filter(nar == 1) %>% 
    filter(LINE_NUMBER == 1, IND_ID == 437233,
        variable == 'AGE65', endpoint == 'OS',
        SCT_FL == 0) %>%
    filter(typeSite == 'EMMOS')
    pull(typeSite)


p <- ggplot(survsummary, mapping) +
    scale_shape_manual(values = 1:length(levels(survsummary$strata)))+
    ggpubr::geom_exec(geom_text, data = survsummary, size = fontsize, color = color, family = font.family) +
    ggtheme +
    scale_y_discrete(breaks = as.character(levels(survsummary$strata)),labels = yticklabs ) +
    coord_cartesian(xlim = xlim) +
    labs(title = title, x = xlab, y = ylab, color = legend.title, shape = legend.title)


riskData <- results[['KMSum']][[1]] %>%
    filter(nar == 1) %>% 
    filter(LINE_NUMBER == 1, IND_ID == 437233,
        variable == 'AGE65', endpoint == 'OS',
        SCT_FL == 0) %>%
    filter(typeSite == 'EMMOS') %>%
    select(time, n.risk, strata)

pltKM <- plotKMCurve(results[['KMSum']], variable = 'var_ISS_ID', 'OS', 1, 0, site = 'EMMOS')
  
{
  {

    ## Create a blank plot for place-holding
    blank.pic <- ggplot(results[['KMSum']][[1]], aes(time, surv)) +
        geom_blank() + theme(axis.line=element_blank(),
            axis.text.x=element_blank(),
            axis.text.y=element_blank(),
            axis.ticks=element_blank(),
            axis.title.x=element_blank(),
            axis.title.y=element_blank(),
            legend.position="none",
            panel.background=element_blank(),
            panel.border=element_blank(),
            panel.grid.major=element_blank(),
            panel.grid.minor=element_blank(),
            plot.background=element_blank())
    
###################################################
# Create table graphic to include at-risk numbers #
###################################################
.df=KMdataplot%>%filter(nar==1)

gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}

Factor <- factor(risk.data$strata)
m <- max(nchar(levels(risk.data$strata)))
narSize=3
x_txtsize=10
legend_txtsize=9
endpoint <- 'OS'
endpointplot <- as.vector(unlist(strsplit(endpoint, split = " ")))
if (length(endpointplot) > 1){
  narSize=2.5
  x_txtsize=8
  legend_txtsize=7
}

if(table){
  risk.data <- data.frame(
      strata = Factor,
      time = .df$time,
      n.risk = .df$n.risk)
  
  risk.data <- riskData
  risk.data$strata <- factor(risk.data$strata, levels = rev(levels(factor(risk.data$strata)))) 
  
  data.table <- ggplot(risk.data, aes(x = time, y = strata, 
              label = format(n.risk, nsmall = 0))) +
      geom_text(size = narSize) + theme_bw() +
      scale_y_discrete(breaks = as.character(levels(risk.data$strata)), 
          labels = rev(levels(risk.data$strata))) +
      scale_x_continuous("Numbers at risk") +
      theme(axis.title.x = element_text(size = x_txtsize, vjust = 1),
          panel.grid.minor = element_blank(),panel.grid.major = element_blank(),
          panel.border = element_blank(), axis.ticks = element_blank(),
          axis.text.y = element_text(face = "bold",hjust = 1))
  #panel.grid.major = element_blank(),
  #axis.ticks = element_blank(),axis.text.x = element_blank(),
  data.table <- data.table +
      theme(legend.position = "none", axis.text.y = element_text(size=legend_txtsize, color=rev(gg_color_hue(length(levels(risk.data$strata)))))) + xlab(NULL) + ylab(NULL)
  
  # ADJUST POSITION OF TABLE FOR AT RISK
  data.table <- data.table +
      theme(plot.margin = unit(c(-1.5, 1, 0.1, ifelse(m < 10, 2.5, 3.5) - 0.22 * m), "lines"))
  
  #######################
  # Plotting the graphs #
  #######################
  
  p = gridExtra::arrangeGrob(pltKM, blank.pic, data.table, clip = FALSE, nrow = 3,
      ncol = 1, heights = unit(c(2, 0.1, 0.3),c("null", "null", "null"))) 
  
  plotlist<-list()
  plotlist[[1]] = p 
} else {
  plotlist[[i]] = p 
}

}
if (length(endpointplot)>2){
  do.call(grid.arrange,c(plotlist,list(ncol=2)))
} else { do.call(gridExtra::grid.arrange,plotlist)}

}

