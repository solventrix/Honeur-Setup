# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' computes gradient, hessian, and log-likelihood within each site
#' @param modelFormula model formula
#' @param isFactor a vector of ones and zeros with the same length as the number of covariates in the model. 
#' 1 would show its corresponding covariate is a factor, and 0 would show otherwise. 
#' @param beta estimated parameter vector 
#' @param centerX part of design matrix corresponds to the site effect
#' @param centerVar a variable indicating various centers
#' @param sampleSize size of the site
#' @param dataPath path to the location of the data.
#' @param factorLevels a list with its component determining the levels of factor columns
#' @param siteNum ID of the current site
#' @return path to json file with contribution of the site to gradient, hessian, and log-lilihood
#' 
#' @importFrom numDeriv hessian
#' @author Vahid Nassiri
#' @export
computeGradientHessianLikelihoodLogReg <- function(dataPath, modelFormula, isFactor, beta, centerX, centerVar,
		sampleSize, factorLevels, siteNum){
	modelFormula <- as.formula(modelFormula)
	## reading data, this probably needs to be replaced with something else
	inputData <- readData(dataPath, modelFormula, isFactor)
	siteSize <- nrow(inputData)
	## obtain the response column
	varsInModel <- all.vars(modelFormula)
	yName <- varsInModel[1]
	respCol <- which(names(inputData) == yName)
	y <- inputData[,respCol]
	iniX <- model.frame(modelFormula, data = as.data.frame(inputData), xlev = factorLevels)
	## Now making data matrix X
	centerVar <- unlist(centerVar)
	if (is.null(centerX)){
		X <- as.matrix(data.frame(model.matrix(modelFormula, data = iniX)))
	}else{
		X <- as.matrix(data.frame(model.matrix(modelFormula, data = iniX), centerX[centerVar == siteNum,]))
	}
	#colnames(X)[ncol(X)] <- "siteEffect"
	## comput gradient
	gradEst <- (t(X)%*%(sigmoid(X%*%beta) - y)) / sampleSize
	hessianEst <- numDeriv::hessian(computeCostFunctionLogistic, beta, 
			method = "complex", X = X, y = y, sampleSize = sampleSize)
	lossEst <- computeCostFunctionLogistic(beta, X, y, sampleSize)
	toReturn <- list(gradEst = gradEst, 
			hessianEst = hessianEst, lossEst = lossEst)
		return(toReturn)
}


