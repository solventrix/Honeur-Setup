# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################



#' Combined results obtained by \link{collector} 
#' @param replyMessages string showing the status of the matched cases and controls
#' @return the same string is returend.
#' @export
collectMatchedSubjectsStatus <- function(replyMessages){
	
	resCombined <- lapply(replyMessages, function(x) {
				x
			})
	
	as.data.frame(do.call('rbind', resCombined))
}



