# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################

#' collects gradient, hessian, and loglikelihood of the Cox 
#' proportional hazard model from different sites.
#' @param dataPath list with path to location of data in different sites
#' @param beta estimated parameter vector
#' @param siteNum ID of the corresponding site
#' @return hessian, gradient, and log-likelihood
#' 
#' @importFrom survival coxph
#' @import distcomp 
#' @author Vahid Nassiri
#' @export


computeGradientHessianLikelihoodCoxph <- function(dataPath, beta, siteNum){
	load(file = paste(dirname(dataPath), "/materialsCoxPh", siteNum,".RData", sep =""))
	oneIterCoxph <- distcomp:::dccoxph.fit(x = materialsCoxph$X, y = materialsCoxph$Y, strata = materialsCoxph$strats, 
			offset = materialsCoxph$offset, init = beta, control = materialsCoxph$control,
			weights = materialsCoxph$weights, method = materialsCoxph$method, rownames = materialsCoxph$method)
	rm(materialsCoxph)
	hessianCoxph <- -solve(oneIterCoxph$var)
	gradientCoxph <- oneIterCoxph$gradient
	logLikCoxph <- oneIterCoxph$loglik
	toReturn <- list(gradientCoxph = gradientCoxph, hessianCoxph = hessianCoxph, logLikCoxph = logLikCoxph)
	return(toReturn)
}

