# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' Function that make a bar plot (or histrogram) for a given variable in a distributed way.
#' @param config a list with these components: "studyId", "centerIds", "messageBrokerAddress", 
#' "dataPath", here is an example:
#' dataPath <- c(system.file('extdata', 'dataLogReg1.csv', package = 'distributedUtils'),
#' 		system.file('extdata', 'dataLogReg2.csv', package = 'distributedUtils'))
#' config <- list(
#' 		studyId = "study1",
#' 		centerIds = paste0('center', 1:2),
#' 		messageBrokerAddress = messageBrokerAddress,
#' 		dataPath = dataPath
#' )
#' @param variableName  string indicating the variable for which the average will be calculated
#' @param groupingVariable string indicating variable that  defines groups. It could be a binary variable, for example
#' for comparing treated/non-treated in case of propensity score matching.
#' @param onlyMatchedSubjects if TRUE, will only use the matched subjects
#' @return a ggplot object and a list with frequency tables.
#' 
#' @import ggplot2
#' @author Vahid Nassiri
#' @export
distributedBarPlot <- function(config, variableName, groupingVariable = NULL, onlyMatchedSubjects = FALSE){
	session <- initDistributedSession(config = config)  
	on.exit(closeDistributedSession(session))
	previousCollector <- NULL
	## Subsetting data
	if (onlyMatchedSubjects){
		RFunction 			<- "computeDataSubsetting"
		collectFunction <- "collectDataSubsetting"
		
		# Call collectors
		dataSubsettingCollector <- collector(session = session, RFunction = RFunction, 
				collectFunction = collectFunction, previousCollector = previousCollector, 
				MoreArgs = NULL, sendSiteID = TRUE)
		config$dataPath <- unlist(dataSubsettingCollector$res)
		closeDistributedSession(session)
		session <- initDistributedSession(config = config)  
	}
	
	## if isFactor is false, then we should ask each hospital to give a 
	## frequency table of a discritized version, just this discritized
	## things should be the same in various hospitals, so we need perhaps
	## the min and max per hospital to find overal min and max and then divide the 
	## in between into say 10 pieces.

		## ask for a frequency table per center
		RFunction 			<- "computeFrequencyTable"
		collectFunction <- "collectFrequencyTable"
		
		# Call collectors
		frqTabCollector <- collector(session = session, RFunction = RFunction, 
				collectFunction = collectFunction, previousCollector = previousCollector, 
				MoreArgs = list(variableName = variableName, groupingVariable = groupingVariable))
		#previousCollector <- frqTabCollector 
		if (is.null(groupingVariable)){
			## Finding all variable levels across different centers
			uniqLevels <- unique(unlist(lapply(lapply(frqTabCollector$res,"[[",2), unlist)))
			#uniqFreq <- matrix(NA, length(),length(uniqLevels))
			#count <- 0
			## Nowe we go over each columns and add numbers with the same name
			## Going over sites and find each frequency tab
			numSites <- length(frqTabCollector$res)
			allFreqTabs <- matrix(NA, numSites, length(uniqLevels))
			for (iSite in 1:numSites){
				allFreqTabs[iSite,] <- unlist(frqTabCollector$res[[iSite]]$freqTab)
				}
			allTabs <- apply(allFreqTabs, 2, sum)
			names(allTabs) <- uniqLevels
#			for (iVal in length(uniqLevels)){
#				#count <- count + 1
##				eachSum <- function(x, iVal) {
##					x <- x[[1]]
##					x[[which(names(x) == iVal)]]
##				}
#
#				#uniqFreq[count] <- sum(unlist(lapply(frqTabCollector$res, eachSum, iVal)))
#			}
#			names(uniqFreq) <- uniqLevels
#			allTabs <- uniqFreq
			data2plot <- data.frame(value = factor(uniqLevels, levels = uniqLevels),
					Frequency = as.numeric(as.character(allTabs)))
			## check for possible NA's
			if (sum(complete.cases(data2plot)) != nrow(data2plot) |
							sum(unlist(lapply(data2plot, is.finite))) != ncol(data2plot)*nrow(data2plot)){
						warning("There are some inifnite or missing values in the frequency table, so no plot is generated.")
						plot2return <- NULL
			}else{
						plot2return <- ggplot(data2plot, aes(x = value, y = Frequency)) +
								geom_bar(stat = "identity", color = "black", fill = "grey") +
								ggtitle(variableName) + xlab("Variable values")
			}

			#barplot(allTabs)
		}else{
			numSites <- length(frqTabCollector$res)
			uniqLevels <- unique(unlist(lapply(lapply(frqTabCollector$res,"[[",2), unlist)))
			uniqGroups <- unique(unlist(lapply(lapply(frqTabCollector$res,"[[",3), unlist)))
			allFreqTabs <- list()
			for (iSite in 1:numSites){
				allFreqTabs[[iSite]] <- lapply(frqTabCollector$res[[iSite]]$freqTab, unlist)
				names(allFreqTabs[[iSite]]) <- uniqGroups
			}
			## Now we go over different values of the grouping variable
			allTabs <- list()
			for (iGroup in 1:length(uniqGroups)){
				allTabs[[iGroup]] <- Reduce("+", lapply(allFreqTabs,"[[", iGroup))
				names(allTabs[[iGroup] ])<- uniqLevels
				}
			names(allTabs) <- uniqGroups

#			allTabs <- list()
#			uniqLev1 <- unique(unlist(lapply(frqTabCollector$res, names)))
#			count1 <- 0
#			for (iLev1 in uniqLev1){
#				count1 <- count1 + 1
#				tmpTab <- list()
#				for (iCenter in 1:length(config$dataPath)){
#					tmpTab[[iCenter]] <- frqTabCollector$res[[iCenter]][which(names(frqTabCollector$res[[iCenter]]) == iLev1)][[1]][[1]]
#				}
#				## Now make a table for this level just like no grouping variable case
#				uniqLevels <- unique(unlist(lapply(tmpTab, names)))
#				uniqFreq <- rep(NA, length(uniqLevels))
#				count <- 0
#				## Nowe we go over each columns and add numbers with the same name
#				for (iVal in uniqLevels){
#					count <- count + 1
#					eachSum <- function(x, iVal) x[[which(names(x) == iVal)]]
#					uniqFreq[count] <- sum(unlist(lapply(tmpTab, eachSum, iVal)))
#				}
#				names(uniqFreq) <- uniqLevels
#				allTabs[[count1]] <- uniqFreq
#			}
#			names(allTabs) <- uniqLev1
#			par(mfrow= c(ceiling(length(allTabs)/2),2))
#			for (iPlot in 1:length(allTabs)){
#				barplot(allTabs[[iPlot]], main = names(allTabs)[iPlot])
#			}
			#data2plot <- reshape2::melt(do.call("cbind", allTabs))
			data2plot <- data.frame(value  = rep(uniqLevels, length(uniqGroups)),
					Group = c(t(matrix(rep(uniqGroups, length(uniqLevels)),length(uniqGroups), length(uniqLevels)))),
					Frequency = c(do.call("cbind", allTabs)))
			names(data2plot) <- c("value", "Group", "Frequency")
			data2plot$value <- factor(data2plot$value, levels = uniqLevels)
			data2plot$Group <- factor(data2plot$Group, levels = uniqGroups)
			data2plot$Frequency <- as.numeric(as.character(data2plot$Frequency))
			if (sum(complete.cases(data2plot)) != nrow(data2plot) |
					sum(unlist(lapply(data2plot, is.finite))) != ncol(data2plot)*nrow(data2plot)){
				warning("There are some inifnite or missing values in the frequency table, so no plot is generated.")
				plot2return <- NULL
			}else{
				plot2return <- ggplot(data2plot, aes(x = value, y = Frequency)) +
						geom_bar(stat = "identity", color = "black", fill = "grey") +
						ggtitle(variableName) + xlab("Variable values") + facet_wrap(~Group)
			}
		}
		return(list(frequencyTables = allTabs, plot = plot2return))
}
