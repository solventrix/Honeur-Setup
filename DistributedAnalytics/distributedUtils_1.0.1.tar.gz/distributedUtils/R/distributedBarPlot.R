# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' Function that make a bar plot (or histrogram) for a given variable in a distributed way.
#' @param config a list with these components: "studyId", "centerIds", "messageBrokerAddress", 
#' "dataPath", here is an example:
#' dataPath <- c(system.file('extdata', 'dataLogReg1.csv', package = 'distributedUtils'),
#' 		system.file('extdata', 'dataLogReg2.csv', package = 'distributedUtils'))
#' config <- list(
#' 		studyId = "study1",
#' 		centerIds = paste0('center', 1:2),
#' 		messageBrokerAddress = messageBrokerAddress,
#' 		dataPath = dataPath
#' )
#' @param variableName  string indicating the variable for which the average will be calculated
#' @param groupingVariable string indicating variable that  defines groups. It could be a binary variable, for example
#' for comparing treated/non-treated in case of propensity score matching.
#' @param onlyMatchedSubjects if TRUE, will only use the matched subjects
#' @return a ggplot object.
#' 
#' @author Vahid Nassiri
#' @export
distributedBarPlot <- function(config, variableName, groupingVariable = NULL, onlyMatchedSubjects = FALSE){
	session <- initDistributedSession(config = config)  
	on.exit(closeDistributedSession(session))
	previousCollector <- NULL
	## Subsetting data
	if (onlyMatchedSubjects){
		RFunction 			<- "computeDataSubsetting"
		collectFunction <- "collectDataSubsetting"
		
		# Call collectors
		dataSubsettingCollector <- collector(session = session, RFunction = RFunction, 
				collectFunction = collectFunction, previousCollector = previousCollector, 
				MoreArgs = NULL, sendSiteID = TRUE)
		config$dataPath <- unlist(dataSubsettingCollector$res)
		closeDistributedSession(session)
		session <- initDistributedSession(config = config)  
	}
	
	## if isFactor is false, then we should ask each hospital to give a 
	## frequency table of a discritized version, just this discritized
	## things should be the same in various hospitals, so we need perhaps
	## the min and max per hospital to find overal min and max and then divide the 
	## in between into say 10 pieces.

		## ask for a frequency table per center
		RFunction 			<- "computeFrequencyTable"
		collectFunction <- "collectFrequencyTable"
		
		# Call collectors
		frqTabCollector <- collector(session = session, RFunction = RFunction, 
				collectFunction = collectFunction, previousCollector = previousCollector, 
				MoreArgs = list(variableName = variableName, groupingVariable = groupingVariable))
		#previousCollector <- frqTabCollector 
		if (is.null(groupingVariable)){
			## Finding all variable levels across different centers
			uniqLevels <- unique(unlist(lapply(frqTabCollector$res, names)))
			uniqFreq <- rep(NA, length(uniqLevels))
			count <- 0
			## Nowe we go over each columns and add numbers with the same name
			for (iVal in uniqLevels){
				count <- count + 1
				eachSum <- function(x, iVal) x[[which(names(x) == iVal)]]
				uniqFreq[count] <- sum(unlist(lapply(frqTabCollector$res, eachSum, iVal)))
			}
			names(uniqFreq) <- uniqLevels
			allTabs <- uniqFreq
			barplot(allTabs)
		}else{
			allTabs <- list()
			uniqLev1 <- unique(unlist(lapply(frqTabCollector$res, names)))
			count1 <- 0
			for (iLev1 in uniqLev1){
				count1 <- count1 + 1
				tmpTab <- list()
				for (iCenter in 1:length(config$dataPath)){
					tmpTab[[iCenter]] <- frqTabCollector$res[[iCenter]][which(names(frqTabCollector$res[[iCenter]]) == iLev1)][[1]]
				}
				## Now make a table for this level just like no grouping variable case
				uniqLevels <- unique(unlist(lapply(tmpTab, names)))
				uniqFreq <- rep(NA, length(uniqLevels))
				count <- 0
				## Nowe we go over each columns and add numbers with the same name
				for (iVal in uniqLevels){
					count <- count + 1
					eachSum <- function(x, iVal) x[[which(names(x) == iVal)]]
					uniqFreq[count] <- sum(unlist(lapply(tmpTab, eachSum, iVal)))
				}
				names(uniqFreq) <- uniqLevels
				allTabs[[count1]] <- uniqFreq
			}
			names(allTabs) <- uniqLev1
			par(mfrow= c(ceiling(length(allTabs)/2),2))
			for (iPlot in 1:length(allTabs)){
				barplot(allTabs[[iPlot]], main = names(allTabs)[iPlot])
			}
		}
		return(allTabs)
	
}
