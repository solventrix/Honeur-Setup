# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################



#' recieved the matched subjects for one site and write them locally for later use.
#' @param matchedList a list with indexes of matched cases and control for the corresponding site
#' @param respName name of response which is the grouping variable indicating cases and controls
#' @param dataPath a list with the same length as the number of sites, each
#' element of the list is the address of the data on the hard disk in the corresponding site.
#' @param siteNum ID of the corresponding site
#' @return nothing! it just writes stuff locally to each site.
#' 
#' @author Vahid Nassiri
#' @export
computeWriteMatchedSubjects <- function(matchedList, respName, dataPath, siteNum){
	matchedCases <- matchedList$case
	matchedControls <- matchedList$control
	write.csv(matchedCases, file = paste(dirname(dataPath), "/matchedCases", siteNum, ".csv", sep =""),
			row.names = FALSE)
	write.csv(matchedControls, file = paste(dirname(dataPath), "/matchedControls", siteNum, ".csv", sep =""),
			row.names = FALSE)
	write.csv(respName, file = paste(dirname(dataPath), "/respName.csv", sep =""),
			row.names = FALSE)
	return(paste("Matched cases and controls are stored on disk in site", siteNum))
#	write_json(PStoExport, path= paste(dirname(dataPath), "/propensityScores",siteNum, ".json", sep =""),
#			digits = NA)
}


