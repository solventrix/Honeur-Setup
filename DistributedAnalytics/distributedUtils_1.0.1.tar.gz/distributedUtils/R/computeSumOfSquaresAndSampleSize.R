#' Function that computes sum of squares of centered observations 
#' and sample size of a given variable
#' @param dataPath path to data file
#' @param variableName string indicating the variable of interest
#' @param overalMean the overal mean
#' @return list containing the sum of squares of centered observations 
#' and the sample size
#' @importFrom utils read.table 
#' @export
computeSumOfSquaresAndSampleSize <- function(dataPath, variableName, overalMean){
  
  data <- read.csv(dataPath, header = TRUE)
  
  sumOfSquares        <- sum((data[, variableName] - overalMean)^2, na.rm = TRUE)
  sampleSize <- sum(!is.na(data[, variableName]))
 
  list(sumOfSquares = sumOfSquares, sampleSize = sampleSize)
  
}
