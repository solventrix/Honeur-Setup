# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' function to fit a logistic regression
#' @param config a list with these components: "studyId", "centerIds", "messageBrokerAddress", 
#' "dataPath", here is an example:
#' dataPath <- c(system.file('extdata', 'dataLogReg1.csv', package = 'distributedUtils'),
#' 		system.file('extdata', 'dataLogReg2.csv', package = 'distributedUtils'))
#' config <- list(
#' 		studyId = "study1",
#' 		centerIds = paste0('center', 1:2),
#' 		messageBrokerAddress = messageBrokerAddress,
#' 		dataPath = dataPath
#' )
#' @param modelFormula model formula.
#' @param isFactor a vector of ones and zeros with the same length as the number of covariates in the model. 
#' 1 would show its corresponding covariate is a factor, and 0 would show otherwise. 
#' @param epsilon convergence tolorence (positive and small). Note that the same epsilon
#' will be used to see if the predicted probabilities are close to 0 or 1 (quai-complete separation). Also
#' whenever there is a need to take care of the rounding error, the same epsilon is used as the tolerance.
#' @param maxit maximum number of iterations of the Newton-Raphson algorithm
#' element of the list is the address of the data on the hard disk in the corresponding site.
#' @param includeSiteEffect logical variable with default TRUE, indicating whether site effect should be 
#' included in the model or not.
#' @return a list withestimated parameter vector, its covariance matrix,
#' and the reason of stopping Newton-Raphson algorithm. 
#' @importFrom stats as.formula
#' @importFrom stats model.matrix
#' @importFrom MASS ginv 
#' @author Vahid Nassiri
#' @export
distributedLogisticRegression <- function(config, modelFormula, isFactor, epsilon = 1e-8, maxit = 25, 
		includeSiteEffect = TRUE){
	session <- initDistributedSession(config = config)  
	on.exit(closeDistributedSession(session))
	previousCollector <- NULL
	## Note to consider: if problems like perfect separation occurs,
	## we might still find a solution, but with very large variances.
	## in fact the variance is diverging, apparently, from working of 
	## of Lesaffre and Albert (1989) we know that if the vector of 
	## standard deviations of the estimated parameters diverge, that's
	## an indicator of perfect separation, and in a few examples I've tried,
	## that is indeed the case.
	## The thing happens in this situation is: we have a quite flat likelihood,
	## so we would keep on iterating and the value of likleihood does not change a lot,
	## so the estimate could be anything (as it is flat), so the variance is practically
	## infinity. 
	
	numSites <- length(session$dataPath)
	
	## checks
	if (numSites < 1 | floor(numSites)!= numSites){
		stop("numSites should be and integer larger than or equal to 1.")
	}
	if (numSites == 1 & includeSiteEffect){
		stop("There is only one site in the study, you may set includeSiteEffect = FALSE.")
	}
	if (length(isFactor) != (length(all.vars(as.formula(modelFormula)))-1)){
		stop("length of isFactor should be equal to the number of covariates.")
	}
	## First of all, we need to things, 
	## 1- sample size: it is needed to compute the derivative and Hessian,
	## 2- number of parameters: this cannot be computed before knowing the number of levels of the Factor covariates.
	
	RFunction 			<- "computeSiteSizeNumPar"
	collectFunction <- "collectSiteSizeNumPar"
	
	# Call collectors
	siteSizesNumVarCollector <- collector(session = session, RFunction = RFunction, 
			collectFunction = collectFunction, previousCollector = previousCollector, 
			MoreArgs = list(modelFormula = modelFormula, 
					isFactor = isFactor))
	
	# Extract result
	siteSizesNumVar <- siteSizesNumVarCollector$res
	
	# construct suitable output
	siteSize <- unlist(siteSizesNumVar$siteSize)
	numPar <- rep(NA, numSites)
	if (any(unlist(lapply(numPar, is.character)))){
		stop(paste("In site(s) ", which(unlist(lapply(numPar, is.character))), " some variables in the model formula are missing: ", numPar))
	}
	
	
	namesVars <- NULL
	factorLevels <- list()
	levFactorAll <- list()
	# checking if all covariates are exisiting in every site
	for (iSite in 1:numSites){
		numPar[iSite] <- siteSizesNumVar$numPar[[iSite]]
		if (is.character(numPar[iSite])){
			stop(paste("In site number ", iSite, " some variables in the model formula are missing: ", numPar[iSite]))
		}
		factorLevels[[iSite]] <- siteSizesNumVar$factorLevels[[iSite]]
	}
	includeIntercept <- attr(terms(as.formula(modelFormula)),"intercept")
	## Let me check the factor levels already, 
	factorVars <- all.vars(as.formula(modelFormula))[which(isFactor == 1) + 1]
	nFactorLevels <- rep(NA, length(factorVars))
	for (iFactor in seq_along(factorVars)){
		resFactors <- 0
		for (iSite in 1:numSites){
			resFactors <- c(resFactors,
					factorLevels[[iSite]][[which(names(factorLevels[[iSite]]) == factorVars[iFactor])]])
		}
		levFactorAll[[iFactor]] <- unique(resFactors[-1])
		nFactorLevels[iFactor] <- length(levFactorAll[[iFactor]])
		names(levFactorAll)[[iFactor]] <- factorVars[iFactor]
	}
	numPar <- includeIntercept + sum(nFactorLevels-1) + sum(1-isFactor)
	factorLevels <- list()
	for (iFactor in seq_along(levFactorAll)){
		factorLevels[[iFactor]] <- unlist(levFactorAll[[iFactor]])
	}
	names(factorLevels) <- names(levFactorAll)
	
	
	## creating covariate names
	covariateNames0 <- all.vars(as.formula(modelFormula))[-1]
	## This is to know which covariate are factor, so based on their levels 
	## we create correct names (always first one the reference).
	if (isFactor[1] ==1){
		indFactor <- 1
	}else{
		indFactor <- 0
	}
	invisible(ifelse(isFactor[1] == 1, covariateNames <- paste(covariateNames0[1], factorLevels[[1]][-1], sep = ""), 
			covariateNames <- covariateNames0[1]))
	if (length(covariateNames0) > 1){
		for (iVar in 2:length(covariateNames0)){
			if (isFactor[iVar] ==1){
				indFactor <- indFactor + 1
			}
			invisible(ifelse(isFactor[iVar] == 1, covariateNames <- c(covariateNames, 
							paste(covariateNames0[iVar], factorLevels[[indFactor]][-1], sep = "")), 
					covariateNames <- c(covariateNames, covariateNames0[iVar])))
		}
	}
	## Adding intercept to the names if it is included
	if (includeIntercept == 1){
		covariateNames <- c("Intercept", covariateNames)
	}
	## changing names of factor variables
	#siteSizesNumVar <- collectingSampleSizeNumParLogistic (modelFormula, isFactor, numSites, dataPath)
	sampleSize <- sum(siteSize)
	## Making the part of design matrix related to site effect
	if (includeSiteEffect){
		centerVar <- as.data.frame(as.factor(rep(1:numSites, siteSizesNumVar$siteSize)))
		colnames(centerVar) <- "center"
		centerX <- as.matrix(model.matrix(object = as.formula("~center"), data = centerVar)[, -1])
		numPar <- numPar + numSites - 1
		covariateNames <- c(covariateNames, paste("siteEffect", 2:numSites, sep = ""))
	}else{
		centerX <- NULL
		centerVar <- NULL
	}
	## Initial value
	beta <- rep(0, numPar)
	## collecting materials
	RFunction 			<- "computeGradientHessianLikelihoodLogReg"
	collectFunction <- "collectMaterialsLogReg"
	
	# Call collectors
	materialsCollector <- collector(session = session, RFunction = RFunction, 
			collectFunction = collectFunction, previousCollector = siteSizesNumVarCollector, 
			MoreArgs = list(modelFormula = modelFormula, 
					isFactor = isFactor, 
					beta = beta, 
					centerX = centerX, 
					centerVar = centerVar,
					sampleSize = sampleSize, 
					factorLevels = factorLevels),
			sendSiteID = TRUE)

	############## WE ARE HERE###################
	## Making suitable output
	logRegGrad <- list()
	logRegHessian <- list()
	logRegLoss <- list()
	for (iSite in 1:numSites){
		logRegGrad[[iSite]] <- unlist(materialsCollector$res$gradEst[[iSite]])
		logRegLoss[[iSite]] <- unlist(materialsCollector$res$lossEst[[iSite]])
		logRegHessian[[iSite]] <- matrix(unlist(materialsCollector$res$hessianEst[[iSite]]), numPar,numPar)
	}
	gradEst <- Reduce("+",logRegGrad)
	hessianEst <- Reduce("+",logRegHessian)
	lossEst <- oldLoss <- Reduce("+",logRegLoss)
	beta <- oldBeta <-  beta - MASS::ginv(hessianEst)%*%gradEst
	#diffBeta <- t(beta)
	iter <- 0
	repeat {
		iter <- iter + 1
		materialsCollector <- collector(session = session, RFunction = RFunction, 
				collectFunction = collectFunction, previousCollector = materialsCollector, 
				MoreArgs = list(modelFormula = modelFormula, 
						isFactor = isFactor, 
						beta = beta, 
						centerX = centerX, 
						centerVar = centerVar,
						sampleSize = sampleSize, 
						factorLevels = factorLevels), sendSiteID = TRUE)
		## Gradient, Hessian and Loss
		logRegGrad <- list()
		logRegHessian <- list()
		logRegLoss <- list()
		for (iSite in 1:numSites){
			logRegGrad[[iSite]] <- unlist(materialsCollector$res$gradEst[[iSite]])
			logRegLoss[[iSite]] <- unlist(materialsCollector$res$lossEst[[iSite]])
			logRegHessian[[iSite]] <- matrix(unlist(materialsCollector$res$hessianEst[[iSite]]), numPar,numPar)
		}
		gradEst <- Reduce("+",logRegGrad)
		hessianEst <- Reduce("+",logRegHessian)
		lossEst <- Reduce("+",logRegLoss)
		## cheking convergence		
		if (max(abs(lossEst - oldLoss)) < epsilon) {
			stoppingReason <- paste("Convergence criteria is met in ", iter, " iteration")
			break
		}
		if (iter >= maxit) {
			stoppingReason <- "Reaching maximum number of iterations."
			break
		}
		#diffBeta <- abs(oldBeta-beta)
		oldBeta <- beta
		oldLoss <- lossEst
		beta <- beta - MASS::ginv(hessianEst)%*%gradEst
	}
	## Now with estimated beta, we are goign to estimate its covariance matrix
	## collecting materials
	RFunction 			<- "computeCovMatLogReg"
	collectFunction <- "collectCovMatLogReg"
	
	# Call collectors
	covMatCollector <- collector(session = session, RFunction = RFunction, 
			collectFunction = collectFunction, previousCollector = materialsCollector, 
			MoreArgs = list(modelFormula = modelFormula, 
					isFactor = isFactor, 
					beta = beta, 
					centerX = centerX, 
					centerVar = centerVar,
					factorLevels = factorLevels,
					epsilon = epsilon),
			sendSiteID = TRUE)
	## extracting the covariance matrix
	covEst <- list()
	separationIdx <- matrix(NA, numSites, 2)
	for (iSite in 1:numSites){
		covEst[[iSite]] <- matrix(unlist(covMatCollector$res$covMat[[iSite]]),
				numPar, numPar)
		separationIdx[iSite, ] <- unlist(covMatCollector$res$separation[[iSite]])
	}
	## Computing covariance matrix
	covMatbeta <- MASS::ginv(Reduce("+",covEst))
	## checking complete separation
	if (any(c(separationIdx)) > 1){
		warning("Some fitted probabilities are numerically 0 or 1!")
	}
	rownames(beta) <- colnames(covMatbeta) <- rownames(covMatbeta) <- covariateNames
	zValues <- beta/sqrt(diag(covMatbeta))
	pValues <- 2*pnorm(-abs(zValues))
	summaryTable <- data.frame(beta, sqrt(diag(covMatbeta)), zValues, pValues)
	## colnames obtaiend from glm output
	colnames(summaryTable) <- c("Estimate", "Std. Error", "z value", "Pr(>|z|)")  
	print(round(summaryTable, 5))
	return(list(paramEst = beta, paramCov = covMatbeta, summaryResults = summaryTable,
					convNote = stoppingReason, previousCollector = covMatCollector))
}