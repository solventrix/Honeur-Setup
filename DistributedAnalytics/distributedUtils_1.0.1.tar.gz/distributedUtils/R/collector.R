#' Function that go over sites and collect information
#' @param session session information as created by \link{initDistributedSession}
#' @param RFunction string indicating the name of the R function to run
#' @param collectFunction string indicating the name of the collect function used to combined the results got from different queues
#' @param time.sleep time in seconds that the function will wait until next try if fails
#' @param previousCollector the output of the previous collector
#' @param MoreArgs a list of other arguments to RFunction
#' @param subsetCenter a vector giving a subset of the xenter which should be used
#' @param sendSiteID logical with default False specifying whether the sideID should be also sent to the centers or not.
#' @return dataframe 
#' @importFrom RJSONIO toJSON
#' @importFrom httr HEAD content
#' @export
collector <- function(session, RFunction, collectFunction, time.sleep = 2,
previousCollector = NULL, MoreArgs = NULL, subsetCenter = NULL, sendSiteID = FALSE){
    # 0. It is sometimes that the operation needs to be done only on a subset of the centers involved
    # in the sudy, for example, for propensity score matching, we may select one site and ask for a
    # random propensity score from there, so then we should not go over all sites. For that, I've added
    # the argument subsetCenter, which would possibly provide a subset of center and before doing anything,
    # we may apply this subset on all related argument.
    #	siteNums <- seq_along(session$centerIds)
    #	if (!is.null(subsetCenter)){
    #			session$dataPath <- session$dataPath[subsetCenter]
    #			session$centerIds <- session$centerIds[subsetCenter]
    #			session$replyQueues <- session$replyQueues[subsetCenter]
    #			siteNums <- subsetCenter
    #		}

    # 1. Post messages to the different sites
    if (is.null(subsetCenter))subsetCenter <- seq_along(session$centerIds)

    for (i in subsetCenter) {
        # This I've changedm since sometimes it's needed to know which center we are working on.
        if (sendSiteID) {
            MoreArgsNew <- MoreArgs
            MoreArgsNew[[length(MoreArgs) + 1]] <- i
            names(MoreArgsNew)[length(MoreArgsNew)] <- "siteNum"
            jsonBody <- RJSONIO::toJSON(c(list(
            RFunction = RFunction,
            dataPath = session$dataPath[i]),
            MoreArgsNew))
        } else {
            jsonBody <- RJSONIO::toJSON(c(list(
            RFunction = RFunction,
            dataPath = session$dataPath[i]),
            MoreArgs))
        }
        #			jsonBody <- RJSONIO::toJSON(c(list(
        #                         replyQueue   = session$replyQueues[i],
        #                         RFunction    = RFunction,
        #                         dataPath     = session$dataPath[i]),
        #                         MoreArgs))

        distributedRequestMessage <- list(
            "uuid"=session$requestUuid,
            "study"=session$studyId,
            "context"=session$context,
            "analyst"=session$analyst,
            "organization"=session$centerIds[i],
            "payload"=jsonBody)

        print(distributedRequestMessage)

        distributedRequestResponse <- postDistributedRequestMessage(
          distributedAnalyticsApiUrl = session$distributedAnalyticsApiUrl,
          tokenContext = session$tokenContext,
          distributedRequestMessage = distributedRequestMessage)

        if(http_error(distributedRequestResponse)) {
            warning(http_status(distributedRequestResponse)$message)
        }

        cat("Message posted to '", session$centerIds[i], "' requesting the calculation of '", RFunction, "'\n", sep = '')

    }

    cat(rep('-', getOption("width")), '\n', sep = '')

    # 2. Retrieve messages from the different sites
    success <- rep(FALSE, length(subsetCenter))
    i <- 1    # Index of centers
    firstIteration <- TRUE
    k <- 1 # Number of iterations

    replyMessages <- list()

    while (! all(success))
    {
        # Retrieve messages
        msg <- pollResponseMessage(distributedAnalyticsApiUrl=session$distributedAnalyticsApiUrl, tokenContext=session$tokenContext, requestUuid=session$requestUuid, organization=session$centerIds[subsetCenter[i]])

        print(msg$status_code)

        if (msg$status_code == 200) {
            success[i] <- TRUE

            cat('Reply message from ', session$centerIds[subsetCenter[i]], ' received\n\n', sep = '')

            jsonResponseParsed <- content(msg, as="parsed")
            print(jsonResponseParsed$payload)

            jsonResponsePayloadParsed <- fromJSON(jsonResponseParsed$payload)
            print (jsonResponsePayloadParsed)

            replyMessages[[subsetCenter[i]]] <- jsonResponsePayloadParsed

            responseMessageUuid <- jsonResponseParsed$uuid
            acknowledgeResponseMessage(distributedAnalyticsApiUrl=session$distributedAnalyticsApiUrl, tokenContext=session$tokenContext, responseMessageUuid=responseMessageUuid)

            i <- i + 1
        } else {
            if (k == 1) cat('[Data scientist] Waiting for messages...\n', sep = '')
            k <- k + 1
            Sys.sleep(time.sleep) # Try to retrieve messages every 2 seconds
        }
    }

    str(replyMessages)

    # 3. Combine information from the different sites
    # sometimes there is nothing to collect, we just want to do something on every site, so we may want to set collector as NULL
    # instead of making a collector function that does nothing.
    if (! is.null(collectFunction)) {
        resCombined <- do.call(collectFunction, args = list(replyMessages))
    } else {
        resCombined <- "Nothing to return!"
    }

    list(res = resCombined)
}
