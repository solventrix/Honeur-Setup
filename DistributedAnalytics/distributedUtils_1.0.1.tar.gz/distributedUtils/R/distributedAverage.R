#' Simple function to calculate the average given a json containing a list of sum values and sample sizes
#' @param config a list with these components: "studyId", "centerIds", "messageBrokerAddress", 
#' "dataPath", here is an example:
#' dataPath <- c(system.file('extdata', 'dataLogReg1.csv', package = 'distributedUtils'),
#' 		system.file('extdata', 'dataLogReg2.csv', package = 'distributedUtils'))
#' config <- list(
#' 		studyId = "study1",
#' 		centerIds = paste0('center', 1:2),
#' 		messageBrokerAddress = messageBrokerAddress,
#' 		dataPath = dataPath
#' )
#' @param variableName string indicating the variable for which the average will be calculated
#' @param groupingVariable string indicating variable that  defines groups. It could be a binary variable, for example
#' for comparing treated/non-treated in case of propensity score matching.
#' @param onlyMatchedSubjects if TRUE, will only use the matched subjects
#' @return average
#' @export
distributedAverage <- function(config, variableName, groupingVariable = NULL, onlyMatchedSubjects = FALSE){
    session <- initDistributedSession(config = config)
    on.exit(closeDistributedSession(session))
    previousCollector <- NULL

    ## Subsetting data
    if (onlyMatchedSubjects){
        RFunction 			<- "computeDataSubsetting"
        collectFunction <- "collectDataSubsetting"

        # Call collectors
        dataSubsettingCollector <- collector(session = session, RFunction = RFunction,
        collectFunction = collectFunction, previousCollector = previousCollector,
        MoreArgs = NULL, sendSiteID = TRUE)
        config$dataPath <- unlist(dataSubsettingCollector$res)
        closeDistributedSession(session)
        session <- initDistributedSession(config = config)
    }



    previousCollector <- NULL
    RFunction 			<- "computeSumAndSampleSize"
    collectFunction <- "collectSumAndSampleSize"

    # Call collectors
    sumAndSampleSizeCollector <- collector(session = session, RFunction = RFunction,
    collectFunction = collectFunction, previousCollector = previousCollector,
    MoreArgs = list(variableName = variableName, groupingVariable = groupingVariable))

    # Extract result
    if (is.null(groupingVariable)){
        sumAndSampleSize <- sumAndSampleSizeCollector$res
        average2return <- sum(sumAndSampleSize$sum)/sum(sumAndSampleSize$sampleSize)
    }else{
        sumAndSampleSize <- sumAndSampleSizeCollector$res
        average2return <- apply(matrix(unlist(sumAndSampleSize$sum), nrow=length(sumAndSampleSize$sum)), 2,sum)/
        apply(matrix(unlist(sumAndSampleSize$sampleSize), nrow=length(sumAndSampleSize$sampleSize)), 2, sum)
        names(average2return) <- sub("sum.", "", names(sumAndSampleSize$sum))
    }
    # Compute average based on collectors info
    list(res = average2return,
    previousCollector = sumAndSampleSizeCollector)

}