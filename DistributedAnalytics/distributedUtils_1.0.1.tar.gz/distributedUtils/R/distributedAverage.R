#' Simple function to calculate the average given a json containing a list of sum values and sample sizes
#' @param config a list with these components: "studyId", "centerIds", "messageBrokerAddress", 
#' "dataPath", here is an example:
#' dataPath <- c(system.file('extdata', 'dataLogReg1.csv', package = 'distributedUtils'),
#' 		system.file('extdata', 'dataLogReg2.csv', package = 'distributedUtils'))
#' config <- list(
#' 		studyId = "study1",
#' 		centerIds = paste0('center', 1:2),
#' 		messageBrokerAddress = messageBrokerAddress,
#' 		dataPath = dataPath
#' )
#' @param variableName string indicating the variable for which the average will be calculated
#' @return average
#' @export
distributedAverage <- function(config, variableName) {

    session <- initDistributedSession(config = config)
	on.exit(closeDistributedSession(session))

    previousCollector <- NULL
    RFunction <- "computeSumAndSampleSize"
    collectFunction <- "collectSumAndSampleSize"

    # Call collectors
    sumAndSampleSizeCollector <- collector(session = session, RFunction = RFunction,
    collectFunction = collectFunction, previousCollector = previousCollector,
    MoreArgs = list(variableName = variableName))

    # Extract result
    sumAndSampleSize <- sumAndSampleSizeCollector$res


    # Compute average based on collectors info
    list(res = sum(sumAndSampleSize$sum) / sum(sumAndSampleSize$sampleSize),
    previousCollector = sumAndSampleSizeCollector)
}