# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################
#' compute the contribution of each site to the covariance matrix, also
#' the propensity scores in that site.
#' @param modelFormula model formula
#' @param isFactor a vector of ones and zeros with the same length as the number of covariates in the model. 
#' 1 would show its corresponding covariate is a factor, and 0 would show otherwise. 
#' @param beta estimated parameter vector
#' @param centerX part of design matrix related to the  site effect
#' @param centerVar a variable indicating various centers
#' @param dataPath path to the location of data
#' @param factorLevels a list with its component determining the levels of factor columns
#' @param epsilon the tolerance level
#' @param siteNum ID of the corresponding site
#' @return returncontribution to the covariance matrix, and writes the propensity scores.
#' 
#' @importFrom utils write.csv
#' @importFrom utils write.table
#' @importFrom jsonlite write_json
#' @author Vahid Nassiri
#' @export

computeCovMatLogReg<- function(modelFormula, isFactor, beta, centerX,centerVar,
		dataPath, factorLevels, epsilon, siteNum){
	modelFormula <- as.formula(modelFormula)
	inputData <- readData(dataPath, modelFormula, isFactor)
	siteSize <- nrow(inputData)
	## Now making data matrix X
	iniX <- model.frame(modelFormula, data = as.data.frame(inputData), xlev = factorLevels)
	## Now making data matrix X
	centerVar <- unlist(centerVar)
	if (is.null(centerX)){
		X <- as.matrix(data.frame(model.matrix(modelFormula, data = iniX)))
	}else{
		X <- as.matrix(data.frame(model.matrix(modelFormula, data = iniX), centerX[centerVar == siteNum,]))
	}
	propensityScore <- 1/(1+exp(-X %*% beta))
	## Here we make a dataset of the response and the propensity scores
	## and save it somewhere for later use
	yName <- all.vars(modelFormula)[1]
	PStoExport <- data.frame(inputData[,which(names(inputData) == yName)], propensityScore)
	colnames(PStoExport) <- c("response", "propensityScore")
	write.csv(PStoExport, file = paste(dirname(dataPath), "/propensityScores", siteNum, ".csv", sep =""),
			row.names = FALSE)
#	write_json(PStoExport, path= paste(dirname(dataPath), "/propensityScores",siteNum, ".json", sep =""),
#			digits = NA)
	separationIdx <- c(sum(PStoExport[,2] < epsilon), sum(PStoExport[,2]>(1-epsilon)))
	covMat <- ((t(X)%*%diag(c(propensityScore*(1-propensityScore)))) %*% X)
		return(list(covMat = covMat, separation = separationIdx))
}

