#' Simple function to calculate the variance given a json containing a list of sum of squares values and sample sizes
#' @param config a list with these components: "studyId", "centerIds", "messageBrokerAddress", 
#' "dataPath", here is an example:
#' dataPath <- c(system.file('extdata', 'dataLogReg1.csv', package = 'distributedUtils'),
#' 		system.file('extdata', 'dataLogReg2.csv', package = 'distributedUtils'))
#' config <- list(
#' 		studyId = "study1",
#' 		centerIds = paste0('center', 1:2),
#' 		messageBrokerAddress = messageBrokerAddress,
#' 		dataPath = dataPath
#' )
#' @param variableName string indicating the variable for which the variance will be calculated
#' @return variance
#' @export
distributedVariance <- function(config, variableName){
	session <- initDistributedSession(config = config)  
	on.exit(closeDistributedSession(session))
	previousCollector <- NULL
	## First step is to compute the overall mean:
	overalMean <- distributedAverage(config = config, variableName = variableName)
	## Now the overal mean, together with session, and variableName should be sent
	## to each center, there the sum of squares as well as the sample size should
	## be returned. 
	RFunction 			<- "computeSumOfSquaresAndSampleSize"
	collectFunction <- "collectSumOfSquaresAndSampleSize"
	previousCollector <- NULL 
	session <- initDistributedSession(config = config)  
	# Call collectors
	sumOfSquaresAndSampleSizeCollector <- collector(session = session, RFunction = RFunction, 
			collectFunction = collectFunction, previousCollector = previousCollector, 
			MoreArgs = list(variableName = variableName, overalMean = overalMean$res))
	
	# Extract result
	sumofSquaresAndSampleSize <- sumOfSquaresAndSampleSizeCollector$res
	# Compute average based on collectors info
	list(res = sum(sumofSquaresAndSampleSize$sumOfSquares)/(sum(sumofSquaresAndSampleSize$sampleSize)-1),
       previousCollector = sumOfSquaresAndSampleSizeCollector)
	
}
