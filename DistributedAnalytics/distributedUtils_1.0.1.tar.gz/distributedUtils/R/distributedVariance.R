#' Simple function to calculate the variance given a json containing a list of sum of squares values and sample sizes
#' @param config a list with these components: "studyId", "centerIds", "messageBrokerAddress", 
#' "dataPath", here is an example:
#' dataPath <- c(system.file('extdata', 'dataLogReg1.csv', package = 'distributedUtils'),
#' 		system.file('extdata', 'dataLogReg2.csv', package = 'distributedUtils'))
#' config <- list(
#' 		studyId = "study1",
#' 		centerIds = paste0('center', 1:2),
#' 		messageBrokerAddress = messageBrokerAddress,
#' 		dataPath = dataPath
#' )
#' @param variableName string indicating the variable for which the variance will be calculated
#' @param groupingVariable string indicating variable that  defines groups. It could be a binary variable, for example
#' for comparing treated/non-treated in case of propensity score matching.
#' @param onlyMatchedSubjects if TRUE, will only use the matched subjects
#' @return variance
#' @export
distributedVariance <- function(config, variableName, groupingVariable = NULL, onlyMatchedSubjects = FALSE){
	session <- initDistributedSession(config = config)
	on.exit(closeDistributedSession(session))
	previousCollector <- NULL
	## Subsetting data
	if (onlyMatchedSubjects){
		RFunction 			<- "computeDataSubsetting"
		collectFunction <- "collectDataSubsetting"

		# Call collectors
		dataSubsettingCollector <- collector(session = session, RFunction = RFunction,
				collectFunction = collectFunction, previousCollector = previousCollector,
				MoreArgs = NULL, sendSiteID = TRUE)
		config$dataPath <- unlist(dataSubsettingCollector$res)
		closeDistributedSession(session)
		session <- initDistributedSession(config = config)
	}

	## First step is to compute the overall mean:
	overalMean <- distributedAverage(config = config, variableName = variableName, groupingVariable = groupingVariable)
	## Now the overal mean, together with session, and variableName should be sent
	## to each center, there the sum of squares as well as the sample size should
	## be returned.
	RFunction 			<- "computeSumOfSquaresAndSampleSize"
	collectFunction <- "collectSumOfSquaresAndSampleSize"
	previousCollector <- NULL
	closeDistributedSession(session)
	session <- initDistributedSession(config = config)
	# Call collectors
	sumOfSquaresAndSampleSizeCollector <- collector(session = session, RFunction = RFunction,
			collectFunction = collectFunction, previousCollector = previousCollector,
			MoreArgs = list(variableName = variableName, groupingVariable = groupingVariable, overalMean = overalMean$res))

	# Extract result
	#sumofSquaresAndSampleSize <- sumOfSquaresAndSampleSizeCollector$res
	# Extract result
	if (is.null(groupingVariable)){
		sumofSquaresAndSampleSize <- sumOfSquaresAndSampleSizeCollector$res
		variance2return <- sum(sumofSquaresAndSampleSize$sumOfSquares)/(sum(sumofSquaresAndSampleSize$sampleSize)-1)
	}else{
		sumofSquaresAndSampleSize <- sumOfSquaresAndSampleSizeCollector$res
		variance2return <- unlist(lapply(lapply(lapply(sumofSquaresAndSampleSize$sumOfSquares, unlist), unlist), sum))/
				(unlist(lapply(lapply(lapply(sumofSquaresAndSampleSize$sampleSize, unlist), unlist), sum))-1)
#		names(variance2return) <- sub("sum.", "", names(sumofSquaresAndSampleSize$sumOfSquares))
		names(variance2return) <- sumOfSquaresAndSampleSizeCollector$res$groupNames
	}
	# Compute average based on collectors info
	# Compute average based on collectors info
	list(res = variance2return,
       previousCollector = sumOfSquaresAndSampleSizeCollector)

}
