###############################################################################
# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' reads data in and make columns that shpuld be factors, actually factors. this will be applied in each site.
#' 
#' @param dataPath a list with the same length as the number of sites, each
#' element of the list is the address of the data on the hard disk in the corresponding site.
#' @param modelFormula model formula (note that, if propensity score matching is asked, the response 
#' will be considered as an indicator of case and control groups with being case as success).
#' @param isFactor a vector of ones and zeros with the same length as the number of covariates in the model. 
#' 1 would show its corresponding covariate is a factor, and 0 would show otherwise. 
#' @param isSurvival logical variable with default as FALSE (not a survival model), otherwise TRUE
#' @return dataset
#' @importFrom utils getFromNamespace read.csv
#' @author Vahid Nassiri
readData <- function(dataPath, modelFormula, isFactor, isSurvival = FALSE){
	## Read the data in
	inputData <- read.csv(dataPath)
	## Find the column names which are factors
	# Note that the role of isSurvival is: when it is a survival model,
	# the response consists of two columns (time to event and status), so
	# the covariates will begin from the third term in the model. In usual case
	# (lm, glm) it will be right the second term.
	if (isSurvival){
		nameFactors <- all.vars(modelFormula)[which(isFactor == 1) + 2]
	}else{
		nameFactors <- all.vars(modelFormula)[which(isFactor == 1) + 1]
		
	}
	## make the columns which are factors, actually factors!
	for (i in seq_along(nameFactors)){
		inputData[,which(colnames(inputData) == nameFactors[i])] <- factor(inputData[,which(colnames(inputData) == nameFactors[i])])
	}
	## here we only return columns which are in the model
	return(inputData[,colnames(inputData)%in%all.vars(modelFormula)])
}

