#' Function to post a distributed request message to the Distributed Analytics service
#' @param distributedAnalyticsApiUrl url of the distributed analytics service
#' @param tokenContext a JWT and the corresponding fingerprint
#' @param distributedRequestMessage the details of the distributed request message (UUID, study, context, analyst, organization, payload)
#' @importFrom httr warning add_headers set_cookies HEAD POST
#' @export
postDistributedRequestMessage <- function(distributedAnalyticsApiUrl, tokenContext, distributedRequestMessage) {

    distributedAnalyticsApiUrl <- paste(distributedAnalyticsApiUrl, "distributed-requests", sep = "/")

    response <- POST(url = distributedAnalyticsApiUrl, body = distributedRequestMessage, add_headers(token = tokenContext$token), set_cookies('userFingerprint' = tokenContext$fingerprint), content_type = content_type_json(), encode = 'json')

    if(http_error(response)) {
        warning(http_status(response)$message)
    }

    return (response)
}
