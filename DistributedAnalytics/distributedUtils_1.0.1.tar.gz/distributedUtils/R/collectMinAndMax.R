# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' Combined results obtained by \link{collector} 
#' @param replyMessages list of named lists returned by the RFunction \link{computeSumAndSampleSize}
#' @return data frame containing the min and max
#' @export
collectMinAndMax <- function(replyMessages){
	
	resCombined <- lapply(replyMessages, function(x) {
				c(estMin = x$estMin, estMax = x$estMax)
			})
	
	as.data.frame(do.call('rbind', resCombined))
}


