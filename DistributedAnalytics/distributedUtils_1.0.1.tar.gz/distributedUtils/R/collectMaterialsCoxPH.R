#' Combined results obtained by \link{collector} 
#' @param replyMessages list of named lists returned by the RFunction \link{computeMaterialsAndReadDataPerSiteCoxph}
#' @return data frame containing the number of parameters in the model
#' @export
collectMaterialsCoxPH <- function(replyMessages){
	
	resCombined <- lapply(replyMessages, function(x) {
				c(x)
			})
	
	as.data.frame(do.call('rbind', resCombined))
}

