# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' computes cost function of the logistic regression
#' @param beta estimated parameter vector
#' @param X design matrix
#' @param y response
#' @param sampleSize sample size
#' @return logistic cost function  
#' 
#' @author Vahid Nassiri
#' @export
computeCostFunctionLogistic <- function(beta, X, y, sampleSize){
	logisticCost <- sum(y*log(sigmoid(X%*%beta)) + (1-y)*log(1-sigmoid(X%*%beta)))*(-1/sampleSize)
	return(logisticCost)
}