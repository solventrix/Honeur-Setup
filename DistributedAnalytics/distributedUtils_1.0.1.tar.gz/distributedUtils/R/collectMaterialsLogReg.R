# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' Combined results obtained by \link{collector} 
#' @param replyMessages list of named lists returned by the RFunction \link{computeSumAndSampleSize}
#' @return data frame containing the sample size in each site and number of parameters in the model.
#' @export
collectMaterialsLogReg <- function(replyMessages){
	
	resCombined <- lapply(replyMessages, function(x) {
				list(gradEst = x$gradEst, hessianEst = x$hessianEst, lossEst = x$lossEst)
			})
	
	as.data.frame(do.call('rbind', resCombined))
}


