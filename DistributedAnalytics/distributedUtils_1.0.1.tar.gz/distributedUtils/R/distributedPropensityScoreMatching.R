# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################



#' function
#' @param config a list with these components: "studyId", "centerIds", "messageBrokerAddress",
#' "dataPath", here is an example:
#' dataPath <- c(system.file('extdata', 'dataLogReg1.csv', package = 'distributedUtils'),
#' 		system.file('extdata', 'dataLogReg2.csv', package = 'distributedUtils'))
#' config <- list(
#' 		studyId = "study1",
#' 		centerIds = paste0('center', 1:2),
#' 		messageBrokerAddress = messageBrokerAddress,
#' 		dataPath = dataPath
#' )
#' @param modelFormula model formula, the response should be indicator of cases (coded as 1) and controls (coded as 0).
#' @param isFactor a vector of ones and zeros with the same length as the number of covariates in the model.
#' 1 would show its corresponding covariate is a factor, and 0 would show otherwise.
#' @param epsilon convergence tolorence (positive and small). Note that the same epsilon
#' will be used to see if the predicted probabilities are close to 0 or 1 (quai-complete separation). Also
#' whenever there is a need to take care of the rounding error, the same epsilon is used as the tolerance.
#' @param maxit maximum number of iterations of the Newton-Raphson algorithm
#' @param includeSiteEffect logical variable with default TRUE, indicating whether site effect should be
#' included in the model or not.
#' @param matchingCaliper logical variable indicating whether a caliper shpould be used for matching or not.
#' @param caliperValue if matchingCaliper = TRUE and caliperValue = NULL, then we use 0.25 * standard deviation of
#' propensity score as caliper, otherwise, the specified value in caliperValue will be used.
#' @return a list with mathcing result, convergence reason, and previous collector, as well as fitted logistic
#' regression model. It also writes the matched subjects in each site in there.
#' @import ggplot2
#' @import gridExtra
#' @author Vahid Nassiri
#' @export
distributedPropensityScoreMatching <- function(config, modelFormula, isFactor, epsilon = 1e-8, maxit = 25,
		includeSiteEffect = TRUE, matchingCaliper = TRUE, caliperValue = NULL){
	session <- initDistributedSession(config = config)
	on.exit(closeDistributedSession(session))
	previousCollector <- NULL
	## removePreviousMatched = TRUE will remove all matched files previously, if it is FALSE, it will add the time
	## and date to the end of the file name and keep it there at each site.
	numSites <- length(session$dataPath)
	## checks
	if (numSites < 1 | floor(numSites)!= numSites){
		stop("numSites should be and integer larger than or equal to 1.")
	}
	if (length(isFactor) != (length(all.vars(as.formula(modelFormula)))-1)){
		stop("length of isFactor should be equal to the number of covariates.")
	}
	## The first step is to fit a logistic regression to obtain propensity scores themselves.
	distLogFit <- distributedLogisticRegression (config = config, modelFormula = modelFormula,
			isFactor = isFactor, epsilon = epsilon, maxit = maxit,
			includeSiteEffect = includeSiteEffect)
	previousCollector <- NULL
	## After fitting the logistic regression, the propensity scores of each site are stored as
	## csv files there, here we define the path to the propensity scores.
	pathPS <- c()
	for (iSite in 1:numSites){
		pathPS[iSite] <- paste(dirname(dataPath[[iSite]]), "/propensityScores", iSite, ".csv", sep ="")
	}
	## Now we define the caliper, if it is TRUE then we use  Rosenbaum and Rubin (1985) suggestion,
	## as 1/4 sigma(PS). Otherwise, we use the range of propensity scores are caliper. This way the matching
	## will be continued to the end.
	if (matchingCaliper & is.null(caliperValue)){
		sessionCaliper <- session
		sessionCaliper$dataPath <- pathPS
		varPS <- distributedVariance(sessionCaliper, variableName = "propensityScore")
		previousCollector <- NULL
		session <- initDistributedSession(config = config)
		caliperValue <- sqrt(varPS$res)/4
		#previousCollector <- varPS$previousCollector
	}

	sessionReadPS <- session
	sessionReadPS$dataPath <- pathPS

	RFunction 			<- "computeReadCaseControlPS"
	collectFunction <- "collectReadCaseControlPS"

	# Call collectors
	caseControlPScollector <- collector(session = sessionReadPS, RFunction = RFunction,
			collectFunction = collectFunction, previousCollector = previousCollector,
			sendSiteID = FALSE)
	previousCollector <- caseControlPScollector

	## make a suitable output from the collector
	iSite <- 1
	## Here we have values: the propensity scores themselves
	## siteIndicators: indicating which site we are dealing with,
	## and id, which shows an id created to refer to cases and contreols in each site
	casePSvalue <- unlist(caseControlPScollector$res[[1]][[iSite]])
	casePSsiteIndicator <- rep(iSite, length(unlist(caseControlPScollector$res[[1]][[iSite]])))
	casePSid <- seq_along(unlist(caseControlPScollector$res[[1]][[iSite]]))
	casePSidWithSite <- cbind(casePSid, rep(iSite, length(casePSid)))
	controlPSvalue <- unlist(caseControlPScollector$res[[2]][[iSite]])
	controlPSsiteIndicator <- rep(iSite, length(unlist(caseControlPScollector$res[[2]][[iSite]])))
	controlPSid <- seq_along(unlist(caseControlPScollector$res[[2]][[iSite]]))
	controlPSidWithSite <- cbind(controlPSid, rep(iSite, length(controlPSid)))
	if (numSites > 1){
		for (iSite in 2:numSites){
			casePSvalue <- c(casePSvalue, unlist(caseControlPScollector$res[[1]][[iSite]]))
			casePSsiteIndicator <- c(casePSsiteIndicator, rep(iSite, length(unlist(caseControlPScollector$res[[1]][[iSite]]))))
			casePSid <- c(casePSid, seq_along(unlist(caseControlPScollector$res[[1]][[iSite]])))
			casePSidWithSite <- rbind(casePSidWithSite, cbind( seq_along(unlist(caseControlPScollector$res[[1]][[iSite]])),
							rep(iSite, length( seq_along(unlist(caseControlPScollector$res[[1]][[iSite]]))))))
			controlPSvalue <- c(controlPSvalue, unlist(caseControlPScollector$res[[2]][[iSite]]))
			controlPSsiteIndicator <- c(controlPSsiteIndicator, rep(iSite, length(unlist(caseControlPScollector$res[[2]][[iSite]]))))
			controlPSid <- c(controlPSid, seq_along(unlist(caseControlPScollector$res[[2]][[iSite]])))
			controlPSidWithSite <- rbind(controlPSidWithSite, cbind(seq_along(unlist(caseControlPScollector$res[[2]][[iSite]])),
							rep(iSite, length(seq_along(unlist(caseControlPScollector$res[[2]][[iSite]]))))))
		}
	}
	## Now that we have PS's from all sites separately for cases and controls,
	## we can begin to match them. We may return both one-to-one, and one-to-many
	diffAll <- abs(t(t(matrix(rep(casePSvalue, length(controlPSvalue)), length(casePSvalue), length(controlPSvalue))) - controlPSvalue))
	allCaseNames <- paste("case",casePSid, "center", casePSsiteIndicator, sep = "")
	allControlNames <- paste("control",controlPSid, "center", controlPSsiteIndicator, sep = "")
#orderedDiff <- apply(diffAll, 1, order)
	matchingRes <- matchingResAll <- diffAllordered <- matrix(NA, nrow(diffAll), ncol(diffAll))
	for (iCase in 1:length(casePSvalue)){
		tmpOrder <- order(diffAll[iCase,])
		subIDX <- which(diffAll[iCase, tmpOrder] < caliperValue)
		if (length(subIDX) > 0){
			matchingRes[iCase,1:length(subIDX)] <- allControlNames[tmpOrder][subIDX]
		}
		diffAllordered[iCase,] <- diffAll[iCase,tmpOrder]
		matchingResAll[iCase,] <- allControlNames[tmpOrder]
	}

	if (matchingCaliper){
		matchingResAll[diffAllordered >= caliperValue] <- NA
	}
	diffAllorderedChar <- matrix(NA, nrow(diffAllordered), ncol(diffAllordered))
	for (iRow in 1:nrow(diffAllordered)){
		for (iCol in 1:ncol(diffAllordered)){
			diffAllorderedChar[iRow, iCol] <- paste("(",round(diffAllordered[iRow,iCol], 3), ")", sep = "")
		}
	}

	rownames(diffAll) <- rownames(diffAllordered) <- rownames(matchingResAll) <- rownames(matchingRes) <- rownames(diffAllorderedChar) <- allCaseNames

	one2manyResults <- list(matchingResults = matchingResAll, absoluteDifference = diffAllordered)

	## Now imagine we want to match one to one, but overally optimal
	diffAllNew <- diffAll
	## If caliper true:
	if (matchingCaliper){
		diffAllNew[diffAllNew >= caliperValue] <- NA
	}

	matchingResults1to1 <- matrix(NA, length(allCaseNames), 2)
	if (sum(!is.na(diffAllNew)) > 0 ){
		minLoc <- which(diffAllNew == min(diffAllNew, na.rm = TRUE), arr.ind = TRUE)[1,]
		diffPS <- min(diffAllNew, na.rm = TRUE)
		matchingResults1to1 <- c(allCaseNames[minLoc[1]], allControlNames[minLoc[2]])
		diffAllNew[minLoc[1],] <- diffAllNew[, minLoc[2]] <- NA
		while (sum(!is.na(diffAllNew)) > 0 ){
			#minLoc <- which(diffAllNew == min(diffAllNew, na.rm = TRUE), arr.ind = TRUE)
			minLoc <- which(diffAllNew == min(diffAllNew, na.rm = TRUE), arr.ind = TRUE)[1,]
			diffPS <- c(diffPS, min(diffAllNew, na.rm = TRUE))
			matchingResults1to1 <- rbind(matchingResults1to1,
					c(allCaseNames[minLoc[1]], allControlNames[minLoc[2]]))
			diffAllNew[minLoc[1],] <- diffAllNew[, minLoc[2]] <- NA
		}
		rownames(matchingResults1to1) <- NULL
	}else{
		cat("There is no propensity score smaller than the caliper to match! \n")
	}
	one2oneResutls <- data.frame(case = matchingResults1to1[,1],
			control = matchingResults1to1[,2], diffPS = diffPS)
	## all we do now is extracting the id for the case or control, also the center
	## first for cases: column 1
	one2oneResultsID <- matrix(NA, nrow(one2oneResutls), 4)
	for (iSubj in 1:nrow(one2oneResutls)){
		caseID <- as.numeric(sub(".*case *(.*?) *center.*", "\\1", one2oneResutls[iSubj,1]))
		caseCenter <- as.numeric(sub('.*center', '', one2oneResutls[iSubj,1]))
		controlID <- as.numeric(sub(".*control *(.*?) *center.*", "\\1", one2oneResutls[iSubj,2]))
		controlCenter <- as.numeric(sub('.*center', '', one2oneResutls[iSubj,2]))
		one2oneResultsID[iSubj,] <- c(caseID, caseCenter, controlID, controlCenter)
	}
	## now we need to make one list per center, the list has two elements:
	## ID's of the cases and ID's of the controls
	matchedPerSite <- list()
	for (iSite in 1:numSites){
		matchedPerSite[[iSite]] <- list(case = sort(one2oneResultsID[one2oneResultsID[,2] == iSite,1]),
				control = sort(one2oneResultsID[one2oneResultsID[,4] == iSite,3]))

	}
	for (iSite in 1:numSites){
		#closeDistributedSession(session)
#		configNew <- list(
#				studyId = config$studyId,
#				centerIds = config$centerIds[iSite],
#				messageBrokerAddress = messageBrokerAddress,
#				dataPath = config$dataPath[1]
#		)
#		sessionWriteMatchedSubjs <- initDistributedSession(config = configNew)
	## In order to see which variable is the grouping variable (indicating cases and controls),
	## we just also send the name of the response here, this will be written in each site and then is read when needed.
	getResponse <- function(formula) {
		tt <- terms(formula)
		vars <- as.character(attr(tt, "variables"))[-1] ## [1] is the list call
		response <- attr(tt, "response") # index of response var
		vars[response]
	}
	respName <- getResponse(as.formula(modelFormula))
		RFunction 			<- "computeWriteMatchedSubjects"
		collectFunction <- "collectMatchedSubjectsStatus"
		writeMatchedSubjscollector <- collector(session = session, RFunction = RFunction,
				collectFunction = collectFunction, previousCollector = previousCollector,
				MoreArgs = list(matchedList = matchedPerSite[[iSite]], respName = respName), subsetCenter = c(iSite), sendSiteID = TRUE)
		previousCollector <- writeMatchedSubjscollector
		cat(writeMatchedSubjscollector$res$V1[[1]],"\n")
	}
	## Now we need to send them to the sites and write them down

	## Here we add the requested histograms
	### first we need to get the subset of matched subjects for cases an controls
	matchedCasesIDs <- one2oneResultsID[,1:2]
	matchedControlsIDs <- one2oneResultsID[,3:4]
	## We also have akll propensity scores for cases and control: casePSvalue and controlPSvalue

	### Now we need to find the index of matched ones.
	### All indexes are in controlPSidWithSite and casePSidWithSite
	### matched indesxes are in matchedCasesIDs, and matchedControlsIDs
	### To check which oens are matched, we simply join two columns
	matchedCases <- which(paste(casePSidWithSite[,1], casePSidWithSite[,2])%in%	paste(matchedCasesIDs[,1], matchedCasesIDs[,2]))
	unmatchedCases <- which(!(paste(casePSidWithSite[,1], casePSidWithSite[,2])%in%	paste(matchedCasesIDs[,1], matchedCasesIDs[,2])))
	matchedControls <- which(paste(controlPSidWithSite[,1], controlPSidWithSite[,2])%in%	paste(matchedControlsIDs[,1], matchedControlsIDs[,2]))
	unmatchedControls <- which(!(paste(controlPSidWithSite[,1], controlPSidWithSite[,2])%in%	paste(matchedControlsIDs[,1], matchedControlsIDs[,2])))
	## Hist all
	if (length(casePSvalue) > 0){
		histPScase <- ggplot(data = data.frame(casePS = casePSvalue), aes(x = casePS)) +
				geom_histogram(color="black", fill="white", bins = 30) +
				xlab("Propensity score") + ggtitle("All Cases")
	}else{
		histPScase <- NULL
	}
	if (length(controlPSvalue) > 0){
		histPScontrol <- ggplot(data = data.frame(controlPS = controlPSvalue), aes(x = controlPS)) +
				geom_histogram(color="black", fill="white", bins = 30) +
				xlab("Propensity score") + ggtitle("All Controls")
	}else{
		histPScontrol <- NULL
	}

	## hist matched
	if (length(casePSvalue[matchedCases]) > 0){
		histPScaseMatched <- ggplot(data = data.frame(casePS = c(casePSvalue[matchedCases])), aes(x = casePS)) +
				geom_histogram(color="black", fill="white", bins = 30) +
				xlab("Propensity score") + ggtitle("All Matched Cases")
	}else{
		histPScaseMatched <- NULL
	}
	if (length(c(controlPSvalue[matchedControls])) > 0){
		#hist(c(controlPSvalue[matchedControls]), xlab = "Propensity score", main = "All matched controls")
		histPScontrolMatched <- ggplot(data = data.frame(controlPS = c(controlPSvalue[matchedControls])), aes(x = controlPS)) +
				geom_histogram(color="black", fill="white", bins = 30) +
				xlab("Propensity score") + ggtitle("All Matched Controls")
	}else{
		histPScontrolMatched <- NULL
	}
	grid.arrange(histPScase, histPScontrol, histPScaseMatched, histPScontrolMatched, nrow = 2)

	return(list(one2manyResults = one2manyResults, one2oneResutls = one2oneResutls,
					one2oneResultsID = one2oneResultsID,
					logRegFit = distLogFit,
					histPScase = histPScase,
					histPScontrol = histPScontrol,
					histPScaseMatched = histPScaseMatched,
					histPScontrolMatched = histPScontrolMatched,
					previousCollector = previousCollector))
}
