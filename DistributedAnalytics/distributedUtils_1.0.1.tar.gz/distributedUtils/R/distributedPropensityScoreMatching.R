# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' function
#' @param config a list with these components: "studyId", "centerIds", "messageBrokerAddress", 
#' "dataPath", here is an example:
#' dataPath <- c(system.file('extdata', 'dataLogReg1.csv', package = 'distributedUtils'),
#' 		system.file('extdata', 'dataLogReg2.csv', package = 'distributedUtils'))
#' config <- list(
#' 		studyId = "study1",
#' 		centerIds = paste0('center', 1:2),
#' 		messageBrokerAddress = messageBrokerAddress,
#' 		dataPath = dataPath
#' )
#' @param modelFormula model formula.
#' @param isFactor a vector of ones and zeros with the same length as the number of covariates in the model. 
#' 1 would show its corresponding covariate is a factor, and 0 would show otherwise. 
#' @param epsilon convergence tolorence (positive and small). Note that the same epsilon
#' will be used to see if the predicted probabilities are close to 0 or 1 (quai-complete separation). Also
#' whenever there is a need to take care of the rounding error, the same epsilon is used as the tolerance.
#' @param maxit maximum number of iterations of the Newton-Raphson algorithm
#' @param includeSiteEffect logical variable with default TRUE, indicating whether site effect should be 
#' included in the model or not.
#' @param matchingCaliper logical variable indicating whether a caliper shpould be used for matching or not.
#' @param caliperValue if matchingCaliper = TRUE and caliperValue = NULL, then we use 0.25 * standard deviation of 
#' propensity score as caliper, otherwise, the specified value in caliperValue will be used.
#' @return a list with mathcing result, convergence reason, and previous collector, as well as fitted logistic 
#' regression model.
#' 
#' @author Vahid Nassiri
#' @export
distributedPropensityScoreMatching <- function(config, modelFormula, isFactor, epsilon = 1e-8, maxit = 25, 
		includeSiteEffect = TRUE, matchingCaliper = TRUE, caliperValue = NULL){
	session <- initDistributedSession(config = config)  
	on.exit(closeDistributedSession(session))
	previousCollector <- NULL
	## removePreviousMatched = TRUE will remove all matched files previously, if it is FALSE, it will add the time
	## and date to the end of the file name and keep it there at each site.
	numSites <- length(session$dataPath)
	## checks
	if (numSites < 1 | floor(numSites)!= numSites){
		stop("numSites should be and integer larger than or equal to 1.")
	}
	if (length(isFactor) != (length(all.vars(as.formula(modelFormula)))-1)){
		stop("length of isFactor should be equal to the number of covariates.")
	}
	## The first step is to fit a logistic regression to obtain propensity scores themselves.
	distLogFit <- distributedLogisticRegression (config = config, modelFormula = modelFormula, 
			isFactor = isFactor, epsilon = epsilon, maxit = maxit, 
			includeSiteEffect = includeSiteEffect)
	previousCollector <- NULL
	## After fitting the logistic regression, the propensity scores of each site are stored as 
	## csv files there, here we define the path to the propensity scores.
	pathPS <- c()
	for (iSite in 1:numSites){
		pathPS[iSite] <- paste(dirname(dataPath[[iSite]]), "/propensityScores", iSite, ".csv", sep ="")
	}
	## Now we define the caliper, if it is TRUE then we use  Rosenbaum and Rubin (1985) suggestion,
	## as 1/4 sigma(PS). Otherwise, we use the range of propensity scores are caliper. This way the matching
	## will be continued to the end.
	if (matchingCaliper & is.null(caliperValue)){
		sessionCaliper <- session
		sessionCaliper$dataPath <- pathPS
		varPS <- distributedVariance(sessionCaliper, variableName = "propensityScore")
		previousCollector <- NULL
		session <- initDistributedSession(config = config)  
		caliperValue <- sqrt(varPS$res)/4
		#previousCollector <- varPS$previousCollector
	}
#	sessionCaliper <- session
#	sessionCaliper$dataPath <- pathPS
#	if (matchingCaliper){
#		varPS <- distributedVariance(sessionCaliper, variableName = "propensityScore",
#				previousCollector = previousCollector)
#		caliperPS <- sqrt(varPS$res)/4
#		previousCollector <- varPS$previousCollector
#		
#	}else{
#		rangePS <- distributedRange(sessionCaliper, variableName = "propensityScore",
#				previousCollector = previousCollector)
#		caliperPS <- rangePS$res[3]
#		previousCollector <- rangePS$previousCollector
#	}
	## As the matched propensity scores are stored, we first check if they exist in each site, and if so, we may remove them.
	## Unless the usetr specifie removePreviousMatched = FALSE, then we rename them by adding the current time and date 
	## to the end of their name.
	sessionReadPS <- session
	sessionReadPS$dataPath <- pathPS
	
	RFunction 			<- "computeReadCaseControlPS"
	collectFunction <- "collectReadCaseControlPS"
	
	# Call collectors
	caseControlPScollector <- collector(session = sessionReadPS, RFunction = RFunction, 
			collectFunction = collectFunction, previousCollector = previousCollector,
			sendSiteID = FALSE)
	previousCollector <- caseControlPScollector
	
	## make a suitable output from the collector
	iSite <- 1
	## Here we have values: the propensity scores themselves
	## siteIndicators: indicating which site we are dealing with,
	## and id, which shows an id created to refer to cases and contreols in each site
	casePSvalue <- unlist(caseControlPScollector$res[[1]][[iSite]])
	casePSsiteIndicator <- rep(iSite, length(unlist(caseControlPScollector$res[[1]][[iSite]])))
	casePSid <- seq_along(unlist(caseControlPScollector$res[[1]][[iSite]]))
	controlPSvalue <- unlist(caseControlPScollector$res[[2]][[iSite]])
	controlPSsiteIndicator <- rep(iSite, length(unlist(caseControlPScollector$res[[2]][[iSite]])))
	controlPSid <- seq_along(unlist(caseControlPScollector$res[[2]][[iSite]]))
	if (numSites > 1){
		for (iSite in 2:numSites){
			casePSvalue <- c(casePSvalue, unlist(caseControlPScollector$res[[1]][[iSite]]))
			casePSsiteIndicator <- c(casePSsiteIndicator, rep(iSite, length(unlist(caseControlPScollector$res[[1]][[iSite]]))))
			casePSid <- c(casePSid, seq_along(unlist(caseControlPScollector$res[[1]][[iSite]])))
			controlPSvalue <- c(controlPSvalue, unlist(caseControlPScollector$res[[2]][[iSite]]))
			controlPSsiteIndicator <- c(controlPSsiteIndicator, rep(iSite, length(unlist(caseControlPScollector$res[[2]][[iSite]]))))
			controlPSid <- c(controlPSid, seq_along(unlist(caseControlPScollector$res[[2]][[iSite]])))
		}
	}
	## Now that we have PS's from all sites separately for cases and controls,
	## we can begin to match them. We may return both one-to-one, and one-to-many
	diffAll <- abs(t(t(matrix(rep(casePSvalue, length(controlPSvalue)), length(casePSvalue), length(controlPSvalue))) - controlPSvalue))
	allCaseNames <- paste("case",casePSid, "center", casePSsiteIndicator, sep = "")
	allControlNames <- paste("control",controlPSid, "center", controlPSsiteIndicator, sep = "")
#orderedDiff <- apply(diffAll, 1, order)
	matchingRes <- matchingResAll <- diffAllordered <- matrix(NA, nrow(diffAll), ncol(diffAll))
	for (iCase in 1:length(casePSvalue)){
		tmpOrder <- order(diffAll[iCase,])
		subIDX <- which(diffAll[iCase, tmpOrder] < caliperValue)
		if (length(subIDX) > 0){
			matchingRes[iCase,1:length(subIDX)] <- allControlNames[tmpOrder][subIDX]
		}
		diffAllordered[iCase,] <- diffAll[iCase,tmpOrder]
		matchingResAll[iCase,] <- allControlNames[tmpOrder]
	}
	
	if (matchingCaliper){
		matchingResAll[diffAllordered >= caliperValue] <- NA
	}
	diffAllorderedChar <- matrix(NA, nrow(diffAllordered), ncol(diffAllordered))
	for (iRow in 1:nrow(diffAllordered)){
		for (iCol in 1:ncol(diffAllordered)){
			diffAllorderedChar[iRow, iCol] <- paste("(",round(diffAllordered[iRow,iCol], 3), ")", sep = "")
		}
	}
	
	rownames(diffAll) <- rownames(diffAllordered) <- rownames(matchingResAll) <- rownames(matchingRes) <- rownames(diffAllorderedChar) <- allCaseNames
	
	one2manyResults <- list(matchingResults = matchingResAll, absoluteDifference = diffAllordered)
	
	## Now imagine we want to match one to one, but overally optimal
	diffAllNew <- diffAll
	## If caliper true:
	if (matchingCaliper){
		diffAllNew[diffAllNew >= caliperValue] <- NA
	}
	
	matchingResults1to1 <- matrix(NA, length(allCaseNames), 2)
#for (iCase in 1:length(casePS)){
#	minLoc <- which(diffAllNew == min(diffAllNew, na.rm = TRUE), arr.ind = TRUE)
#	print(paste(allCaseNames[minLoc[1]], "is matched to", allControlNames[minLoc[2]]))
#	matchingResults1to1 [iCase, ] <- c(allCaseNames[minLoc[1]], allControlNames[minLoc[2]])
#	diffAllNew[minLoc[1],] <- diffAllNew[, minLoc[2]] <- NA
#}
	if (sum(!is.na(diffAllNew)) > 0 ){
		minLoc <- which(diffAllNew == min(diffAllNew, na.rm = TRUE), arr.ind = TRUE)
#		print(paste(allCaseNames[minLoc[1]], "is matched to", allControlNames[minLoc[2]], 
#						"with propensity scores absolute difference", round(min(diffAllNew, na.rm = TRUE), 3)))
		diffPS <- min(diffAllNew, na.rm = TRUE)
		matchingResults1to1 <- c(allCaseNames[minLoc[1]], allControlNames[minLoc[2]])
		diffAllNew[minLoc[1],] <- diffAllNew[, minLoc[2]] <- NA
		while (sum(!is.na(diffAllNew)) > 0 ){
			minLoc <- which(diffAllNew == min(diffAllNew, na.rm = TRUE), arr.ind = TRUE)
			diffPS <- c(diffPS, min(diffAllNew, na.rm = TRUE))
#			print(paste(allCaseNames[minLoc[1]], "is matched to", allControlNames[minLoc[2]], 
#							"with propensity scores absolute difference", round(min(diffAllNew, na.rm = TRUE), 3)))
			matchingResults1to1 <- rbind(matchingResults1to1, 
					c(allCaseNames[minLoc[1]], allControlNames[minLoc[2]]))
			diffAllNew[minLoc[1],] <- diffAllNew[, minLoc[2]] <- NA
		}
		rownames(matchingResults1to1) <- NULL
	}else{
		cat("There is no propensity score smaller than the caliper to match! \n")
	}
	one2oneResutls <- data.frame(case = matchingResults1to1[,1], 
			control = matchingResults1to1[,2], diffPS = diffPS)
	
	
	
#	RFunction 			<- "computeMatchedExistence"
#	collectFunction <- "collectMatchedExistence"
#	
#	# Call collectors
#	matchedExistenceVarCollector <- collector(session = sessionCheckExistence, RFunction = RFunction, 
#			collectFunction = collectFunction, previousCollector = previousCollector, 
#			MoreArgs = list(removePreviousMatched = removePreviousMatched),
#			sendSiteID = TRUE)
#	previousCollector <- matchedExistenceVarCollector
#	for (iSite in 1:numSites){
#		if ((unlist(matchedExistenceVarCollector$res)[iSite]) != "No action is taken!"){
#			cat(unlist(matchedExistenceVarCollector$res)[iSite], "\n")
#		}
#	}
#	## Now we begin matching, first one to one matching: every treated patient is
#	## matched to one un-treated one. We then extend it to one to many.
#	matchID <- 0
#	sitesToMatchIDX <- 1:numSites
#	pathPStoMatchIDX <- 1:numSites
#	repeat{
#		matchID <- matchID + 1
#	
#		sitesToMatch <- (1:numSites)[!is.na(sitesToMatchIDX)]
#		pathPStoMatch <- (1:numSites)[!is.na(pathPStoMatchIDX)]
#		## Step 1: select a hospital at random
#		## Apparently, when single scalar is given as the first
#		## argument of sample, it takes the sample from the set of
#		## all integers from 1 to that number, to avoid this, I 
#		## use the following conditon.
#		if (length(sitesToMatch) > 1){
#			selectedSite <- sample(sitesToMatch, 1)
#		}else{
#			selectedSite <- sitesToMatch
#		}
#		
#		## Step 2: ask the selected hospital to send a random
#		## propensity score from a treated person
#		RFunction 			<- "computeReturnCasePS"
#		collectFunction <- "collectReturnCasePS"
#		
#		# Call collectors
#	sessionReturnPS <- session
#	sessionReturnPS$dataPath <- pathPS
#	returnedPSCollector <- collector(session = sessionReturnPS, RFunction = RFunction, 
#			collectFunction = collectFunction, previousCollector = previousCollector, 
#			MoreArgs = list(matchID = matchID),
#			subsetCenter = c(selectedSite),
#			sendSiteID = TRUE)
#	previousCollector <- returnedPSCollector
#		returnedPS <- unname(unlist(returnedPSCollector$res))
#		## Step3: send the selected propensity socre to all hospital and 
#		## ask for absolute difference with all control subjects
#		RFunction 			<- "computeDiffPS"
#		collectFunction <- "collectDiffPS"
#		
#		# Call collectors
#		sessionDiffPS <- session
#		sessionDiffPS$dataPath <- pathPS
#		diffPSCollector <- collector(session = sessionDiffPS, RFunction = RFunction, 
#				collectFunction = collectFunction, previousCollector = previousCollector, 
#				MoreArgs = list(returnedPS = returnedPS),
#				subsetCenter = pathPStoMatch,
#				sendSiteID = TRUE)
#		previousCollector <- diffPSCollector
#		## make an appropriate diffPS!
#		diffPS <- list()
#		for (iDiff in seq_along(diffPSCollector$res$diffPS)){
#			diffPS[[iDiff]] <- unlist(diffPSCollector$res$diffPS[[iDiff]])
#		}
#		toConsiderIDX <- which(unlist(lapply(diffPS, is.null)) == FALSE)
#		## Step 4: Now first we need to find in which site the minimum happend, 
#		## also its value
#		minDiff <- unlist(lapply(diffPS[toConsiderIDX], min))
#		minSite <- which(abs(minDiff- min(minDiff)) < epsilon)
#		## If more than one site share the minimum value, we select one of them at random.
#		if (length(minSite) == 1){
#			overallMinDiff <- c(toConsiderIDX[minSite],min(minDiff))
#		}else if (length(minSite) > 1){
#			minSite <- sample(minSite, 1)
#			overallMinDiff <- c(toConsiderIDX[minSite],min(minDiff))
#		}else{
#			stop("The minimum propensity score difference cannot be identified among different sites.")
#		}
#		## Now the site which has the subject with minimum difference
#		## should recieve the value of difference, to see which subject
#		## it belongs to, then match it with the matchID.
#		# Call collectors
#		RFunction 			<- "computeUpdateMatch"
#		collectFunction <- NULL
#
#		sessionUpdateMatch <- session
#		sessionUpdateMatch$dataPath <- pathPS
#		updateMatchCollector <- collector(session = sessionUpdateMatch, RFunction = RFunction, 
#				collectFunction = collectFunction, previousCollector = previousCollector, 
#				MoreArgs = list(minValue = overallMinDiff[2], 
#						matchID = matchID, 
#						returnedPS = returnedPS, 
#						epsilon = epsilon),
#				subsetCenter = overallMinDiff[1],
#				sendSiteID = TRUE)
#		previousCollector <- updateMatchCollector
#		## Other than existance of no difference smaller than caliper,
#		## there are two other situations that we need to stop the 
#		## matching iterations: 1- when there are no case to match, or
#		## 2- when there are no control to be matched. So we put a 
#		## function here that at the end of each iteration will check
#		## the number of un-matched cases and control, and once there is nothing is a site,
#		## it should excluded.
#		RFunction 			<- "computeCheckMatched"
#		collectFunction <- "collectCheckMatched"
#		sessionCheckMatched <- session
#		sessionCheckMatched$dataPath <- pathPS
#		checkMatchCollector <- collector(session = sessionCheckMatched, RFunction = RFunction, 
#				collectFunction = collectFunction, previousCollector = previousCollector,
#				sendSiteID = TRUE)
#		previousCollector <- checkMatchCollector
#		## make it appropriate!
#		numUnmatched <- matrix(NA, length(pathPS), 2)
#		for (iSite in 1:numSites){
#			numUnmatched[iSite,] <- unlist(checkMatchCollector$res$numUnmatched[[iSite]])
#		}
#		colnames(numUnmatched) <- c("case", "control")
#		## now check
#		if (sum(numUnmatched[,1] == 0)>0){
#			sitesToMatchIDX[which(numUnmatched[,1] == 0)] <- NA
#		}
#		if (sum(numUnmatched[,2]==0)>0){
#			pathPStoMatchIDX[which(numUnmatched[,2] == 0)] <- NA
#		}
##			sitesToMatch
##			pathPStoMatch
##			numUnmatched
#		## Stopping rules
#		if (sum(numUnmatched[,1]==0) == numSites) {
#			stoppingReasonMatching <- "No site remained with a case to match."
#			break
#		}
#		if (sum(numUnmatched[,2]==0) == numSites) {
#			stoppingReasonMatching <- "No site remained with a control to be matched."
#			break
#		}
#		if (overallMinDiff[2] >= caliperPS) {
#			stoppingReasonMatching <- "Smallest difference becomes larger than caliper."
#			break
#		}
#	}
#	RFunction 			<- "computeFinalMatchingResults"
#	collectFunction <- "collectFinalMatchingResults"
#	sessionFinalMatchingResults <- session
#	sessionFinalMatchingResults$dataPath <- pathPS
#	finalMatchingResultsCollector <- collector(session = sessionFinalMatchingResults, RFunction = RFunction, 
#			collectFunction = collectFunction, previousCollector = previousCollector,
#			sendSiteID = TRUE)
#	previousCollector <- finalMatchingResultsCollector
#	## making outcomes nice for computation
#	matchedOnes <- list()
#	namesResp <- rep(NA, length(pathPS))
#	for (iSite in 1:numSites){
#		matchedOnes[[iSite]] <- unlist(finalMatchingResultsCollector$res$matchedOnes[[iSite]])
#		isNULL <- unlist(lapply(finalMatchingResultsCollector$res$matchedOnes[[iSite]], is.null))
#		matchedOnes[[iSite]][isNULL] <- NA
#		namesResp[iSite] <- unlist(finalMatchingResultsCollector$res$namesResp)[iSite]
#	}
#	## making final matching results
#	names(matchedOnes) <- namesResp
#	allSitesMatches <- cbind(reshape2::melt(matchedOnes),
#			unlist(lapply(lapply(matchedOnes, length), 
#							FUN = function(x) 1:x)))
#	colnames(allSitesMatches) <- c("match","site","obs")
#	rownames(allSitesMatches) <- NULL
	return(list(one2manyResults = one2manyResults, one2oneResutls = one2oneResutls, 
					logRegFit = distLogFit, previousCollector = previousCollector))
}