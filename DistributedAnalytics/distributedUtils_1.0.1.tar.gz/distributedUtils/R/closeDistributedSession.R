

#' Simple function to stop 
#' @param session list as created by \link{initDistributedSession}
#' @seealso \link{initDistributedSession}
#' @importFrom artemis deleteQueue
#' @export
closeDistributedSession <- function(session) {
	return(invisible(session))
}
