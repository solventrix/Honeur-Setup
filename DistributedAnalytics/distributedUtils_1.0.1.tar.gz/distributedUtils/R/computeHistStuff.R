# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' Function to compute a frequency table within each center
#' @param dataPath path to data file
#' @param variableName string indicating the variable of interest
#' @param groupingVariable string indicating variable that  defines groups. It could be a binary variable, for example
#' @param breakSeq the breaking points to make the histogram
#' for comparing treated/non-treated in case of propensity score matching.
#' @return frequency table
#' 
#' @author Vahid Nassiri
#' @export
computeHistStuff <- function(dataPath, variableName, groupingVariable, breakSeq){
	data <- read.csv(dataPath, header = TRUE)
	if (!is.null(groupingVariable)){
		uniqVals <- unique(data[, groupingVariable])
		toReturn <- list()
		iCount <- 0
		for (iVar in uniqVals){
			iCount <- iCount + 1
			idx <- which(data[, groupingVariable] == iVar)
			toReturn[[iCount]] <- cut(data[idx, variableName], breaks = breakSeq)
		}
		names(toReturn) <- uniqVals
		
	}else{
		toReturn <- cut(data[, variableName], breaks = breakSeq)
	}
	
	return(toReturn)
	
}