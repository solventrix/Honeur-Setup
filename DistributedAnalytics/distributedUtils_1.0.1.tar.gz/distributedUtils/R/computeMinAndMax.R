# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' Function that computes the minimum and maximum of a given variable
#' @param dataPath path to data file
#' @param variableName string indicating the variable of interest
#' @param groupingVariable string indicating variable that  defines groups. It could be a binary variable, for example
#' for comparing treated/non-treated in case of propensity score matching.
#' @return list containing the minimum and the maximum
#' @importFrom utils read.table 
#' @export
computeMinAndMax <- function(dataPath, variableName, groupingVariable){

	data <- read.csv(dataPath, header = TRUE)


	if (!is.null(groupingVariable)){
		## Obtain names of groupinf var
		groupNames <- sort(unique(data[,groupingVariable]))
		data[,groupingVariable] <- factor(data[,groupingVariable], levels = groupNames)
		##
		uniqVals <- sort(unique(data[, groupingVariable]))
		estMin <- estMax <- rep(NA, length(uniqVals))
		iCount <- 0
		for (iVar in uniqVals){
			iCount <- iCount + 1
			idx <- which(data[, groupingVariable] == iVar)
			estMin[iCount] <- min(data[idx, variableName], na.rm = TRUE)
			estMax[iCount] <- max(data[idx, variableName], na.rm = TRUE)
		}
		names(estMin) <- names(estMax) <- uniqVals
	}else{
		estMin <- min(data[, variableName], na.rm = TRUE)
		estMax <- max(data[, variableName], na.rm = TRUE)
		groupNames <- NULL
	}

	list(estMin = estMin, estMax = estMax, groupNames = groupNames)

}

