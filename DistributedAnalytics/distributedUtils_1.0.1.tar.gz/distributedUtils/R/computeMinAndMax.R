# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' Function that computes the minimum and maximum of a given variable
#' @param dataPath path to data file
#' @param variableName string indicating the variable of interest
#' @return list containing the minimum and the maximum
#' @importFrom utils read.table 
#' @export
computeMinAndMax <- function(dataPath, variableName){
	
	data <- read.csv(dataPath, header = TRUE)
	
	estMin <- min(data[, variableName], na.rm = TRUE)
	estMax <- max(data[, variableName], na.rm = TRUE)
	
	list(estMin = estMin, estMax = estMax)
	
}

