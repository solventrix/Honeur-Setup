# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' Function that make a bar plot (or histrogram) for a given variable in a distributed way.
#' @param config a list with these components: "studyId", "centerIds", "messageBrokerAddress", 
#' "dataPath", here is an example:
#' dataPath <- c(system.file('extdata', 'dataLogReg1.csv', package = 'distributedUtils'),
#' 		system.file('extdata', 'dataLogReg2.csv', package = 'distributedUtils'))
#' config <- list(
#' 		studyId = "study1",
#' 		centerIds = paste0('center', 1:2),
#' 		messageBrokerAddress = messageBrokerAddress,
#' 		dataPath = dataPath
#' )
#' @param variableName  string indicating the variable for which the average will be calculated
#' @param groupingVariable string indicating variable that  defines groups. It could be a binary variable, for example
#' for comparing treated/non-treated in case of propensity score matching.
#' @param numBins in case isFactor = FALSE, this will be the numbr of bins in the histogram, default is 30
#' @param onlyMatchedSubjects if TRUE, will only use the matched subjects
#' @return a ggplot object.
#' 
#' @import ggplot2
#' @import reshape2
#' @author Vahid Nassiri
#' @export
distributedHistogram <- function(config, variableName, groupingVariable = NULL, numBins = 30, onlyMatchedSubjects = FALSE){
	session <- initDistributedSession(config = config)  
	on.exit(closeDistributedSession(session))
	previousCollector <- NULL
	## Subsetting data
	if (onlyMatchedSubjects){
		RFunction 			<- "computeDataSubsetting"
		collectFunction <- "collectDataSubsetting"
		
		# Call collectors
		dataSubsettingCollector <- collector(session = session, RFunction = RFunction, 
				collectFunction = collectFunction, previousCollector = previousCollector, 
				MoreArgs = NULL, sendSiteID = TRUE)
		config$dataPath <- unlist(dataSubsettingCollector$res)
		closeDistributedSession(session)
		session <- initDistributedSession(config = config)  
	}
	
	## if isFactor is false, then we should ask each hospital to give a 
	## frequency table of a discritized version, just this discritized
	## things should be the same in various hospitals, so we need perhaps
	## the min and max per hospital to find overal min and max and then divide the 
	## in between into say 10 pieces.
	
	
		## Find overal min and max to define cut-points
		## note that, groupingVariable = NULL since for all its levels we want the same range of histograms
		## for the sake of a better comparison
		overalRange0 <- distributedRange(config = config, variableName = variableName, groupingVariable = NULL)
		breakSeq <- seq(overalRange0$res[1]-(overalRange0$res[1]/100), overalRange0$res[2] + (overalRange0$res[2]/100), ,numBins)
		## ask for a frequency table per center
		RFunction 			<- "computeHistStuff"
		collectFunction <- "collectHistStuff"
		
		# Call collectors
		histCollector <- collector(session = session, RFunction = RFunction, 
				collectFunction = collectFunction, previousCollector = previousCollector, 
				MoreArgs = list(variableName = variableName, groupingVariable = groupingVariable, breakSeq = breakSeq))
		
		if (is.null(groupingVariable)){
#			barplot(table(as.factor(unlist(lapply(histCollector$res, unlist)))), space = rep(0, numBins -1), xaxt='n',
#					ylab = "Frequency", xlab = variableName)
#			axis(side = 1, at= 0:(numBins-1), labels= as.character(round(breakSeq)))
			allTabs <- table(as.factor(unlist(lapply(histCollector$res, unlist))))
			data2plot <- data.frame(allTabs)
			names(data2plot) <- c("value", "Frequency")
			data2plot$value <- as.numeric(data2plot$value)
			plot2return <- ggplot(data2plot, aes(x = value, y = Frequency)) +
					geom_bar(stat = "identity", color = "black", fill = "grey", width=1) +
					ggtitle(variableName) +
					scale_x_continuous(breaks=seq(min(data2plot$value), max(data2plot$value),,5),
							labels = seq(overalRange0$res[1], overalRange0$res[2],,5))
		}else{
			## find all levels of the grouping variable
			uniqLev1 <- unique(unlist(lapply(histCollector$res, names)))
			count1 <- 0
			tab2plot <- list()
			for (iLev1 in uniqLev1){
				tmpTab <- list()
				count1 <- count1 + 1
				for (iCenter in 1:length(config$dataPath)){
					tmpTab[[iCenter]] <- histCollector$res[[iCenter]][which(names(histCollector$res[[iCenter]]) == iLev1)][[1]]
				}
				## Now make a table for this level just like no grouping variable case
				tab2plot[[count1]] <- table(as.factor(unlist(lapply(tmpTab, unlist))))
			}
			## Now the issue is, not all intervals are available in all levels of the 
			## grouping variable, so we make a large pool of available levels
			## and see for which we have a counterpart for each level of the 
			## grouping variable. If we don't have any, we replace with with NA
			poolLevels <- unique(names(unlist(tab2plot)))
			#par(mfrow= c(ceiling(length(tab2plot)/2),2))
			tab2plotAll <- list()
			## Now we go over all of them and fill in the new table
			for (iTab in 1:length(tab2plot)){
				tab2plotNew <- rep(NA, length(poolLevels))
				names(tab2plotNew) <- poolLevels
				for (iLevel in 1:length(poolLevels)){
					idxSel <- which(names(tab2plot[[iTab]]) == poolLevels[iLevel])
					if (length(idxSel) > 0){
						tab2plotNew[iLevel] <- tab2plot[[iTab]][idxSel]
					}
				}
				tab2plotAll[[iTab]] <- tab2plotNew
#				barplot(tab2plotNew, space = c(0,0), xaxt='n',
#						ylab = "Frequency", xlab = variableName, main = uniqLev1[iTab])
#				axis(side = 1, at= 0:(numBins-1), labels= as.character(round(breakSeq)))
			}
			data2plot <- melt(do.call("cbind", tab2plotAll))
			names(data2plot) <- c("value", "Group", "Frequency")
			data2plot$value <- as.numeric(data2plot$value)
			plot2return <- ggplot(data2plot, aes(x = value, y = Frequency)) +
					geom_bar(stat = "identity", color = "black", fill = "grey", width=1) +
					ggtitle(variableName) +
					scale_x_continuous(breaks=seq(min(data2plot$value), max(data2plot$value),,5),
							labels = seq(overalRange0$res[1], overalRange0$res[2],,5))+
					facet_wrap(~Group)

		}
		return(plot2return)
}

