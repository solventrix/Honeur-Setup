#' Function to poll for messages
#' @param brokerAddress string indicating the message broker address
#' @param queue string indicating the name of the queue
#' @param time.sleep time in seconds that the function will wait until the next try if fails
#' @param verbose should verbose output be generated? logical with default value \code{FALSE}
#' @param msgConsumeNextURL httr:response() object of previous message consumed (NULL if first message)
#' @return list containing a string for the reply queue name and a second string containing the calculation in json format
#' @importFrom httr content
#' @importFrom artemis consumeMessage
#' @export
pollForMessages <- function(brokerAddress, queue, time.sleep = 2, verbose = FALSE, msgConsumeNextURL = NULL){
  
  # Consume messages from requestQueue 
  
  cat('[Center] Waiting for messages...\n')
    
    msg <- consumeMessage(brokerAddress = brokerAddress, msgConsumeNextURL = msgConsumeNextURL, 
            queue = queue, verbose = verbose)
    
    if (msg$status_code == 200){      
      msg_content <- content(msg)
      
      res <- runRFunction(RJSONIO::toJSON(msg_content))
      cat('Calculation done\n\n', sep = '')

    }

  
  list(replyQueue = msg_content$replyQueue, msg = RJSONIO::toJSON(res), msgConsumeNextURL = msg)
  
}
