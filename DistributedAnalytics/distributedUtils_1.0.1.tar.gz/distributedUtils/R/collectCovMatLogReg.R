# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' Combined results obtained by \link{collector} 
#' @param replyMessages list of named lists returned by the RFunction \link{computeCovMatLogReg}
#' @return data frame containing the contribution of each site to the covariance matrix
#' @export
collectCovMatLogReg <- function(replyMessages){
	
	resCombined <- lapply(replyMessages, function(x) {
				list(covMat = x$covMat, separation = x$separation)
			})
	
	as.data.frame(do.call('rbind', resCombined))
}


