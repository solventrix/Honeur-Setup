# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' Find the subset of data that are matched via propensity score matching
#' @param dataPath a list with the same length as the number of sites, each
#' element of the list is the address of the data on the hard disk in the corresponding site.
#' @param siteNum ID of the corresponding site
#' @return subset of the original data
#' 
#' @author Vahid Nassiri
#' @export
computeDataSubsetting <- function(dataPath, siteNum){
	if (!file.exists(paste(dirname(dataPath), "/matchedCases", siteNum, ".csv", sep =""))){
		stop(paste("No list of matched cases is found in site, ", siteNum))
	}
	if (!file.exists(paste(dirname(dataPath), "/matchedControls", siteNum, ".csv", sep =""))){
		stop(paste("No list of matched controls is found in site, ", siteNum))
	}
	casePSidx <-  read.csv(paste(dirname(dataPath), "/matchedCases", siteNum, ".csv", sep =""))
	controlPSidx <- read.csv(paste(dirname(dataPath), "/matchedControls", siteNum, ".csv", sep =""))
	dataAll <- read.csv(dataPath, header = TRUE)
	## Note that, we assume 1 indicates cases and 0 indicates controls.
	## let's check that
	groupingVariable0 <- read.csv(paste(dirname(dataPath), "/respName.csv", sep =""))
	groupingVariable <- as.character(groupingVariable0$x)
	if (sum(unique(dataAll[,groupingVariable])%in%c(0,1)) != length(unique(dataAll[,groupingVariable]))){
		stop(paste("The current grouping variable has the levels ", paste(unique(dataAll[,groupingVariable]), collapse = ","), ". They should be 0 for controls and 1 for cases.", sep = ""))
	}
	idxControls <- which(dataAll[,groupingVariable] == 0)[controlPSidx$x]
	idxCases <-  which(dataAll[,groupingVariable] == 1)[casePSidx$x]
	data <- dataAll[sort(c(idxCases, idxControls)), ]
	## Now we write the new data to the local site
	write.csv(data, file = paste(dirname(dataPath), "/dataSubset", siteNum, ".csv", sep =""),
			row.names = FALSE)
	
	return(paste(dirname(dataPath), "/dataSubset", siteNum, ".csv", sep =""))
	## For each function that could possibly deal with subset of matched data, which is 
	## practically all of the functions I guess, we need to add an extra argument called onlyMatchedSubjects = FALSE, now if this
	## is TRUE, we should go to everywhere in the compute... function where we read a dataset (if  onlyMatchedSubjects = TRUE), 
	## it should be read via this function, so that also means, we need to set sendSiteID = TRUE in the collector function of them. 
	

}
