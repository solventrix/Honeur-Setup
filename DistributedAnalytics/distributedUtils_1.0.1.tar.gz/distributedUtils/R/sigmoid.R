# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' computes logistic function
#' @param scalar, input of logistic function 
#' @return value of logistic function 
#' 
#' @author Vahid Nassiri
#' @noRd
sigmoid <- function(x){
	1/(1+exp(-x))
}
