# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' reads data from each siteand return needed matrials to fit 
#' the model.
#' @param dataPath path to the location of the data on the site
#' @param formula model formula
#' @param weights see coxph in survival
#' @param subset  see coxph in survival
#' @param na.action  see coxph in survival
#' @param init  see coxph in survival
#' @param control  see coxph in survival
#' @param ties  see coxph in survival
#' @param singular.ok  see coxph in survival
#' @param robust  see coxph in survival
#' @param model  see coxph in survival
#' @param x  see coxph in survival
#' @param y  see coxph in survival
#' @param tt  see coxph in survival
#' @param method  see coxph in survival
#' @param siteNum ID of the current center
#' @return required materials
#' 
#' @author Vahid Nassiri
#' @noRd
collectMaterialsAndReadDataPerSiteCoxph <- function(dataPath, formula, isFactor, weights, subset, na.action,
		init, control, ties,
		singular.ok, robust,
		model, x, y,  tt, method=ties, siteNum){
	formula <- as.formula(formula)
	## this acts at the site level
	data <- readData(dataPath, modelFormula, isFactor)
	materialsCoxph <- computeMaterialsCoxph(formula = formula, data = data, 
			init = init, ties = ties,
			singular.ok = singular.ok, robust = robust,
			model = model, x = x, y = y,  tt = tt, method=ties)
			save(materialsCoxph, file = paste(dirname(dataPath), 
							"/materialsCoxPh", siteNum,".RData", sep =""))
	return(materialsCoxph$p)
}

