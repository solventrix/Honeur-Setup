#' Function to poll for responses for a given distributed request
#' @param distributedAnalyticsApiUrl url of the distributed analytics service
#' @param tokenContext a JWT and the corresponding fingerprint
#' @param requestUuid the UUID of the distributed request
#' @param organization the organization to poll the message for
#' @importFrom httr warning add_headers set_cookies HEAD GET
#' @export
pollResponseMessage <- function(distributedAnalyticsApiUrl, tokenContext, requestUuid, organization) {

    distributedAnalyticsApiUrl <- paste(distributedAnalyticsApiUrl, "distributed-responses", "poll", requestUuid, organization, sep = "/")

    response <- GET(url = distributedAnalyticsApiUrl, add_headers(token = tokenContext$token), set_cookies('userFingerprint' = tokenContext$fingerprint))

    if(http_error(response)) {
        warning(http_status(response)$message)
    }

    return (response)
}


