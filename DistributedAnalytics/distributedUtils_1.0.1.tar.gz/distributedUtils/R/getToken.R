#' Function to get a token for the given username and password
#' @param loginApiUrl the URL of the login API, e.g. https://storage-local.honeur.org/api/login
#' @param username username of the user to create a token for
#' @param password password of the user to create a token for
#' @importFrom httr headers HEAD GET
#' @export
getToken <- function(loginApiUrl, username, password) {

    tokenResponse = GET(loginApiUrl, authenticate(username, password))

    if(http_error(tokenResponse)) {
        warning(http_status(tokenResponse)$message)
    }

    tokenParsed = content(tokenResponse, as="parsed", type="application/json")
    tokenString = paste0("", tokenParsed)

    cookies <- cookies(tokenResponse)
    userfingerprintCookie <- cookies$value

    return (list("token" = tokenString, "fingerprint" = userfingerprintCookie))
}