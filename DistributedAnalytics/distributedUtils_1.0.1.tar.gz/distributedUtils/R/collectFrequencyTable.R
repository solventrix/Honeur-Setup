# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' Combined results obtained by \link{collector} 
#' @param replyMessages list of named lists returned by the RFunction \link{computeFrequencyTable}
#' @return a list with all results
#' @export
collectFrequencyTable <- function(replyMessages){
	
### Note that like in CoxPh we need every level of each factor to happen in every hospital
#	resCombinedFreqTab <- lapply(replyMessages, function(x) {
#				as.data.frame(do.call('rbind', x))
#			})
#	
#	resCombinedSum <- lapply(replyMessages, function(x) {
#				rbind(x)
#			})
#	
#	
#	unlist(lapply(replyMessages, rbind))
#	
#	#as.data.frame(do.call('rbind', resCombined))
#	returnMin <- as.data.frame(do.call('rbind', resCombinedMin))
#	returnMax <- as.data.frame(do.call('rbind', resCombinedMax))
#	freqTabs <- replyMessages
#	varNames <- names(replyMessages)
#	return(list(freqTabs = freqTabs, varNames = varNames))
	return(replyMessages)
}
