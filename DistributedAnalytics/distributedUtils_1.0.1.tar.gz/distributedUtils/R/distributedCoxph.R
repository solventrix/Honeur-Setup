# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################




#' fits Cox proportional hazard model with a distributed approach.
#' @param config a list with these components: "studyId", "centerIds", "messageBrokerAddress", 
#' "dataPath", here is an example:
#' dataPath <- c(system.file('extdata', 'dataLogReg1.csv', package = 'distributedUtils'),
#' 		system.file('extdata', 'dataLogReg2.csv', package = 'distributedUtils'))
#' config <- list(
#' 		studyId = "study1",
#' 		centerIds = paste0('center', 1:2),
#' 		messageBrokerAddress = messageBrokerAddress,
#' 		dataPath = dataPath
#' )
#' @param modelFormula model formula
#' @param isFactor a vector of ones and zeros with the same length as the number of covariates in the model. 
#' 1 would show its corresponding covariate is a factor, and 0 would show otherwise.
#' @param maxit maximum number of iterations of Newton-Raphson algorithm.
#' @param epsilon convergence tolorence (positive and small)
#' @param init vector of initial values of the iteration. Default initial value is zero for all variables, 
#'  see coxph function in R package survival
#' @param ties a character string specifying the method for tie handling, see coxph function in R package survival
#' @param singular.ok logical value indicating how to handle collinearity in the model matrix, 
#' see coxph function in R package survival.
#' @param robust this argument has been deprecated, use a cluster term in the model instead,
#' see coxph function in R package survival.
#' @param tt optional list of time-transform functions.
#' see coxph function in R package survival.
#' @param method alternate name for the ties argument.
#' see coxph function in R package survival.
#' @param onlyMatchedSubjects if TRUE, will only use the matched subjects
#' @return a list withestimated parameter vector, its covariance matrix,
#' and the reason of stopping Newton-Raphson algorithm.
#' @importFrom survival coxph
#' @importFrom stats model.frame pnorm
#' @import distcomp
#' @seealso \href{https://www.rdocumentation.org/packages/survival/versions/2.42-6/topics/coxph}{coxph}
#' @author Vahid Nassiri
#' @export
distributedCoxph <- function(config, modelFormula, isFactor, maxit = 25, epsilon = 1e-09,
		init = NULL, ties= c("efron", "breslow", "exact"),
		singular.ok =TRUE, robust=FALSE,
		tt = NULL, method=ties, onlyMatchedSubjects = FALSE){
	session <- initDistributedSession(config = config)
	on.exit(closeDistributedSession(session))
	previousCollector <- NULL
	## Subsetting data
	if (onlyMatchedSubjects){
		RFunction 			<- "computeDataSubsetting"
		collectFunction <- "collectDataSubsetting"

		# Call collectors
		dataSubsettingCollector <- collector(session = session, RFunction = RFunction,
				collectFunction = collectFunction, previousCollector = previousCollector,
				MoreArgs = NULL, sendSiteID = TRUE)
		config$dataPath <- unlist(dataSubsettingCollector$res)
		closeDistributedSession(session)
		session <- initDistributedSession(config = config)
	}

	## intiials: we don't want to have x or y
	## We omit the missing values
	na.action =options()$na.action
	weights = NULL
	subset = NULL
	model <- FALSE
	control <- survival::coxph.control()
	x <- FALSE
	y <- FALSE
	## checks
	numSites <- length(dataPath)
	if (numSites < 1 | floor(numSites)!= numSites){
		stop("numSites should be and integer larger than or equal to 1.")
	}

	## Here we just want to detect factor and their levels to construct
	## variable names
	RFunction 			<- "computeSiteSizeNumPar"
	collectFunction <- "collectSiteSizeNumParCox"

	# Call collectors
	factorLevelsCollector <- collector(session = session, RFunction = RFunction,
			collectFunction = collectFunction, previousCollector = previousCollector,
			MoreArgs = list(modelFormula = modelFormula,
					isFactor = isFactor, isSurvival = TRUE))
	previousCollector <- factorLevelsCollector

	## creating covariate names
	namesVars <- NULL
	factorLevels <- list()
	levFactorAll <- list()
	# checking if all covariates are exisiting in every site
	for (iSite in 1:numSites){
		factorLevels[[iSite]] <- factorLevelsCollector$res[[1]][[iSite]]
	}
	## Let me check the factor levels already, 
	factorVars <- all.vars(as.formula(modelFormula))[which(isFactor == 1) + 2]
	nFactorLevels <- rep(NA, length(factorVars))
	for (iFactor in seq_along(factorVars)){
		resFactors <- 0
		for (iSite in 1:numSites){
			resFactors <- c(resFactors,
					factorLevels[[iSite]][[which(names(factorLevels[[iSite]]) == factorVars[iFactor])]])
		}
		levFactorAll[[iFactor]] <- unique(resFactors[-1])
		nFactorLevels[iFactor] <- length(levFactorAll[[iFactor]])
		names(levFactorAll)[[iFactor]] <- factorVars[iFactor]
	}
	factorLevels <- list()
	for (iFactor in seq_along(levFactorAll)){
		factorLevels[[iFactor]] <- unlist(levFactorAll[[iFactor]])
	}
	names(factorLevels) <- names(levFactorAll)
	covariateNames0 <- all.vars(as.formula(modelFormula))[-c(1,2, length(all.vars(as.formula(modelFormula))))]
	## This is to know which covariate are factor, so based on their levels 
	## we create correct names (always first one the reference).
	if (isFactor[1] ==1){
		indFactor <- 1
	}else{
					indFactor <- 0
	}
	invisible(ifelse(isFactor[1] == 1, covariateNames <- paste(covariateNames0[1], factorLevels[[1]][-1], sep = ""),
					covariateNames <- covariateNames0[1]))
	if (length(covariateNames0) > 1){
		for (iVar in 2:length(covariateNames0)){
			if (isFactor[iVar] ==1){
				indFactor <- indFactor + 1
			}
			invisible(ifelse(isFactor[iVar] == 1, covariateNames <- c(covariateNames,
									paste(covariateNames0[iVar], factorLevels[[indFactor]][-1], sep = "")),
							covariateNames <- c(covariateNames, covariateNames0[iVar])))
		}
	}



	## This step will only return the number of parameters to know how long
	## should be the parameter vector, but internally, it will compute needed
	## materials for iterations and save them as R objects in the local disk of
	## each site. This will be read in in every iteration.
	RFunction 			<- "computeMaterialsAndReadDataPerSiteCoxph"
	collectFunction <- "collectMaterialsCoxPH"

	# Call collectors
	numParColelctor <- collector(session = session, RFunction = RFunction,
			collectFunction = collectFunction, previousCollector = previousCollector,
			MoreArgs = list(modelFormula = modelFormula,
					isFactor = isFactor,
					weights = weights,
					subset = subset,
					na.action = na.action,
					init = init,
					ties = ties,
					singular.ok = singular.ok,
					robust = robust,
					model = model,
					x = x,
					y = y,
					tt = tt,
					method=ties),
			sendSiteID = TRUE)


	numParAll <- unlist(c(numParColelctor$res))
	## check if the number of parameters in all sites are the same,
	## if they are not we stop, that probably means we have some categorical
	## variables with different levels in different sites.
	if (length(unique(numParAll))> 1){
		stop("The number of parameters is not equal in all centers!")
	}else{
		numPar <- numParAll[1]
	}


#	invisible(ifelse(length(dotParms)>0,
#					materialsCoxph <- collectMaterialsCoxph(modelFormula, dataPath, weights = weights, subset = subset, na.action = na.action,
#							init = init, control = control, ties = ties,
#							singular.ok = singular.ok, robust=robust,
#							model=model, x=x, y=y,  tt = tt, method=ties, dotParms),
#					materialsCoxph <- collectMaterialsCoxph(modelFormula, dataPath, weights = weights, subset = subset, na.action = na.action,
#							init = init, control = control, ties = ties,
#							singular.ok = singular.ok, robust=robust,
#							model=model, x=x, y=y,  tt = tt, method=ties)))
	## begin with beta = 0
	prevBeta <- beta <- rep(0, numPar)
	## Collecting gradient and other optimizing stuff
	RFunction 			<- "computeGradientHessianLikelihoodCoxph"
	collectFunction <- "collectGradientHessianLikelihoodCoxph"

	# Call collectors
	optimStuffColelctor <- collector(session = session, RFunction = RFunction,
			collectFunction = collectFunction, previousCollector = numParColelctor,
			MoreArgs = list(beta = beta),
			sendSiteID = TRUE)


	gradientCoxph0 <- list()
	hessianCoxph0 <- list()
	loglikeCoxph0 <- list()
	for (iSite in 1:numSites){
		gradientCoxph0[[iSite]] <- optimStuffColelctor$res$gradientCoxph[[iSite]]
		hessianCoxph0[[iSite]] <- matrix(optimStuffColelctor$res$hessianCoxph[[iSite]],
				 numPar, numPar)
		loglikeCoxph0[[iSite]] <- optimStuffColelctor$res$logLikCoxph[[iSite]]
	}
	hessianCoxph <- Reduce("+", hessianCoxph0)
	gradientCoxph <- Reduce("+", gradientCoxph0)
	loglikeCoxph <- prevLoglikeCoxph <- Reduce("+", loglikeCoxph0)
	iter <- 0
	repeat {
		## the beta is computed in center and be sent to sites
		beta <- beta - (solve(hessianCoxph) %*% gradientCoxph)
		iter <- iter + 1
		## optimization stuff
		optimStuffColelctor <- collector(session = session, RFunction = RFunction,
				collectFunction = collectFunction, previousCollector = optimStuffColelctor,
				MoreArgs = list(beta = beta),
				sendSiteID = TRUE)
		gradientCoxph0 <- list()
		hessianCoxph0 <- list()
		loglikeCoxph0 <- list()
		for (iSite in 1:numSites){
			gradientCoxph0[[iSite]] <- optimStuffColelctor$res$gradientCoxph[[iSite]]
			hessianCoxph0[[iSite]] <- matrix(optimStuffColelctor$res$hessianCoxph[[iSite]],
					numPar, numPar)
			loglikeCoxph0[[iSite]] <- optimStuffColelctor$res$logLikCoxph[[iSite]]
		}
		hessianCoxph <- Reduce("+", hessianCoxph0)
		gradientCoxph <- Reduce("+", gradientCoxph0)
		loglikeCoxph <- Reduce("+", loglikeCoxph0)
		##
		## New computing with new init which is beta
		## each site use beta as initial value and return gradient, hessian and log-likelihood
#		gradientHessianLikelihoodCoxph <- collectGradientHessianLikelihoodCoxph(dataPath, beta)
#		gradientCoxph <- gradientHessianLikelihoodCoxph$gradientCoxph
#		hessianCoxph <- gradientHessianLikelihoodCoxph$hessianCoxph
#		loglikeCoxph <- gradientHessianLikelihoodCoxph$logLikCoxph
		if (max(abs(loglikeCoxph - prevLoglikeCoxph)) < epsilon) {
			stoppingReason <- paste("The algorithm is converged in ", iter, " iterations.")
			break
		}
		if (iter >= maxit) {
			stoppingReason <- paste("Convergence is not achived.")
			break
		}
		prevBeta <- beta
		prevLoglikeCoxph <- loglikeCoxph
	}
	covMat <- -solve(hessianCoxph)
	rownames(beta) <- rownames(covMat) <- colnames(covMat) <- covariateNames

	zValues <- beta/sqrt(diag(covMat))
	pValues <- 2*pnorm(-abs(zValues))
	summaryTable <- data.frame(beta, exp(beta), sqrt(diag(covMat)), zValues, pValues)
	## colnames obtaiend from survival::coxph output
	colnames(summaryTable) <- c("coef", "exp(coef)", "se(coef)", "z", "Pr(>|z|)" )
	print(round(summaryTable, 5))
	return(list(betaEst = beta, betaCov = covMat, cnovNote = stoppingReason,
					previousCollector = optimStuffColelctor))
}

