# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' Combined results obtained by \link{collector} 
#' @param replyMessages list of named lists returned by the RFunction \link{computeSumAndSampleSize}
#' @return data frame containing the sample size in each site and number of parameters in the model.
#' @export
collectSiteSizeNumPar <- function(replyMessages){
	
	resCombined <- lapply(replyMessages, function(x) {
				list(siteSize = x$siteSize, numPar = x$numPar, factorLevels = x$factorLevels)
			})
	
	as.data.frame(do.call('rbind', resCombined))
}


