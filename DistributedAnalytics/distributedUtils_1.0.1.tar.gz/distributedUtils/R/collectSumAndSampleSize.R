#' Combined results obtained by \link{collector} 
#' @param replyMessages list of named lists returned by the RFunction \link{computeSumAndSampleSize}
#' @return data frame containing the sum and sample size
#' @export
collectSumAndSampleSize <- function(replyMessages){
  
  resCombined <- lapply(replyMessages, function(x) {
        c(sum = x$sum, sampleSize = x$sampleSize)
      })
  
  as.data.frame(do.call('rbind', resCombined))
}

