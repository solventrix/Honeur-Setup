#' Combined results obtained by \link{collector} 
#' @param replyMessages list of named lists returned by the RFunction \link{computeSumAndSampleSize}
#' @return data frame containing the sum and sample size
#' @export
collectSumAndSampleSize <- function(replyMessages){
  
#  resCombined <- lapply(replyMessages, function(x) {
#        c(sum = x$sum, sampleSize = x$sampleSize)
#      })
#
	resCombinedSum <- lapply(replyMessages, function(x) {
				c(sum = x$sum)
			})

	resCombinedSampleSize <- lapply(replyMessages, function(x) {
				c(sampleSize = x$sampleSize)
      })
  
  #as.data.frame(do.call('rbind', resCombined))
	returnSum <- as.data.frame(do.call('rbind', resCombinedSum))
	returnSampleSize <- as.data.frame(do.call('rbind', resCombinedSampleSize))
	return(list(sum = returnSum, sampleSize = returnSampleSize))
}

