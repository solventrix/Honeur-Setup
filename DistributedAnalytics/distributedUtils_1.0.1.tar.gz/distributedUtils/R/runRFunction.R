#' Run R function using arguments specified in jsonBody 
#' @param jsonBody string containing json structure
#' @return string in json format with result of running R function specified in jsonBody 
#' @importFrom jsonlite fromJSON
#' @export
runRFunction <- function(jsonBody){
  
  jsonList <- jsonlite::fromJSON(jsonBody)
  
  try(do.call(jsonList$RFunction, args = jsonList[-c(1,2)]))
  
}
