#' Function to retrieve all details of the distributed analytics request with the given UUID
#' @param distributedAnalyticsApiUrl url of the distributed analytics service
#' @param tokenContext a JWT and the corresponding fingerprint
#' @param requestUuid the UUID of the distributed request to find
#' @importFrom httr warning add_headers set_cookies HEAD GET
#' @export
getDistributedRequestMessage <- function(distributedAnalyticsApiUrl, tokenContext, requestUuid) {

    distributedAnalyticsApiUrl <- paste(distributedAnalyticsApiUrl, "distributed-requests", requestUuid, sep = "/")

    response <- GET(url = distributedAnalyticsApiUrl, add_headers(token = tokenContext$token), set_cookies('userFingerprint' = tokenContext$fingerprint))

    if(http_error(response)) {
        warning(http_status(response)$message)
    }

    return (response)
}