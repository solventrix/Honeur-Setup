# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' Function to compute a frequency table within each center
#' @param dataPath path to data file
#' @param variableName string indicating the variable of interest
#' @param groupingVariable string indicating variable that  defines groups. It could be a binary variable, for example
#' for comparing treated/non-treated in case of propensity score matching.
#' @return frequency table
#' 
#' @author Vahid Nassiri
#' @export
computeFrequencyTable <- function(dataPath, variableName, groupingVariable){
	data <- read.csv(dataPath, header = TRUE)
	if (!is.null(groupingVariable)){
		uniqVals <- sort(unique(data[, variableName]))
		data[,variableName] <- factor(data[,variableName], levels = uniqVals)
		groupNames <- sort(unique(data[,groupingVariable]))
		data[,groupingVariable] <- factor(data[,groupingVariable], levels = groupNames)
		freqTab0 <- list()
		iCount <- 0
		for (iVar in groupNames){
			iCount <- iCount + 1
			idx <- which(data[, groupingVariable] == iVar)
			freqTab0[[iCount]] <- t(matrix(table(data[idx, variableName])))
			colnames(freqTab0[[iCount]]) <- names(table(data[idx, variableName]))
		}
		names(freqTab0) <- groupNames
#		combinedTabs <- do.call("rbind", freqTab0)
#		freqTab <- matrix(unlist(combinedTabs), nrow = length(freqTab0))
#		colnames(freqTab) <- colnames(combinedTabs)
#		rownames(freqTab) <- rownames(combinedTabs)
#		freqTabReturn <- freqTab
		freqTabReturn <- freqTab0
	}else{
		uniqVals <- sort(unique(data[, variableName]))
		data[,variableName] <- factor(data[,variableName], levels = uniqVals)
		freqTab <- table(data[,variableName])
		freqTabReturn <- t(matrix(freqTab))
		colnames(freqTabReturn) <- names(table(data[,variableName]))
		groupNames <- NULL
	}
	return(list(freqTab = freqTabReturn,varNames = uniqVals, groupNames = groupNames))
}
