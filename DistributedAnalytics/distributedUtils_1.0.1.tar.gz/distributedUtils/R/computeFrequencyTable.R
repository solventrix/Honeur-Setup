# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' Function to compute a frequency table within each center
#' @param dataPath path to data file
#' @param variableName string indicating the variable of interest
#' @param groupingVariable string indicating variable that  defines groups. It could be a binary variable, for example
#' for comparing treated/non-treated in case of propensity score matching.
#' @return frequency table
#' 
#' @author Vahid Nassiri
#' @export
computeFrequencyTable <- function(dataPath, variableName, groupingVariable){
	data <- read.csv(dataPath, header = TRUE)
	if (!is.null(groupingVariable)){
		uniqVals <- unique(data[, groupingVariable])
		freqTab0 <- list()
		iCount <- 0
		for (iVar in uniqVals){
			iCount <- iCount + 1
			idx <- which(data[, groupingVariable] == iVar)
			freqTab0[[iCount]] <- c(table(data[idx, variableName]))
		}
		names(freqTab0) <- uniqVals
#		combinedTabs <- do.call("rbind", freqTab0)
#		freqTab <- matrix(unlist(combinedTabs), nrow = length(freqTab0))
#		colnames(freqTab) <- colnames(combinedTabs)
#		rownames(freqTab) <- rownames(combinedTabs)
#		freqTabReturn <- freqTab
		freqTabReturn <- freqTab0
	}else{
		freqTab <- table(data[,variableName])
		freqTabReturn <- c(freqTab)
	}
	
	return(freqTabReturn)
	
}
