#' Combined results obtained by \link{collector} 
#' @param replyMessages list of named lists returned by the RFunction \link{computeSumAndSampleSize}
#' @return data frame containing the sumOfSquares and sample size
#' @export
collectSumOfSquaresAndSampleSize <- function(replyMessages){
  
#  resCombined <- lapply(replyMessages, function(x) {
#        c(sumOfSquares = x$sumOfSquares, sampleSize = x$sampleSize)
#      })

	resCombinedSumOfSquares <- lapply(replyMessages, function(x) {
				c(sum = x$sumOfSquares)
			})

	resCombinedSampleSize <- lapply(replyMessages, function(x) {
				c(sampleSize = x$sampleSize)
			})

	resCombinedgroupNames <- lapply(replyMessages, function(x) {
				c(groupNames = x$groupNames)
			})

  #as.data.frame(do.call('rbind', resCombined))
	returnSumOfSquares <- as.data.frame(do.call('rbind', resCombinedSumOfSquares))
	returnSampleSize <- as.data.frame(do.call('rbind', resCombinedSampleSize))
	returnGroupNames <- unique(unlist(resCombinedgroupNames))

	return(list(sumOfSquares = returnSumOfSquares, sampleSize = returnSampleSize, groupNames = returnGroupNames))
}

