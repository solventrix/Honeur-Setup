#' Combined results obtained by \link{collector} 
#' @param replyMessages list of named lists returned by the RFunction \link{computeSumAndSampleSize}
#' @return data frame containing the sumOfSquares and sample size
#' @export
collectSumOfSquaresAndSampleSize <- function(replyMessages){
  
  resCombined <- lapply(replyMessages, function(x) {
        c(sumOfSquares = x$sumOfSquares, sampleSize = x$sampleSize)
      })
  
  as.data.frame(do.call('rbind', resCombined))
}

