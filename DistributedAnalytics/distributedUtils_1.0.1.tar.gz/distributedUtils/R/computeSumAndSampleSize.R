#' Function that computes sum and sample size of a given variable
#' @param dataPath path to data file
#' @param variableName string indicating the variable of interest
#' @param groupingVariable string indicating variable that  defines groups. It could be a binary variable, for example
#' for comparing treated/non-treated in case of propensity score matching.
#' @return list containing the sum and the sample size
#' @importFrom utils read.table 
#' @export
computeSumAndSampleSize <- function(dataPath, variableName, groupingVariable){
	data <- read.csv(dataPath, header = TRUE)
  if (!is.null(groupingVariable)){
		## Obtain names of groupinf var
		groupNames <- sort(unique(data[,groupingVariable]))
		data[,groupingVariable] <- factor(data[,groupingVariable], levels = groupNames)
		##
		uniqVals <- sort(unique(data[, groupingVariable]))
		sum <- sampleSize <- rep(NA, length(uniqVals))
		iCount <- 0
		for (iVar in uniqVals){
			iCount <- iCount + 1
			idx <- which(data[, groupingVariable] == iVar)
			sum[iCount] <- sum(data[idx, variableName], na.rm = TRUE)
			sampleSize[iCount] <- sum(!is.na(data[idx, variableName]))
		}
		names(sum) <- names(sampleSize) <- uniqVals
	}else{
		sum <- sum(data[, variableName], na.rm = TRUE)
		sampleSize <- sum(!is.na(data[, variableName]))
		groupNames <- NULL
	}
  list(sum = sum, sampleSize = sampleSize, groupNames = groupNames)
}
