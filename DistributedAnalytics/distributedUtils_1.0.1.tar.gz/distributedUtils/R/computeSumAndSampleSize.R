#' Function that computes sum and sample size of a given variable
#' @param dataPath path to data file
#' @param variableName string indicating the variable of interest
#' @return list containing the sum and the sample size
#' @importFrom utils read.table 
#' @export
computeSumAndSampleSize <- function(dataPath, variableName){
  
  data <- read.csv(dataPath, header = TRUE)
  
  sum        <- sum(data[, variableName], na.rm = TRUE)
  sampleSize <- sum(!is.na(data[, variableName]))
 
  list(sum = sum, sampleSize = sampleSize)
  
}
