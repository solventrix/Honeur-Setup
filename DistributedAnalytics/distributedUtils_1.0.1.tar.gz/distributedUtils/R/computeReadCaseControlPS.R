# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' read propensity scores and return them for cases and controls separarelu
#' @param dataPath the path to propensity scores
#' @return a list with propensity scores of cases and controls
#' 
#' @author Vahid Nassiri
#' @export
computeReadCaseControlPS <- function(dataPath){
	estPS <- read.csv(dataPath)
	return(list(case = estPS$propensityScore[estPS$response == 1],
					control = estPS$propensityScore[estPS$response == 0]))
}
