#' Function to acknowledge a response message
#' @param distributedAnalyticsApiUrl url of the distributed analytics service
#' @param tokenContext a JWT and the corresponding fingerprint
#' @param responseMessageUuid a UUID of the response message to be acknowledged
#' @importFrom httr warning add_headers set_cookies HEAD POST
#' @export
acknowledgeResponseMessage <- function(distributedAnalyticsApiUrl, tokenContext, responseMessageUuid) {

    distributedAnalyticsApiUrl <- paste(distributedAnalyticsApiUrl, "distributed-responses", "acknowledge", responseMessageUuid, sep = "/")

    response <- POST(url = distributedAnalyticsApiUrl, add_headers(token = tokenContext$token), set_cookies('userFingerprint' = tokenContext$fingerprint))

    if(http_error(response)) {
        warning(http_status(response)$message)
    }

    return (response)
}
