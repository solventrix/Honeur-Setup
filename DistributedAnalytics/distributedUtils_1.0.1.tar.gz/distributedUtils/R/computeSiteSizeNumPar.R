# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' computes sample size and number of parameter in each site for a logistic regression model
#' @param modelFormula model formula
#' @param isFactor a vector of ones and zeros with the same length as the number of covariates in the model. 
#' 1 would show its corresponding covariate is a factor, and 0 would show otherwise. 
#' @param dataPath path to the location of data in the site
#' @param isSurvival logical variable indicating whether we have a survival model (TRUE) or not (FALSE).
#' @return path to json file with sample size in the site and the number of parameters and factor levels.
#' 
#' @author Vahid Nassiri
#' @export
computeSiteSizeNumPar <- function(dataPath, modelFormula, isFactor, isSurvival = FALSE){
	## make model formula a formula, it enters as character
	modelFormula <- as.formula(modelFormula)
	## this function also needs to compute number of levels of each factor variable,
	## that is a vector of the same length as isFactor with number of levels 0 for non-factors
	inputData <- readData(dataPath, modelFormula, isFactor, isSurvival)
	## now we determine levels of each factor
	factorLevels <- list()
	for (iLevels in 1:ncol(inputData)){
		if (is.factor(inputData[,iLevels])){
			factorLevels[[iLevels]] <- levels(inputData[,iLevels])
		}else{
			factorLevels[[iLevels]] <- "not a factor!"
		}
	}
	names(factorLevels) <- colnames(inputData)
	if (isSurvival){
		toReturn <- factorLevels
	}else{
		X <- try(model.matrix(modelFormula, data = as.data.frame(inputData)))
		if (is.character(X)){
			toReturn <- X
		}else{
			toReturn <- list(siteSize = nrow(inputData), numPar = ncol(X), factorLevels = factorLevels)
		}
	}
	
	return(toReturn)
	
}
