#' Initialize a session for distributed computing
#' @param config list containing messageBrokerAddress, centerIds, studyId and dataPath
#' @return the config list with an additional slot replyQueues containing the vector
#'   of reply queues, one for every center in the list
#' @importFrom uuid UUIDgenerate
#' @export
initDistributedSession <- function(config) {
	
	if (length(config$studyId) > 1){
	  error("Only one 'studyId' allowed per session.")	
	}

	if(is.null(config$requestUuid)) {
		uuid <- UUIDgenerate(use.time = FALSE)
		config$requestUuid <- uuid
	}

	print(config$requestUuid)

	return(config)
}
