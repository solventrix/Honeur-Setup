# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' Simple function to calculate the average given a json containing a list of sum values and sample sizes
#' @param config a list with these components: "studyId", "centerIds", "messageBrokerAddress", 
#' "dataPath", here is an example:
#' dataPath <- c(system.file('extdata', 'dataLogReg1.csv', package = 'distributedUtils'),
#' 		system.file('extdata', 'dataLogReg2.csv', package = 'distributedUtils'))
#' config <- list(
#' 		studyId = "study1",
#' 		centerIds = paste0('center', 1:2),
#' 		messageBrokerAddress = messageBrokerAddress,
#' 		dataPath = dataPath
#' )
#' @param variableName string indicating the variable for which the range as well as min and max will be calculated
#' @return range, min and max
#' @export
distributedRange <- function(config, variableName){
	session <- initDistributedSession(config = config)  
	on.exit(closeDistributedSession(session))
	previousCollector <- NULL
	RFunction 			<- "computeMinAndMax"
	collectFunction <- "collectMinAndMax"
	
	# Call collectors
	minAndMaxCollector <- collector(session = session, RFunction = RFunction, 
			collectFunction = collectFunction, previousCollector = previousCollector, 
			MoreArgs = list(variableName = variableName))
	
	# Extract result
	minAndMax <- minAndMaxCollector$res
	
	
	# Compute average based on collectors info
	toReturn <- c(min(minAndMax$estMin), max(minAndMax$estMax), max(minAndMax$estMax) - min(minAndMax$estMin))	
	names(toReturn) <- c("min", "max", "range")
	return(list(res = toReturn, previousCollector = minAndMaxCollector))
}
