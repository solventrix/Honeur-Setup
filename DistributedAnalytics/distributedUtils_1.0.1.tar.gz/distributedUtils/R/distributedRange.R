# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' Simple function to calculate the average given a json containing a list of sum values and sample sizes
#' @param config a list with these components: "studyId", "centerIds", "messageBrokerAddress", 
#' "dataPath", here is an example:
#' dataPath <- c(system.file('extdata', 'dataLogReg1.csv', package = 'distributedUtils'),
#' 		system.file('extdata', 'dataLogReg2.csv', package = 'distributedUtils'))
#' config <- list(
#' 		studyId = "study1",
#' 		centerIds = paste0('center', 1:2),
#' 		messageBrokerAddress = messageBrokerAddress,
#' 		dataPath = dataPath
#' )
#' @param variableName string indicating the variable for which the range as well as min and max will be calculated
#' @param groupingVariable string indicating variable that  defines groups. It could be a binary variable, for example
#' for comparing treated/non-treated in case of propensity score matching.
#' @param onlyMatchedSubjects if TRUE, will only use the matched subjects
#' @return range, min and max
#' @export
distributedRange <- function(config, variableName, groupingVariable = NULL, onlyMatchedSubjects = FALSE){
	session <- initDistributedSession(config = config)
	on.exit(closeDistributedSession(session))
	previousCollector <- NULL
	## Subsetting data
	if (onlyMatchedSubjects){
		RFunction 			<- "computeDataSubsetting"
		collectFunction <- "collectDataSubsetting"

		# Call collectors
		dataSubsettingCollector <- collector(session = session, RFunction = RFunction,
		collectFunction = collectFunction, previousCollector = previousCollector,
		MoreArgs = NULL, sendSiteID = TRUE)
		config$dataPath <- unlist(dataSubsettingCollector$res)
		closeDistributedSession(session)
		session <- initDistributedSession(config = config)
	}

	RFunction 			<- "computeMinAndMax"
	collectFunction <- "collectMinAndMax"

	# Call collectors
	minAndMaxCollector <- collector(session = session, RFunction = RFunction,
	collectFunction = collectFunction, previousCollector = previousCollector,
	MoreArgs = list(variableName = variableName, groupingVariable = groupingVariable))

	# Extract result
	minAndMax <- minAndMaxCollector$res

	if (is.null(groupingVariable)){
		toReturn <- c(min(minAndMax$min), max(minAndMax$max), max(minAndMax$max) - min(minAndMax$min))
		names(toReturn) <- c("min", "max", "range")
	}else{
		min2return <- apply(matrix(unlist(minAndMax$min), nrow=length(minAndMax$min)), 2,min)
		max2return <- apply(matrix(unlist(minAndMax$max), nrow=length(minAndMax$max)), 2,max)
		range2return <- max2return - min2return
		names(min2return) <- names(max2return) <- names(range2return) <- sub("estMin.", "", names(minAndMax$min))
		toReturn <- rbind(min2return, max2return, range2return)
		rownames(toReturn) <- c("min", "max", "range")
	}

	# Compute average based on collectors info

	return(list(res = toReturn, previousCollector = minAndMaxCollector))
}
