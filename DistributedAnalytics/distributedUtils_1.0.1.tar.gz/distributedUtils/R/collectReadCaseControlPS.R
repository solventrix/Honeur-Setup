# TODO: Add comment
# 
# Author: Vahid Nassiri
###############################################################################


#' Combined results obtained by \link{collector} 
#' @param replyMessages list of named lists returned by the RFunction \link{computeReadCaseControlPS}
#' @return data frame containing the sample size in each site and number of parameters in the model.
#' @export
collectReadCaseControlPS <- function(replyMessages){
	
	resCombined <- lapply(replyMessages, function(x) {
				list(case = x$case, control = x$control)
			})
	
	as.data.frame(do.call('rbind', resCombined))
}


