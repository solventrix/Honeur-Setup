# launch the server:
# sudo docker run -it -p 8080:8080 openanalytics/artemis-server

# then in R session
library(artemis)

messageBrokerAddress <- "http://localhost:8080/artemis-rest"

# Create queues for hospitals, the artemis server config already has
# the queues 'center1' and 'center2' defined for demo purposes
# otherwise, queues can be created as follows:
if (FALSE){
	createQueue(brokerAddress = messageBrokerAddress, queue = 'center1')
	createQueue(brokerAddress = messageBrokerAddress, queue = 'center2')
	createQueue(brokerAddress = messageBrokerAddress, queue = 'center3')
	createQueue(brokerAddress = messageBrokerAddress, queue = 'center4')
	createQueue(brokerAddress = messageBrokerAddress, queue = 'center5')
}
