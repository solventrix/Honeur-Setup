library(httr)
library(artemis)
library(distributedUtils)

messageBrokerAddress <- "http://localhost:8080/artemis-rest"
queue <- 'center1'
msgCreateNextURL <- msgConsumeNextURL <- NULL


# Keep server active trying to retrieve messages from data analysts
while(TRUE){
  
  # This function will check every 2 seconds if there is a message from a data analyst
  resList <- pollForMessages(brokerAddress = messageBrokerAddress, queue = queue, 
		  time.sleep = 2, msgConsumeNextURL = msgConsumeNextURL)	
  msgConsumeNextURL <- resList$msgConsumeNextURL
  
  cat(resList$msg, '\n')
  
  # Reply to data analyst
  msg <- postMessage(brokerAddress = messageBrokerAddress, msg = resList$msg, 
      msgCreateNextURL = msgCreateNextURL, queue = resList$replyQueue)
  
#  msgCreateNextURL <- msg
  
}
