# load package required for the analysis
library(distributedUtils)

# The data analyst sets configuration to be used throughout the analysis e.g.
messageBrokerAddress <- "http://localhost:8080/artemis-rest"

localDataFolder <- system.file('extdata', package = 'distributedUtils') # for development only 
demoDataFolder <- "/opt/exampleData" # for demo purposes (with docker-compose)
dataFolder <- demoDataFolder 

dataPath <- file.path(dataFolder, c('study1-data1.csv', 'study1-data2.csv'))

config <- list(
		studyId = "study1",
		centerIds = paste0('center', 1:2),
		messageBrokerAddress = messageBrokerAddress,
		dataPath = dataPath
)

# distributed average
resMean <- distributedAverage(config = config, variableName = 'Sepal.Width')
resMean$res - mean(iris$Sepal.Width)

# distributed variance
resVar <- distributedVariance(config = config, variableName = 'Sepal.Width')
resVar$res - var(iris$Sepal.Width)

# distributed min, max, range
resRange <- distributedRange(config = config, variableName = 'Sepal.Width')
resRange$res - c(min(iris$Sepal.Width), max(iris$Sepal.Width), 
		max(iris$Sepal.Width) - min(iris$Sepal.Width))

# distributed logistic regression
dataPath <- file.path(dataFolder, c('dataLogReg1.csv', 'dataLogReg2.csv'))

config <- list(
		studyId = "study1",
		centerIds = paste0('center', 1:2),
		messageBrokerAddress = messageBrokerAddress,
		dataPath = dataPath
)

modelFormula <- "y ~ x1 + x2 + x3 + x4 "
isFactor <- c(1,1,0,0)
epsilon = 1e-8
maxit = 25 
includeSiteEffect = TRUE
distLogFit <- distributedLogisticRegression (config, modelFormula, isFactor, epsilon = 1e-8, maxit = 25, 
		includeSiteEffect = TRUE)

# check against plain glm output
dataPath <- file.path(localDataFolder, c('dataLogReg1.csv', 'dataLogReg2.csv'))

inputData1 <- read.csv(dataPath[[1]])
inputData2 <- read.csv(dataPath[[2]])
inputDataAll <- rbind(inputData1[,c(2,3,4,5,8)], inputData2[,c(2,3,4,5,6)])
inputDataAll$x1 <- factor(inputDataAll$x1)
inputDataAll$x2 <- factor(inputDataAll$x2)
inputDataAll <- data.frame(inputDataAll, c(rep(1, 100), rep(2,100)))
names(inputDataAll)[6] <- "siteEffect"
inputDataAll$siteEffect <- factor(inputDataAll$siteEffect)
logFit <- glm(y ~ x1 + x2 + x3 + x4 + siteEffect, data = inputDataAll, family=binomial(link="logit"))
distLogFit$paramEst-coefficients(logFit)
distLogFit$paramCov - vcov(logFit)

# distributed Cox proportional-hazards model
dataPath <- file.path(dataFolder, c('dataCox1.csv', 'dataCox2.csv'))

config <- list(
		studyId = "study1",
		centerIds = paste0('center', 1:2),
		messageBrokerAddress = messageBrokerAddress,
		dataPath = dataPath
)


modelFormula <- "Surv(time, status) ~ x1 + x2 + strata(site)"
isFactor <- c(0 , 1)
init = NULL
ties= c("efron")
singular.ok =TRUE
robust=FALSE
tt = NULL
method=ties
distCoxFit <- distributedCoxph(config, modelFormula, isFactor, maxit = 25, epsilon = 1e-09,
		init = NULL, ties= ties,
		singular.ok =TRUE, robust=FALSE,
		tt = NULL, method=ties)

# check against coxph from the survival package
dataPath <- file.path(localDataFolder, c('dataCox1.csv', 'dataCox2.csv'))

dataCox1 <- read.csv(dataPath[1])
dataCox2 <- read.csv(dataPath[2])
dataCox <- rbind(dataCox1, dataCox2)
dataCox$x2 <- factor(dataCox$x2)
library(survival)
fitAllCox <- coxph(Surv(time, status) ~ x1 + x2 + strata(site), dataCox) 

distCoxFit$betaEst - coefficients(fitAllCox)
distCoxFit$betaCov - vcov(fitAllCox)

# distributed propensity score matching
dataPath <- file.path(dataFolder, c('dataLogReg1.csv', 'dataLogReg2.csv'))

config <- list(
		studyId = "study1",
		centerIds = paste0('center', 1:2),
		messageBrokerAddress = messageBrokerAddress,
		dataPath = dataPath
)

modelFormula <- "y ~ x1 + x2 + x3 + x4 "
isFactor <- c(1,1,0,0)
epsilon = 1e-8
maxit = 25 
includeSiteEffect = TRUE

matchingCaliper <- distributedPropensityScoreMatching(config, modelFormula, isFactor, epsilon = 1e-8, maxit = 25, 
		includeSiteEffect = TRUE, matchingCaliper = TRUE, caliperValue = 0.25)
one2manyResultsWithCaliper <- matchingCaliper$one2manyResults
one2oneResultsWithCaliper <- matchingCaliper$one2oneResutls

matchingAll <- distributedPropensityScoreMatching(config, modelFormula, isFactor, epsilon = 1e-8, maxit = 25, 
		includeSiteEffect = TRUE, matchingCaliper = FALSE)
one2manyResultsWithoutCaliper <- matchingAll$one2manyResults
one2oneResultsWithoutCaliper <- matchingAll$one2oneResutls
